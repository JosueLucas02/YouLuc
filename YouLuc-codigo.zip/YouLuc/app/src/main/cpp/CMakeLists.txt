cmake_minimum_required(VERSION 3.22.1)
project(opentune_native LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_subdirectory(automix)