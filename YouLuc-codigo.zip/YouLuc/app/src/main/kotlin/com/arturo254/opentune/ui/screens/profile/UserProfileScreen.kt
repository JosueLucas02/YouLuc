package com.arturo254.opentune.ui.screens.profile

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.navigation.NavController
import coil3.compose.AsyncImage
import com.arturo254.opentune.BuildConfig
import com.arturo254.opentune.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    navController: NavController,
    viewModel: UserProfileViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    var username by remember { mutableStateOf("") }
    var photoPath by remember { mutableStateOf<String?>(null) }
    var joinDate by remember { mutableStateOf("") }
    var showEditSheet by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val (name, photo, date) = ProfileStore.load(context)
        username = name
        photoPath = photo
        joinDate = date
    }

    if (showEditSheet) {
        EditProfileBottomSheet(
            currentName = username,
            currentPhoto = photoPath,
            onDismiss = { showEditSheet = false },
            onSaved = { newName, newPhoto ->
                username = newName
                photoPath = newPhoto
                showEditSheet = false
            }
        )
    }

    val hours by viewModel.totalHours.collectAsState()
    val minutes by viewModel.totalMinutes.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF121212))
            // Fondo de puntos sutil
            .drawBehind {
                val dotColor = Color(0xFF2A2A2A)
                val spacing = 24.dp.toPx()
                val radius = 1.5.dp.toPx()
                var x = 0f
                while (x < size.width) {
                    var y = 0f
                    while (y < size.height) {
                        drawCircle(color = dotColor, radius = radius, center = Offset(x, y))
                        y += spacing
                    }
                    x += spacing
                }
            }
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(48.dp))

            // Saludo
            Text(
                text = "Hello again, $username!",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(24.dp))

            // === TARJETA DE ID ===
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF252525)),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(28.dp))) {

                    // Texto vertical de fondo
                    Text(
                        text = "${username.take(2).uppercase()}'S CARD · $username",
                        color = Color.White.copy(alpha = 0.05f),
                        fontSize = 56.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .offset(x = 30.dp)
                            .rotate(90f)
                    )

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp)
                    ) {
                        // Tag superior
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "PROFILE USR#${username.hashCode().toString().take(8)}",
                                color = Color(0xFFAAAAAA),
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(Modifier.width(8.dp))
                            Icon( painterResource(R.drawable.edit), null, tint = Color.Gray, modifier = Modifier.size(14.dp).clickable { showEditSheet = true })
                        }

                        Spacer(Modifier.height(24.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Foto
                            Box(
                                modifier = Modifier
                                    .size(90.dp)
                                    .clip(CircleShape)
                                    .background(Color.DarkGray)
                                    .clickable { showEditSheet = true },
                                contentAlignment = Alignment.Center
                            ) {
                                if (photoPath != null) {
                                    AsyncImage(
                                        model = photoPath,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(painterResource(R.drawable.person), null, tint = Color.Gray, modifier = Modifier.size(40.dp))
                                }
                            }

                            Spacer(Modifier.width(20.dp))

                            Column {
                                Text(
                                    text = "ID CARD OF",
                                    color = Color(0xFFAAAAAA),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = username,
                                        color = Color.White,
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Icon(
                                        painterResource(R.drawable.edit),
                                        contentDescription = "Edit",
                                        tint = Color.Gray,
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clickable { showEditSheet = true }
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = joinDate,
                                    color = Color(0xFFAAAAAA),
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // === TARJETA DE TIEMPO DE ESCUCHA ===
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text("$hours", fontSize = 56.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("h", fontSize = 24.sp, color = Color.Gray, modifier = Modifier.padding(bottom = 10.dp, start = 4.dp))
                            Spacer(Modifier.width(16.dp))
                            Text("$minutes", fontSize = 56.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text("m", fontSize = 24.sp, color = Color.Gray, modifier = Modifier.padding(bottom = 10.dp, start = 4.dp))
                        }
                        Text("Total Listening\ntime", color = Color.Gray, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.End)
                    }
                    HorizontalDivider(color = Color(0xFF2A2A2A), modifier = Modifier.padding(vertical = 16.dp))
                    Text("View Stats >", color = Color.Gray, fontSize = 14.sp, modifier = Modifier.clickable { /* navController.navigate("stats") */ })
                }
            }

            Spacer(Modifier.height(16.dp))

            // === TARJETA DE VERSIÓN ===
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(BuildConfig.VERSION_NAME, fontSize = 48.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                    Button(
                        onClick = { /* TODO */ },
                        shape = RoundedCornerShape(50),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF333333))
                    ) {
                        Text("About app", color = Color.White)
                    }
                }
            }
            Spacer(Modifier.height(120.dp))
        }
    }
}

@Composable
fun LinkCard(iconRes: Int, text: String) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1A1A)),
        modifier = Modifier.fillMaxWidth().clickable { /* Abrir enlace */ }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Color.DarkGray)
            ) {
                Icon(painterResource(iconRes), null, tint = Color.Gray, modifier = Modifier.align(Alignment.Center))
            }
            Spacer(Modifier.width(16.dp))
            Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
    }
}