/*
 * OpenTune Project Original (2026)
 * Arturo254 (github.com/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */

package com.arturo254.opentune.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.arturo254.opentune.R
import kotlinx.coroutines.delay

/**
 * Pantalla de apertura de OpenTune: se muestra cada vez que la app arranca.
 *
 * Reutiliza el logotipo animado de la presentación (cabeza con rebote, plica que se revela,
 * ondas y destello), muestra el nombre de la app y se despide con un fundido + ligero zoom
 * hacia la interfaz ya cargada. Mientras está visible tapa la interfaz y absorbe los toques,
 * lo que además disimula la composición inicial de la pantalla de inicio.
 *
 * Con las animaciones del sistema desactivadas dura una fracción de segundo y sin movimiento.
 */
@Composable
fun OpenTuneLaunchSplash(
    onFinished: () -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surface,
) {
    val reducedMotion = rememberReducedMotion()
    val currentOnFinished by rememberUpdatedState(onFinished)

    var showTitle by remember { mutableStateOf(false) }
    var leaving by remember { mutableStateOf(false) }

    val titleAlpha by animateFloatAsState(
        targetValue = if (showTitle) 1f else 0f,
        animationSpec = tween(durationMillis = 450, easing = FastOutSlowInEasing),
        label = "launch_splash_title",
    )
    val alpha by animateFloatAsState(
        targetValue = if (leaving) 0f else 1f,
        animationSpec = tween(durationMillis = 360, easing = FastOutSlowInEasing),
        label = "launch_splash_alpha",
    )
    val scale by animateFloatAsState(
        targetValue = if (leaving) 1.08f else 1f,
        animationSpec = tween(durationMillis = 440, easing = FastOutSlowInEasing),
        label = "launch_splash_scale",
    )

    LaunchedEffect(reducedMotion) {
        if (reducedMotion) {
            showTitle = true
            delay(350)
            leaving = true
        } else {
            delay(500)
            showTitle = true
            delay(1_000)
            leaving = true
            delay(380)
        }
        currentOnFinished()
    }

    val blocker = remember { MutableInteractionSource() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .graphicsLayer {
                this.alpha = alpha
                scaleX = scale
                scaleY = scale
            }
            .background(containerColor)
            // Absorbe los toques mientras la pantalla de apertura está visible.
            .clickable(interactionSource = blocker, indication = null, onClick = {}),
    ) {
        AuroraBackdrop(reducedMotion = reducedMotion, modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            OpenTuneLogoIntro(
                reducedMotion = reducedMotion,
                logoSize = 190.dp,
            )

            Spacer(Modifier.height(8.dp))

            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.graphicsLayer { this.alpha = titleAlpha },
            )
        }
    }
}