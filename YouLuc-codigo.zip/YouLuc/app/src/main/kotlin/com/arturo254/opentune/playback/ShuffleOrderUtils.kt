/*
 * OpenTune Project Original (2026)
 * Arturo254 (github.com/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */

package com.arturo254.opentune.playback

import kotlin.random.Random

internal fun currentFirstShuffleOrder(
    itemCount: Int,
    currentIndex: Int,
    seed: Long = System.currentTimeMillis(),
): IntArray {
    if (itemCount <= 0) return IntArray(0)

    val safeCurrentIndex = currentIndex.coerceIn(0, itemCount - 1)
    val shuffledIndices = IntArray(itemCount) { it }
    shuffledIndices.shuffle(Random(seed))

    val currentPosition = shuffledIndices.indexOf(safeCurrentIndex)
    if (currentPosition > 0) {
        shuffledIndices[currentPosition] = shuffledIndices[0]
        shuffledIndices[0] = safeCurrentIndex
    }

    return shuffledIndices
}
