/*
 * OpenTune Project Original (2026)
 * Arturo254 (github.com/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */



package com.arturo254.opentune.utils

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import timber.log.Timber

/**
 * Monitors the app's default network, including validation and data restrictions.
 */
class NetworkConnectivityObserver(context: Context) {
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val state = DefaultNetworkState<Network>(readCurrentConnectivity())
    val networkStatus = state.status
    @Volatile private var registered = false

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            // On API 26+ capabilities follow immediately. Availability alone is not internet access.
            state.available(network)
        }

        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
            state.capabilitiesChanged(network,
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET),
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
            )
        }

        override fun onBlockedStatusChanged(network: Network, blocked: Boolean) {
            state.blockedChanged(network, blocked)
        }

        override fun onLost(network: Network) {
            state.lost(network)
        }
    }

    init {
        try {
            connectivityManager.registerDefaultNetworkCallback(networkCallback)
            registered = true
        } catch (e: Exception) {
            Timber.tag("Connectivity").w(e, "Could not register default network callback")
        }
    }

    @Synchronized
    fun unregister() {
        if (!registered) return
        registered = false
        runCatching { connectivityManager.unregisterNetworkCallback(networkCallback) }
    }
    
    /**
     * Check current connectivity state synchronously
     */
    fun isCurrentlyConnected(): Boolean = if (registered) networkStatus.value else readCurrentConnectivity()

    private fun readCurrentConnectivity(): Boolean {
        return try {
            val activeNetwork = connectivityManager.activeNetwork
            val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
            
            // Check if we have internet capability
            val hasInternet = networkCapabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
            
            val isValidated = networkCapabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) == true
            
            hasInternet && isValidated
        } catch (e: Exception) {
            false
        }
    }
}
