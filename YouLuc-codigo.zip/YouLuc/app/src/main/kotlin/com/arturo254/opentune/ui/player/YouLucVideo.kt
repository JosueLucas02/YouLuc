/*
 * YouLuc — modificación de OpenTune (GPL-3.0)
 * Modo video: palanca "Canción | Video", video dentro del reproductor
 * (reproductor oficial de YouTube) y ventana flotante al salir de la app.
 */

package com.arturo254.opentune.ui.player

import android.annotation.SuppressLint
import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Rational
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.arturo254.opentune.LocalPlayerConnection
import com.arturo254.opentune.MainActivity
import com.arturo254.opentune.playback.PlayerConnection

/** Estado compartido del modo video. */
object YouLucVideoState {
    var enabled by mutableStateOf(false)

    @Volatile var currentVideoId: String? = null
    @Volatile var currentTimeSec: Double = 0.0
    @Volatile var inlineWebView: WebView? = null
    @Volatile var pipReturnTimeSec: Double? = null

    // Estado del video para que los controles del reproductor lo manejen.
    var videoPlaying by mutableStateOf(false)
    var videoPositionMs by mutableStateOf(0L)
    var videoDurationMs by mutableStateOf(0L)

    private fun js(code: String) {
        inlineWebView?.evaluateJavascript("try{$code}catch(e){}", null)
    }

    fun playVideo() { js("player.playVideo()"); videoPlaying = true }
    fun pauseVideo() { js("player.pauseVideo()"); videoPlaying = false }
    fun toggleVideo() { if (videoPlaying) pauseVideo() else playVideo() }
    fun seekVideo(ms: Long) {
        val sec = ms / 1000.0
        js("player.seekTo($sec,true)")
        videoPositionMs = ms
        currentTimeSec = sec
    }
    @Volatile var pipReturnPlay: Boolean = true

    /** Activa o desactiva el video. Al desactivar, el audio sigue desde el segundo del video. */
    fun setEnabled(on: Boolean, playerConnection: PlayerConnection?) {
        if (on == enabled) return
        if (on) {
            currentTimeSec = (playerConnection?.player?.currentPosition ?: 0L) / 1000.0
            enabled = true
        } else {
            enabled = false
            val player = playerConnection?.player ?: return
            val mediaId = player.currentMediaItem?.mediaId
            if (mediaId != null && mediaId == currentVideoId && currentTimeSec > 0.0) {
                player.seekTo((currentTimeSec * 1000).toLong())
            }
            player.play()
        }
    }

    /** Se llama al salir de la app: si hay video, lo pasa a la ventana flotante. */
    fun launchPipIfActive(activity: Activity) {
        val id = currentVideoId ?: return
        if (!enabled || inlineWebView == null) return
        if (!activity.packageManager.hasSystemFeature("android.software.picture_in_picture")) return
        inlineWebView?.evaluateJavascript("try{player.pauseVideo()}catch(e){}", null)
        val intent = Intent(activity, YouLucPipActivity::class.java)
            .putExtra(YouLucPipActivity.EXTRA_VIDEO_ID, id)
            .putExtra(YouLucPipActivity.EXTRA_START, currentTimeSec)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            activity.startActivity(intent)
        } catch (_: Exception) {
        }
    }
}

/** Puente entre el video (JavaScript) y la app. */
class YouLucVideoBridge(private val endedCallback: () -> Unit) {
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun onTime(seconds: Double) {
        YouLucVideoState.currentTimeSec = seconds
    }

    @JavascriptInterface
    fun onTick(seconds: Double, duration: Double, playing: Boolean) {
        YouLucVideoState.currentTimeSec = seconds
        main.post {
            YouLucVideoState.videoPositionMs = (seconds * 1000).toLong()
            if (duration > 0) YouLucVideoState.videoDurationMs = (duration * 1000).toLong()
            YouLucVideoState.videoPlaying = playing
        }
    }

    @JavascriptInterface
    fun onEnded() {
        main.post { endedCallback() }
    }
}

internal fun youLucEmbedHtml(videoId: String, startSec: Double): String {
    val start = startSec.toInt().coerceAtLeast(0)
    return """
        <!DOCTYPE html><html><head>
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <style>html,body{margin:0;padding:0;background:#000;height:100%;overflow:hidden}
        #p,iframe{position:absolute;inset:0;width:100%;height:100%;border:0}</style>
        </head><body><div id="p"></div>
        <script>
        var player;
        function onYouTubeIframeAPIReady(){
          player = new YT.Player('p', {
            width:'100%', height:'100%', videoId:'$videoId',
            playerVars:{autoplay:1, playsinline:1, rel:0, start:$start, origin:'https://youluc.app'},
            events:{
              onReady:function(e){ e.target.playVideo(); },
              onStateChange:function(e){ if(e.data===0){ try{YouLuc.onEnded()}catch(x){} } }
            }
          });
        }
        setInterval(function(){
          try{ if(player && player.getCurrentTime){ YouLuc.onTick(player.getCurrentTime(), player.getDuration() || 0, player.getPlayerState() === 1); } }catch(x){}
        }, 300);
        </script>
        <script src="https://www.youtube.com/iframe_api"></script>
        </body></html>
    """.trimIndent()
}

@SuppressLint("SetJavaScriptEnabled")
internal fun createYouLucWebView(context: Context, bridge: YouLucVideoBridge): WebView =
    WebView(context).apply {
        layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
        )
        setBackgroundColor(AndroidColor.BLACK)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        webViewClient = WebViewClient()
        webChromeClient = WebChromeClient()
        addJavascriptInterface(bridge, "YouLuc")
    }

internal fun WebView.loadYouLucVideo(videoId: String, startSec: Double) {
    // Una dirección https como origen evita el error 153 de YouTube.
    loadDataWithBaseURL("https://youluc.app", youLucEmbedHtml(videoId, startSec), "text/html", "utf-8", null)
}

/** Palanca "Canción | Video" estilo Spotify. */
@Composable
fun YouLucSongVideoToggle(modifier: Modifier = Modifier) {
    val playerConnection = LocalPlayerConnection.current
    val videoOn = YouLucVideoState.enabled
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.14f))
            .padding(3.dp),
    ) {
        listOf(false to "Canción", true to "Video").forEach { (value, label) ->
            val selected = videoOn == value
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (selected) Color.White else Color.Transparent)
                    .clickable { YouLucVideoState.setEnabled(value, playerConnection) }
                    .padding(horizontal = 20.dp, vertical = 7.dp),
            ) {
                Text(
                    text = label,
                    color = if (selected) Color.Black else Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

/** Video dentro del reproductor, en lugar de la portada. */
@Composable
fun YouLucInlineVideo(
    videoId: String,
    isAudioPlaying: Boolean,
    modifier: Modifier = Modifier,
) {
    val playerConnection = LocalPlayerConnection.current
    val lifecycleOwner = LocalLifecycleOwner.current

    // Al empezar cada video: pausa el audio para que no suenen los dos.
    var sawAudioPaused by remember(videoId) { mutableStateOf(false) }
    LaunchedEffect(videoId) {
        YouLucVideoState.currentVideoId = videoId
        YouLucVideoState.videoPositionMs = 0L
        YouLucVideoState.videoDurationMs = 0L
        YouLucVideoState.videoPlaying = true
        playerConnection?.player?.pause()
    }
    // Si el audio arranca por otro lado (notificación, auriculares), se apaga el video
    // y el audio sigue desde el segundo del video.
    LaunchedEffect(isAudioPlaying, videoId) {
        if (!isAudioPlaying) {
            sawAudioPaused = true
        } else if (sawAudioPaused) {
            YouLucVideoState.setEnabled(false, playerConnection)
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            val web = YouLucVideoState.inlineWebView
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    val back = YouLucVideoState.pipReturnTimeSec
                    if (back != null) {
                        YouLucVideoState.pipReturnTimeSec = null
                        val play = if (YouLucVideoState.pipReturnPlay) "player.playVideo();" else ""
                        web?.evaluateJavascript(
                            "try{player.seekTo($back,true);$play}catch(e){}",
                            null,
                        )
                    }
                }
                Lifecycle.Event.ON_STOP -> {
                    web?.evaluateJavascript("try{player.pauseVideo()}catch(e){}", null)
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val startSec = remember(videoId) {
        val pos = (playerConnection?.player?.currentPosition ?: 0L) / 1000.0
        if (playerConnection?.player?.currentMediaItem?.mediaId == videoId) pos else 0.0
    }

    key(videoId) {
        val webHolder = remember { arrayOfNulls<WebView>(1) }
        DisposableEffect(Unit) {
            onDispose {
                webHolder[0]?.let { web ->
                    if (YouLucVideoState.inlineWebView === web) YouLucVideoState.inlineWebView = null
                    web.loadUrl("about:blank")
                    web.stopLoading()
                    web.destroy()
                }
                webHolder[0] = null
            }
        }
        Box(modifier = modifier.background(Color.Black)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    createYouLucWebView(
                        ctx,
                        YouLucVideoBridge { playerConnection?.seekToNext() },
                    ).also { web ->
                        web.loadYouLucVideo(videoId, startSec)
                        webHolder[0] = web
                        YouLucVideoState.inlineWebView = web
                    }
                },
            )
        }
    }
}

/** Ventana flotante (imagen en imagen) con el video cuando sales de la app. */
class YouLucPipActivity : ComponentActivity() {
    private var webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val videoId = intent.getStringExtra(EXTRA_VIDEO_ID)
        if (videoId == null) {
            finish()
            return
        }
        val start = intent.getDoubleExtra(EXTRA_START, 0.0)
        val web = createYouLucWebView(this, YouLucVideoBridge { })
        web.loadYouLucVideo(videoId, start)
        setContentView(web)
        webView = web
    }

    private var pipRequested = false

    override fun onResume() {
        super.onResume()
        if (!pipRequested && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            pipRequested = true
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder()
                        .setAspectRatio(Rational(16, 9))
                        .build()
                )
            } catch (_: Exception) {
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (!isInPictureInPictureMode && lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
            // Tocó "agrandar": vuelve a YouLuc y el video sigue en el reproductor.
            returnToApp()
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isFinishing) {
            // Cerró la ventanita: guarda el segundo (sin volver a reproducir) y termina.
            YouLucVideoState.pipReturnTimeSec = YouLucVideoState.currentTimeSec
            YouLucVideoState.pipReturnPlay = false
            finishAndRemoveTask()
        }
    }

    private fun returnToApp() {
        YouLucVideoState.pipReturnTimeSec = YouLucVideoState.currentTimeSec
        YouLucVideoState.pipReturnPlay = true
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
        finishAndRemoveTask()
    }

    override fun onDestroy() {
        webView?.apply {
            loadUrl("about:blank")
            stopLoading()
            destroy()
        }
        webView = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_VIDEO_ID = "youluc_video_id"
        const val EXTRA_START = "youluc_start"
    }
}
