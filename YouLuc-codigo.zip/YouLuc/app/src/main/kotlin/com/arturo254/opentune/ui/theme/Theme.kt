/*
 * OpenTune Project Original (2026)
 * Arturo254 (github.com/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */



package com.arturo254.opentune.ui.theme

import android.graphics.Bitmap
import android.os.Build
import android.util.Base64
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialExpressiveTheme
import androidx.compose.material3.MotionScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.SaverScope
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.palette.graphics.Palette
import com.kyant.m3color.hct.Hct
import com.kyant.m3color.scheme.SchemeMonochrome
import com.kyant.m3color.scheme.SchemeNeutral
import com.kyant.m3color.scheme.SchemeTonalSpot
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlin.math.abs
import kotlin.math.min

val DefaultThemeColor = Color(0xFF1DB954) // YouLuc: verde tipo Spotify

data class ThemeSeedPalette(
    val primary: Color,
    val secondary: Color,
    val tertiary: Color,
    val neutral: Color,
)

data class FrostedGlassTokens(
    val isEnabled: Boolean,
    val isBlurSupported: Boolean, // Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !disableBlur
    val surfaceAlpha: Float = 0.82f,
    val borderStrokeWidthDp: Float = 1.0f,
    val borderTopAlpha: Float = 0.22f,
    val borderBottomAlpha: Float = 0.05f,
    val fallbackSurfaceColor: Color = Color(0xFF121212),
    val borderStroke: BorderStroke = BorderStroke(
        1.dp,
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = 0.22f),
                Color.White.copy(alpha = 0.05f)
            )
        )
    ),
)

val LocalFrostedGlass: ProvidableCompositionLocal<FrostedGlassTokens> =
    staticCompositionLocalOf {
        FrostedGlassTokens(
            isEnabled = false,
            isBlurSupported = false,
            surfaceAlpha = 0.82f,
            fallbackSurfaceColor = Color(0xFF121212)
        )
    }

fun resolveFrostedGlassTokens(
    isEnabled: Boolean,
    sdkInt: Int = Build.VERSION.SDK_INT,
    disableBlur: Boolean = false,
    fallbackColor: Color = Color(0xFF121212),
): FrostedGlassTokens {
    val blurSupported = isEnabled && sdkInt >= Build.VERSION_CODES.S && !disableBlur
    return FrostedGlassTokens(
        isEnabled = isEnabled,
        isBlurSupported = blurSupported,
        surfaceAlpha = 0.82f,
        fallbackSurfaceColor = fallbackColor,
    )
}

fun resolveFrostedGlassTokens(
    isEnabled: Boolean,
    sdkInt: Int,
    disableBlur: Boolean,
    fallbackColor: Long,
): FrostedGlassTokens = resolveFrostedGlassTokens(
    isEnabled = isEnabled,
    sdkInt = sdkInt,
    disableBlur = disableBlur,
    fallbackColor = Color(fallbackColor),
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun OpenTuneTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    pureBlack: Boolean = false,
    themeColor: Color = DefaultThemeColor,
    motionScheme: MotionScheme = MotionScheme.expressive(),
    seedPalette: ThemeSeedPalette? = null,
    useSystemFont: Boolean = false,
    enableFrostedGlass: Boolean = false,
    disableBlur: Boolean = false,
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    // YouLuc: siempre usar el verde propio, no los colores del fondo de pantalla.
    val useSystemDynamicColor = false

    val typography = remember(useSystemFont) {
        if (useSystemFont) SystemTypography else AppTypography
    }

    val appColorScheme =
        remember(seedPalette, themeColor, darkTheme) {
            if (seedPalette != null) {
                exactPaletteColorScheme(
                    palette = seedPalette,
                    isDark = darkTheme,
                )
            } else {
                m3DynamicColorScheme(
                    seedPalette = null,
                    keyColor = themeColor,
                    isDark = darkTheme,
                )
            }
        }

    val baseColorScheme =
        if (useSystemDynamicColor) {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        } else {
            appColorScheme
        }

    // YouLuc: con el tema por defecto en modo oscuro, colores exactos de Spotify.
    val useSpotifyColors = darkTheme &&
        (seedPalette?.primary ?: themeColor) == DefaultThemeColor
    val colorScheme = remember(baseColorScheme, pureBlack, darkTheme, useSpotifyColors) {
        val scheme = if (darkTheme && pureBlack) baseColorScheme.pureBlack(true) else baseColorScheme
        if (useSpotifyColors) scheme.youLucSpotify(pureBlack) else scheme
    }

    val animatedColorScheme = updateTransition(colorScheme)

    val frostedGlassTokens = remember(enableFrostedGlass, disableBlur, animatedColorScheme) {
        resolveFrostedGlassTokens(
            isEnabled = enableFrostedGlass,
            disableBlur = disableBlur,
            fallbackColor = animatedColorScheme.surfaceContainer,
        )
    }

    CompositionLocalProvider(
        LocalFrostedGlass provides frostedGlassTokens,
    ) {
        MaterialExpressiveTheme(
            colorScheme = animatedColorScheme,
            typography = typography,
            motionScheme = motionScheme,
            content = content
        )
    }
}

@Composable
private fun updateTransition(targetColorScheme: ColorScheme): ColorScheme {
    val animationSpec = spring<Color>(stiffness = Spring.StiffnessLow)
    return ColorScheme(
        primary = animateColorAsState(
            targetColorScheme.primary,
            animationSpec,
            label = "primary"
        ).value,
        onPrimary = animateColorAsState(
            targetColorScheme.onPrimary,
            animationSpec,
            label = "onPrimary"
        ).value,
        primaryContainer = animateColorAsState(
            targetColorScheme.primaryContainer,
            animationSpec,
            label = "primaryContainer"
        ).value,
        onPrimaryContainer = animateColorAsState(
            targetColorScheme.onPrimaryContainer,
            animationSpec,
            label = "onPrimaryContainer"
        ).value,
        inversePrimary = animateColorAsState(
            targetColorScheme.inversePrimary,
            animationSpec,
            label = "inversePrimary"
        ).value,
        secondary = animateColorAsState(
            targetColorScheme.secondary,
            animationSpec,
            label = "secondary"
        ).value,
        onSecondary = animateColorAsState(
            targetColorScheme.onSecondary,
            animationSpec,
            label = "onSecondary"
        ).value,
        secondaryContainer = animateColorAsState(
            targetColorScheme.secondaryContainer,
            animationSpec,
            label = "secondaryContainer"
        ).value,
        onSecondaryContainer = animateColorAsState(
            targetColorScheme.onSecondaryContainer,
            animationSpec,
            label = "onSecondaryContainer"
        ).value,
        tertiary = animateColorAsState(
            targetColorScheme.tertiary,
            animationSpec,
            label = "tertiary"
        ).value,
        onTertiary = animateColorAsState(
            targetColorScheme.onTertiary,
            animationSpec,
            label = "onTertiary"
        ).value,
        tertiaryContainer = animateColorAsState(
            targetColorScheme.tertiaryContainer,
            animationSpec,
            label = "tertiaryContainer"
        ).value,
        onTertiaryContainer = animateColorAsState(
            targetColorScheme.onTertiaryContainer,
            animationSpec,
            label = "onTertiaryContainer"
        ).value,
        background = animateColorAsState(
            targetColorScheme.background,
            animationSpec,
            label = "background"
        ).value,
        onBackground = animateColorAsState(
            targetColorScheme.onBackground,
            animationSpec,
            label = "onBackground"
        ).value,
        surface = animateColorAsState(
            targetColorScheme.surface,
            animationSpec,
            label = "surface"
        ).value,
        onSurface = animateColorAsState(
            targetColorScheme.onSurface,
            animationSpec,
            label = "onSurface"
        ).value,
        surfaceVariant = animateColorAsState(
            targetColorScheme.surfaceVariant,
            animationSpec,
            label = "surfaceVariant"
        ).value,
        onSurfaceVariant = animateColorAsState(
            targetColorScheme.onSurfaceVariant,
            animationSpec,
            label = "onSurfaceVariant"
        ).value,
        surfaceTint = animateColorAsState(
            targetColorScheme.surfaceTint,
            animationSpec,
            label = "surfaceTint"
        ).value,
        inverseSurface = animateColorAsState(
            targetColorScheme.inverseSurface,
            animationSpec,
            label = "inverseSurface"
        ).value,
        inverseOnSurface = animateColorAsState(
            targetColorScheme.inverseOnSurface,
            animationSpec,
            label = "inverseOnSurface"
        ).value,
        error = animateColorAsState(targetColorScheme.error, animationSpec, label = "error").value,
        onError = animateColorAsState(
            targetColorScheme.onError,
            animationSpec,
            label = "onError"
        ).value,
        errorContainer = animateColorAsState(
            targetColorScheme.errorContainer,
            animationSpec,
            label = "errorContainer"
        ).value,
        onErrorContainer = animateColorAsState(
            targetColorScheme.onErrorContainer,
            animationSpec,
            label = "onErrorContainer"
        ).value,
        outline = animateColorAsState(
            targetColorScheme.outline,
            animationSpec,
            label = "outline"
        ).value,
        outlineVariant = animateColorAsState(
            targetColorScheme.outlineVariant,
            animationSpec,
            label = "outlineVariant"
        ).value,
        scrim = animateColorAsState(targetColorScheme.scrim, animationSpec, label = "scrim").value,
        surfaceBright = animateColorAsState(
            targetColorScheme.surfaceBright,
            animationSpec,
            label = "surfaceBright"
        ).value,
        surfaceDim = animateColorAsState(
            targetColorScheme.surfaceDim,
            animationSpec,
            label = "surfaceDim"
        ).value,
        surfaceContainer = animateColorAsState(
            targetColorScheme.surfaceContainer,
            animationSpec,
            label = "surfaceContainer"
        ).value,
        surfaceContainerHigh = animateColorAsState(
            targetColorScheme.surfaceContainerHigh,
            animationSpec,
            label = "surfaceContainerHigh"
        ).value,
        surfaceContainerHighest = animateColorAsState(
            targetColorScheme.surfaceContainerHighest,
            animationSpec,
            label = "surfaceContainerHighest"
        ).value,
        surfaceContainerLow = animateColorAsState(
            targetColorScheme.surfaceContainerLow,
            animationSpec,
            label = "surfaceContainerLow"
        ).value,
        surfaceContainerLowest = animateColorAsState(
            targetColorScheme.surfaceContainerLowest,
            animationSpec,
            label = "surfaceContainerLowest"
        ).value,
    )
}

private fun exactPaletteColorScheme(
    palette: ThemeSeedPalette,
    isDark: Boolean,
): ColorScheme {
    val primaryScheme = m3Scheme(palette.primary, isDark, 0.0)
    val secondaryScheme = m3Scheme(palette.secondary, isDark, 0.0)
    val tertiaryScheme = m3Scheme(palette.tertiary, isDark, 0.0)
    val neutralScheme = m3Scheme(palette.neutral, isDark, 0.0)

    return ColorScheme(
        primary = primaryScheme.primary.toComposeColor(),
        onPrimary = primaryScheme.onPrimary.toComposeColor(),
        primaryContainer = primaryScheme.primaryContainer.toComposeColor(),
        onPrimaryContainer = primaryScheme.onPrimaryContainer.toComposeColor(),
        inversePrimary = primaryScheme.inversePrimary.toComposeColor(),
        secondary = secondaryScheme.primary.toComposeColor(),
        onSecondary = secondaryScheme.onPrimary.toComposeColor(),
        secondaryContainer = secondaryScheme.primaryContainer.toComposeColor(),
        onSecondaryContainer = secondaryScheme.onPrimaryContainer.toComposeColor(),
        tertiary = tertiaryScheme.primary.toComposeColor(),
        onTertiary = tertiaryScheme.onPrimary.toComposeColor(),
        tertiaryContainer = tertiaryScheme.primaryContainer.toComposeColor(),
        onTertiaryContainer = tertiaryScheme.onPrimaryContainer.toComposeColor(),
        background = neutralScheme.background.toComposeColor(),
        onBackground = neutralScheme.onBackground.toComposeColor(),
        surface = neutralScheme.surface.toComposeColor(),
        onSurface = neutralScheme.onSurface.toComposeColor(),
        surfaceVariant = neutralScheme.surfaceVariant.toComposeColor(),
        onSurfaceVariant = neutralScheme.onSurfaceVariant.toComposeColor(),
        surfaceTint = primaryScheme.surfaceTint.toComposeColor(),
        inverseSurface = neutralScheme.inverseSurface.toComposeColor(),
        inverseOnSurface = neutralScheme.inverseOnSurface.toComposeColor(),
        error = primaryScheme.error.toComposeColor(),
        onError = primaryScheme.onError.toComposeColor(),
        errorContainer = primaryScheme.errorContainer.toComposeColor(),
        onErrorContainer = primaryScheme.onErrorContainer.toComposeColor(),
        outline = neutralScheme.outline.toComposeColor(),
        outlineVariant = neutralScheme.outlineVariant.toComposeColor(),
        scrim = neutralScheme.scrim.toComposeColor(),
        surfaceBright = neutralScheme.surfaceBright.toComposeColor(),
        surfaceDim = neutralScheme.surfaceDim.toComposeColor(),
        surfaceContainer = neutralScheme.surfaceContainer.toComposeColor(),
        surfaceContainerHigh = neutralScheme.surfaceContainerHigh.toComposeColor(),
        surfaceContainerHighest = neutralScheme.surfaceContainerHighest.toComposeColor(),
        surfaceContainerLow = neutralScheme.surfaceContainerLow.toComposeColor(),
        surfaceContainerLowest = neutralScheme.surfaceContainerLowest.toComposeColor(),
    )
}


private fun m3DynamicColorScheme(
    seedPalette: ThemeSeedPalette?,
    keyColor: Color,
    isDark: Boolean,
    contrastLevel: Double = 0.0,
): ColorScheme {
    val primarySeed = seedPalette?.primary ?: keyColor
    val secondarySeed = seedPalette?.secondary ?: primarySeed
    val tertiarySeed = seedPalette?.tertiary ?: primarySeed
    val neutralSeed = seedPalette?.neutral ?: primarySeed

    val primaryScheme = m3Scheme(primarySeed, isDark, contrastLevel)
    val secondaryScheme = m3Scheme(secondarySeed, isDark, contrastLevel)
    val tertiaryScheme = m3Scheme(tertiarySeed, isDark, contrastLevel)
    val neutralScheme = m3Scheme(neutralSeed, isDark, contrastLevel)

    return ColorScheme(
        primary = primaryScheme.primary.toComposeColor(),
        onPrimary = primaryScheme.onPrimary.toComposeColor(),
        primaryContainer = primaryScheme.primaryContainer.toComposeColor(),
        onPrimaryContainer = primaryScheme.onPrimaryContainer.toComposeColor(),
        inversePrimary = primaryScheme.inversePrimary.toComposeColor(),
        secondary = secondaryScheme.primary.toComposeColor(),
        onSecondary = secondaryScheme.onPrimary.toComposeColor(),
        secondaryContainer = secondaryScheme.primaryContainer.toComposeColor(),
        onSecondaryContainer = secondaryScheme.onPrimaryContainer.toComposeColor(),
        tertiary = tertiaryScheme.primary.toComposeColor(),
        onTertiary = tertiaryScheme.onPrimary.toComposeColor(),
        tertiaryContainer = tertiaryScheme.primaryContainer.toComposeColor(),
        onTertiaryContainer = tertiaryScheme.onPrimaryContainer.toComposeColor(),
        background = neutralScheme.background.toComposeColor(),
        onBackground = neutralScheme.onBackground.toComposeColor(),
        surface = neutralScheme.surface.toComposeColor(),
        onSurface = neutralScheme.onSurface.toComposeColor(),
        surfaceVariant = neutralScheme.surfaceVariant.toComposeColor(),
        onSurfaceVariant = neutralScheme.onSurfaceVariant.toComposeColor(),
        surfaceTint = primaryScheme.surfaceTint.toComposeColor(),
        inverseSurface = neutralScheme.inverseSurface.toComposeColor(),
        inverseOnSurface = neutralScheme.inverseOnSurface.toComposeColor(),
        error = primaryScheme.error.toComposeColor(),
        onError = primaryScheme.onError.toComposeColor(),
        errorContainer = primaryScheme.errorContainer.toComposeColor(),
        onErrorContainer = primaryScheme.onErrorContainer.toComposeColor(),
        outline = neutralScheme.outline.toComposeColor(),
        outlineVariant = neutralScheme.outlineVariant.toComposeColor(),
        scrim = neutralScheme.scrim.toComposeColor(),
        surfaceBright = neutralScheme.surfaceBright.toComposeColor(),
        surfaceDim = neutralScheme.surfaceDim.toComposeColor(),
        surfaceContainer = neutralScheme.surfaceContainer.toComposeColor(),
        surfaceContainerHigh = neutralScheme.surfaceContainerHigh.toComposeColor(),
        surfaceContainerHighest = neutralScheme.surfaceContainerHighest.toComposeColor(),
        surfaceContainerLow = neutralScheme.surfaceContainerLow.toComposeColor(),
        surfaceContainerLowest = neutralScheme.surfaceContainerLowest.toComposeColor(),
    )
}

private fun m3Scheme(seedColor: Color, isDark: Boolean, contrastLevel: Double) =
    Hct.fromInt(seedColor.toArgb()).let { hct ->
        when {
            hct.chroma < 4.0 -> SchemeMonochrome(hct, isDark, contrastLevel)
            hct.chroma < 12.0 -> SchemeNeutral(hct, isDark, contrastLevel)
            else -> SchemeTonalSpot(hct, isDark, contrastLevel)
        }
    }

private fun Int.toComposeColor(): Color = Color(this.toLong() and 0xFFFFFFFFL)

fun Bitmap.extractThemeColor(): Color {
    val palette = Palette.from(this)
        .maximumColorCount(16)
        .generate()

    val swatch =
        palette.vibrantSwatch
            ?: palette.dominantSwatch
            ?: palette.mutedSwatch
            ?: palette.lightVibrantSwatch
            ?: palette.darkVibrantSwatch
            ?: palette.lightMutedSwatch
            ?: palette.darkMutedSwatch

    return swatch?.rgb?.toComposeColor() ?: DefaultThemeColor
}

fun Bitmap.extractGradientColors(): List<Color> {
    val palette = Palette.from(this)
        .maximumColorCount(48)
        .generate()

    val swatches = palette.swatches
        .filter { it.population > 0 }
        .sortedByDescending { it.population }

    if (swatches.isEmpty()) {
        return listOf(Color(0xFF595959), Color(0xFF0D0D0D))
    }

    val first = swatches.first()
    val firstHsv = FloatArray(3)
    android.graphics.Color.colorToHSV(first.rgb, firstHsv)

    val second =
        swatches
            .drop(1)
            .maxByOrNull { candidate ->
                val hsv = FloatArray(3)
                android.graphics.Color.colorToHSV(candidate.rgb, hsv)

                val hueDiffRaw = abs(hsv[0] - firstHsv[0])
                val hueDiff = min(hueDiffRaw, 360f - hueDiffRaw) / 180f
                val satDiff = abs(hsv[1] - firstHsv[1])
                val valueDiff = abs(hsv[2] - firstHsv[2])

                hueDiff * 0.65f + satDiff * 0.2f + valueDiff * 0.15f
            }
            ?: first

    return listOf(first.rgb.toComposeColor(), second.rgb.toComposeColor())
        .sortedByDescending { it.luminance() }
}

fun ColorScheme.pureBlack(apply: Boolean) =
    if (apply) copy(
        surface = Color.Black,
        background = Color.Black
    ) else this

val ColorSaver = object : Saver<Color, Int> {
    override fun restore(value: Int): Color = value.toComposeColor()
    override fun SaverScope.save(value: Color): Int = value.toArgb()
}

@Serializable
data class ThemeExportV1(
    val version: Int = 1,
    val name: String? = null,
    val primary: String,
    val secondary: String,
    val tertiary: String,
    val neutral: String,
)

object ThemeSeedPaletteCodec {
    private const val PreferencePrefix = "seedPalette:"
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
        isLenient = true
    }

    fun encodeForPreference(palette: ThemeSeedPalette, name: String? = null): String {
        val payload = json.encodeToString(
            ThemeExportV1(
                name = name,
                primary = palette.primary.toHexArgbString(),
                secondary = palette.secondary.toHexArgbString(),
                tertiary = palette.tertiary.toHexArgbString(),
                neutral = palette.neutral.toHexArgbString(),
            )
        )
        val b64 = Base64.encodeToString(payload.toByteArray(Charsets.UTF_8), Base64.URL_SAFE or Base64.NO_WRAP)
        return PreferencePrefix + b64
    }

    fun decodeFromPreference(value: String): ThemeSeedPalette? {
        if (!value.startsWith(PreferencePrefix)) return null
        val b64 = value.removePrefix(PreferencePrefix)
        val decoded =
            runCatching {
                val bytes = Base64.decode(b64, Base64.URL_SAFE or Base64.NO_WRAP)
                bytes.toString(Charsets.UTF_8)
            }.getOrNull()
                ?: return null
        return decodeFromJson(decoded)
    }

    fun encodeAsJson(palette: ThemeSeedPalette, name: String? = null): String =
        json.encodeToString(
            ThemeExportV1(
                name = name,
                primary = palette.primary.toHexArgbString(),
                secondary = palette.secondary.toHexArgbString(),
                tertiary = palette.tertiary.toHexArgbString(),
                neutral = palette.neutral.toHexArgbString(),
            )
        )

    fun decodeFromJson(text: String): ThemeSeedPalette? {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return null
        return runCatching {
            val element = json.parseToJsonElement(trimmed)
            val obj = element.jsonObject

            val version = obj["version"]?.jsonPrimitive?.content?.toIntOrNull() ?: 1
            if (version != 1) return@runCatching null

            fun getColor(key: String): Color? =
                obj[key]
                    ?.jsonPrimitive
                    ?.content
                    ?.toColorOrNull()

            val primary = getColor("primary") ?: return@runCatching null
            val secondary = getColor("secondary") ?: primary
            val tertiary = getColor("tertiary") ?: primary
            val neutral = getColor("neutral") ?: primary

            ThemeSeedPalette(
                primary = primary,
                secondary = secondary,
                tertiary = tertiary,
                neutral = neutral,
            )
        }.getOrNull()
            ?: decodeFromLegacyObject(trimmed)
    }

    fun extractNameFromJsonOrNull(text: String): String? {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return null
        return runCatching {
            val element: JsonElement = json.parseToJsonElement(trimmed)
            element.jsonObject["name"]?.jsonPrimitive?.content?.takeIf { it.isNotBlank() }
        }.getOrNull()
    }

    fun extractNameFromPreference(value: String): String? {
        if (!value.startsWith(PreferencePrefix)) return null
        val b64 = value.removePrefix(PreferencePrefix)
        val decoded =
            runCatching {
                val bytes = Base64.decode(b64, Base64.URL_SAFE or Base64.NO_WRAP)
                bytes.toString(Charsets.UTF_8)
            }.getOrNull()
                ?: return null
        return extractNameFromJsonOrNull(decoded)
    }

    private fun decodeFromLegacyObject(text: String): ThemeSeedPalette? {
        val trimmed = text.trim()
        if (!trimmed.startsWith("{")) return null
        return runCatching {
            val element = json.parseToJsonElement(trimmed)
            val obj = element.jsonObject

            fun getHex(key: String): String? =
                obj[key]
                    ?.jsonPrimitive
                    ?.content
                    ?.takeIf { it.isNotBlank() }

            val primary = getHex("primary")?.toColorOrNull() ?: return@runCatching null
            val secondary = getHex("secondary")?.toColorOrNull() ?: primary
            val tertiary = getHex("tertiary")?.toColorOrNull() ?: primary
            val neutral = getHex("neutral")?.toColorOrNull() ?: primary

            ThemeSeedPalette(primary, secondary, tertiary, neutral)
        }.getOrNull()
    }

    private fun Color.toHexArgbString(): String = String.format("#%08X", this.toArgb())

    private fun String.toColorOrNull(): Color? {
        val normalized = trim()
        if (normalized.isEmpty()) return null
        return runCatching {
            val withHash = if (normalized.startsWith("#")) normalized else "#$normalized"
            Color(android.graphics.Color.parseColor(withHash))
        }.getOrNull()
    }
}


// YouLuc: paleta oscura tipo Spotify
private fun ColorScheme.youLucSpotify(pureBlack: Boolean): ColorScheme {
    val green = Color(0xFF1DB954)
    val bg = if (pureBlack) Color.Black else Color(0xFF121212)
    return copy(
        primary = green,
        onPrimary = Color.Black,
        primaryContainer = green,
        onPrimaryContainer = Color.Black,
        secondary = Color(0xFF1ED760),
        onSecondary = Color.Black,
        secondaryContainer = Color(0xFF2A2A2A),
        onSecondaryContainer = Color.White,
        tertiary = green,
        onTertiary = Color.Black,
        background = bg,
        onBackground = Color.White,
        surface = bg,
        onSurface = Color.White,
        surfaceVariant = Color(0xFF2A2A2A),
        onSurfaceVariant = Color(0xFFB3B3B3),
        surfaceContainerLowest = bg,
        surfaceContainerLow = Color(0xFF181818),
        surfaceContainer = Color(0xFF1F1F1F),
        surfaceContainerHigh = Color(0xFF2A2A2A),
        surfaceContainerHighest = Color(0xFF333333),
        outline = Color(0xFF535353),
        outlineVariant = Color(0xFF2A2A2A),
    )
}
