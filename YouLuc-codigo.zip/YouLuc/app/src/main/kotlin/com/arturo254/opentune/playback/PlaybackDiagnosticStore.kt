package com.arturo254.opentune.playback

import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Bounded journal and a frozen incident window; all calls run on a background dispatcher. */
internal class PlaybackDiagnosticStore(
    private val directory: File,
    private val maxFileBytes: Int = 1024 * 1024,
    private val archiveCount: Int = 2,
) {
    init {
        require(maxFileBytes >= 128)
        require(archiveCount in 1..5)
    }
    private var incidentUntilMs = 0L
    private val incidentFile get() = File(directory, "last-incident.jsonl")
    private fun journal(index: Int) = File(directory, "events-$index.jsonl")

    @Synchronized
    fun append(line: String, timeMs: Long, incident: Boolean = false) {
        require('\n' !in line && '\r' !in line)
        if (!directory.isDirectory && !directory.mkdirs()) throw IOException("Cannot create diagnostic directory")
        val raw = (line + "\n").toByteArray(Charsets.UTF_8)
        val bytes = if (raw.size <= minOf(64 * 1024, maxFileBytes)) raw
            else "{\"event\":\"oversized_record_dropped\",\"bytes\":${raw.size}}\n".toByteArray()
        if (journal(0).length() + bytes.size + 1 > maxFileBytes) rotate()
        if (journal(0).length() > 0) {
            val endsWithNewline = RandomAccessFile(journal(0), "r").use {
                it.seek(it.length() - 1)
                it.read() == 10
            }
            if (!endsWithNewline) journal(0).appendText("\n")
        }
        journal(0).appendBytes(bytes)

        if (incident && (!incidentFile.isFile || timeMs > incidentUntilMs)) {
            val temporary = File(directory, "incident.tmp")
            temporary.outputStream().use { output ->
                // Reserve one journal's worth of space for events following the failure.
                for (file in journals().takeLast(archiveCount)) file.inputStream().use { it.copyTo(output) }
            }
            replace(temporary, incidentFile)
            incidentUntilMs = timeMs + 120_000L
        } else if (timeMs <= incidentUntilMs && incidentFile.isFile &&
            incidentFile.length() + bytes.size <= maxFileBytes.toLong() * (archiveCount + 1)) {
            incidentFile.appendBytes(bytes)
        }
    }

    private fun rotate() {
        for (index in archiveCount downTo 1) {
            val previous = journal(index - 1)
            if (previous.isFile) replace(previous, journal(index))
        }
    }

    private fun replace(source: File, destination: File) {
        Files.move(source.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING)
    }

    private fun journals() = (archiveCount downTo 0).map(::journal).filter { it.isFile }

    fun export(output: OutputStream, metadata: String) {
        val snapshot = synchronized(this) {
            (journals() + listOf(incidentFile).filter { it.isFile }).map { it.name to it.readBytes() }
        }
        ZipOutputStream(output).use { zip ->
            zip.putNextEntry(ZipEntry("report.txt"))
            zip.write(metadata.toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            for ((name, bytes) in snapshot) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(bytes)
                zip.closeEntry()
            }
        }
    }

    @Synchronized
    fun clear() {
        for (file in (0..archiveCount).map(::journal) + listOf(incidentFile, File(directory, "incident.tmp"))) {
            if (file.exists() && !file.delete()) throw IOException("Cannot delete diagnostic file")
        }
        incidentUntilMs = 0
    }
}
