package com.arturo254.opentune.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player.STATE_BUFFERING
import androidx.navigation.NavController
import com.arturo254.opentune.models.MediaMetadata
import com.arturo254.opentune.playback.PlayerConnection
import com.arturo254.opentune.ui.component.BottomSheetPageState
import com.arturo254.opentune.ui.component.BottomSheetState
import com.arturo254.opentune.ui.component.MenuState
import com.arturo254.opentune.ui.menu.PlayerMenu
import com.arturo254.opentune.ui.utils.ShowMediaInfo

@Composable
fun TurntablePlayerContent(
    mediaMetadata: MediaMetadata?,
    playerConnection: PlayerConnection,
    state: BottomSheetState,
    navController: NavController,
    menuState: MenuState,
    bottomSheetPageState: BottomSheetPageState,
    isPlaying: Boolean,
    playbackState: Int,
    queueSheetState: BottomSheetState,
) {
    // Rotación del vinilo: se incrementa mientras isPlaying sea true
    val rotation = rememberTurntableRotation(isPlaying)

    // Estado del menú expandible (chevron)
    var isExpandMenuOpen by remember { mutableStateOf(false) }

    val currentSong by playerConnection.currentSong.collectAsState(initial = null)
    val isLoading = playbackState == STATE_BUFFERING

    Box(modifier = Modifier.fillMaxSize()) {
        // 1. Fondo oscuro (el "cuarto" del tocadiscos)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.58f))
        )

        // 2. La base del brazo (se dibuja DEBAJO del vinilo)
        TurntableBase(modifier = Modifier.fillMaxSize())

        // 3. El vinilo con la etiqueta girando
        DiscCover(
            artworkUrl = mediaMetadata?.thumbnailUrl,
            rotationProvider = rotation,
            modifier = Modifier.fillMaxSize(),
        )

        // 4. El brazo interactivo (sigue la canción y es el seek bar)
        TurntableArm(
            active = state.isExpanded,
            interactive = true,
            modifier = Modifier.fillMaxSize(),
        )

        // 5. Los controles (pills + título)
        TurntableControls(
            isExpandMenuOpen = isExpandMenuOpen,
            onToggleExpandMenu = { isExpandMenuOpen = !isExpandMenuOpen },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 44.dp + queueSheetState.collapsedBound),
        )
        if (isExpandMenuOpen && mediaMetadata != null) {
            Column {
                PlayerMenu(
                    mediaMetadata = mediaMetadata,
                    navController = navController,
                    playerBottomSheetState = state,
                    onShowDetailsDialog = {
                        mediaMetadata.id.let { id ->
                            bottomSheetPageState.show {
                                ShowMediaInfo(id)
                            }
                        }
                    },
                    onDismiss = { isExpandMenuOpen = false },
                )
            }
        }
    }
}