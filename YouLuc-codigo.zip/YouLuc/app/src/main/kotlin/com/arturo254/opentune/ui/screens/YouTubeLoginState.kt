package com.arturo254.opentune.ui.screens

import java.net.URI
import kotlinx.serialization.json.*

internal object YouTubeLoginState {
    const val DEFAULT_URL = "https://accounts.google.com/ServiceLogin?continue=https%3A%2F%2Fmusic.youtube.com"
    private val youtubeHosts = setOf("music.youtube.com", "www.youtube.com", "youtube.com", "m.youtube.com")
    private val trustedDomains = listOf("google.com", "youtube.com", "gstatic.com", "googleusercontent.com", "googleapis.com")

    private fun isTrustedAuthHost(host: String): Boolean {
        val h = host.lowercase()
        if (trustedDomains.any { h == it || h.endsWith(".$it") }) return true
        if (h.matches(Regex("^(.*\\.)?google\\.[a-z]{2,3}(\\.[a-z]{2})?$"))) return true
        if (h.matches(Regex("^(.*\\.)?youtube\\.[a-z]{2,3}(\\.[a-z]{2})?$"))) return true
        return false
    }

    private fun trustedHost(url: String?): String? = runCatching {
        val uri = URI(url?.trim().orEmpty())
        uri.host?.lowercase()?.takeIf {
            uri.scheme.equals("https", true) && uri.rawUserInfo == null && uri.port in setOf(-1, 443)
        }
    }.getOrNull()

    fun isYouTubePage(url: String?) = trustedHost(url) in youtubeHosts
    fun allowsNavigation(url: String?): Boolean {
        val host = trustedHost(url) ?: return false
        return isTrustedAuthHost(host)
    }
    fun startUrl(url: String?): String = url?.trim()?.takeIf(::allowsNavigation) ?: DEFAULT_URL

    /** Preferred music.youtube.com cookies come first and must not be overwritten by a stale root cookie. */
    fun mergeCookies(values: List<String?>): String? {
        val parts = linkedMapOf<String, String>()
        for (cookies in values) for (part in cookies.orEmpty().split(';')) {
            val name = part.substringBefore('=', "").trim()
            val value = part.substringAfter('=', "").trim()
            if (name.isNotBlank() && value.isNotBlank()) parts.putIfAbsent(name, value)
        }
        return parts.takeIf { it.isNotEmpty() }?.entries?.joinToString("; ") { "${it.key}=${it.value}" }
    }

    fun authenticationCookie(cookie: String?): String? = cookie.orEmpty().split(';').firstOrNull {
        it.substringBefore('=').trim() == "SAPISID" && it.substringAfter('=', "").isNotBlank()
    }?.substringAfter('=')?.trim()

    fun hasAuthentication(cookie: String?) = authenticationCookie(cookie) != null

    data class PageConfig(val visitorData: String?, val dataSyncId: String?, val poToken: String?)

    fun pageConfig(result: String?): PageConfig? = runCatching {
        require(result != null && result.length <= 64_000)
        val outer = Json.parseToJsonElement(result)
        val parsed = if (outer is JsonPrimitive && outer.isString) Json.parseToJsonElement(outer.content) else outer
        val config = parsed as? JsonObject ?: return null
        fun text(key: String) = (config[key] as? JsonPrimitive)?.takeIf { it.isString }?.contentOrNull?.takeIf { it.isNotBlank() }
        PageConfig(text("visitorData"), text("dataSyncId"), text("poToken"))
    }.getOrNull()

    fun accountDataSyncId(raw: String): String = when {
        "||" !in raw -> raw
        raw.endsWith("||") -> raw.substringBefore("||")
        else -> raw.substringAfter("||")
    }
}
