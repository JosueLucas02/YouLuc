package com.arturo254.opentune.playback

import java.net.URI

internal object DiagnosticRedactor {
    private val urls = Regex("(?i)https?://[^\\s<>\\\"']+")
    private val localUris = Regex("(?i)(?:content|file)://[^\\s<>\\\"']+")
    private val headers = Regex("(?im)\\b(authorization|cookie|set-cookie)[\\\"']?\\s*[:=]\\s*[^\\r\\n]+")
    private val secrets = Regex("(?i)\\b(access[_-]?token|refresh[_-]?token|token|api[_-]?key|secret|password|signature|sig|sp_dc|sp_key|visitor[_-]?data|po[_-]?token)[\\\"']?\\s*[:=]\\s*[\\\"']?[^&\\s,;}'\\\"]+")
    private val bearer = Regex("(?i)\\bBearer\\s+[^\\s,;]+")
    private val emails = Regex("(?i)\\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}\\b")
    private val sensitiveKey = Regex("(?i)authorization|cookie|token|secret|password|signature|visitor|account|email|api[_-]?key|sp_dc|sp_key")

    fun redact(text: String): String {
        var result = text.take(24_000)
        result = urls.replace(result) { match ->
            val host = runCatching { URI(match.value).host }.getOrNull()
            if (host.isNullOrBlank()) "<url>" else "<url:$host>"
        }
        result = localUris.replace(result, "<local-uri>")
        result = headers.replace(result) { "${it.groupValues[1]}: <redacted>" }
        result = secrets.replace(result) { "${it.groupValues[1]}=<redacted>" }
        result = bearer.replace(result, "Bearer <redacted>")
        return emails.replace(result, "<email>")
    }

    fun field(key: String, value: Any?): Any? =
        if (sensitiveKey.containsMatchIn(key)) "<redacted>"
        else when (value) {
            null, is Boolean, is Number -> value
            else -> redact(value.toString()).take(1024)
        }
}
