/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.arturo254.opentune.ui.screens.library

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.CircularWavyProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import kotlinx.coroutines.launch
import com.arturo254.opentune.LocalPlayerAwareWindowInsets
import com.arturo254.opentune.LocalPlayerConnection
import com.arturo254.opentune.R
import com.arturo254.opentune.constants.ListThumbnailSize
import com.arturo254.opentune.constants.ThumbnailCornerRadius
import com.arturo254.opentune.extensions.togglePlayPause
import com.arturo254.opentune.models.MediaMetadata
import com.arturo254.opentune.spotify.SpotifyLikedSongsViewModel
import com.arturo254.opentune.spotify.SpotifyMusicSection
import com.arturo254.opentune.spotify.SpotifyPlaybackResolver
import com.arturo254.opentune.spotify.SpotifyTrackQueue
import com.arturo254.opentune.spotify.models.SpotifyAlbum
import com.arturo254.opentune.spotify.models.SpotifyTrack
import com.arturo254.opentune.ui.component.ChipsRow
import com.arturo254.opentune.ui.component.EmptyPlaceholder
import com.arturo254.opentune.ui.component.ExpressivePullToRefreshBox
import com.arturo254.opentune.ui.component.ItemThumbnail
import com.arturo254.opentune.ui.component.ListItem
import com.arturo254.opentune.ui.component.SpotifyTrackListItem
import com.arturo254.opentune.ui.utils.resize
import com.arturo254.opentune.utils.joinByBullet
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpotifyLikedSongsScreen(
    navController: NavController,
    scrollBehavior: TopAppBarScrollBehavior,
    viewModel: SpotifyLikedSongsViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val playerConnection = LocalPlayerConnection.current
    val isPlaying by playerConnection?.isPlaying?.collectAsStateWithLifecycle()
        ?: remember { mutableStateOf(false) }
    val mediaMetadata by playerConnection?.mediaMetadata?.collectAsStateWithLifecycle()
        ?: remember { mutableStateOf<MediaMetadata?>(null) }
    val lazyListState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    var isSearching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable(stateSaver = TextFieldValue.Saver) {
        mutableStateOf(TextFieldValue())
    }
    var resolvingTrackId by remember { mutableStateOf<String?>(null) }
    var resolvingAlbumId by remember { mutableStateOf<String?>(null) }
    val focusRequester = remember { FocusRequester() }

    val section = state.section
    val sectionTracks =
        remember(section, state.likedSongs, state.topTracks) { state.tracksFor(section) }

    val filteredTracks by remember(sectionTracks, query.text) {
        derivedStateOf {
            val text = query.text.trim()
            if (text.isBlank()) {
                sectionTracks
            } else {
                sectionTracks.filter { track ->
                    track.name.contains(text, ignoreCase = true) ||
                            track.artists.any { it.name.contains(text, ignoreCase = true) } ||
                            track.album?.name?.contains(text, ignoreCase = true) == true
                }
            }
        }
    }

    val showTopBarTitle by remember {
        derivedStateOf { lazyListState.firstVisibleItemIndex > 0 }
    }

    val sectionTitle = when (section) {
        SpotifyMusicSection.LIKED_SONGS -> stringResource(R.string.liked_songs)
        SpotifyMusicSection.TOP_TRACKS -> stringResource(R.string.spotify_top_tracks)
        SpotifyMusicSection.ALBUMS -> stringResource(R.string.spotify_saved_albums)
    }

    LaunchedEffect(isSearching) {
        if (isSearching) focusRequester.requestFocus()
    }

    fun playTracks(startIndex: Int = 0, shuffled: Boolean = false) {
        if (sectionTracks.isEmpty()) return
        val queueTracks = if (shuffled) sectionTracks.shuffled() else sectionTracks
        val bounded = startIndex.coerceIn(queueTracks.indices)
        val preloadTrack = queueTracks[bounded]
        if (resolvingTrackId != null) return
        coroutineScope.launch {
            resolvingTrackId = preloadTrack.id
            try {
                val preloadItem = SpotifyPlaybackResolver.resolveToMetadata(preloadTrack)
                playerConnection?.playQueue(
                    SpotifyTrackQueue(
                        title = sectionTitle,
                        tracks = queueTracks,
                        startIndex = bounded,
                        preloadItem = preloadItem,
                    ),
                )
            } finally {
                resolvingTrackId = null
            }
        }
    }

    fun playAlbum(album: SpotifyAlbum) {
        if (resolvingAlbumId != null) return
        coroutineScope.launch {
            resolvingAlbumId = album.id
            try {
                val tracks = viewModel.albumTracks(album.id)
                if (tracks.isEmpty()) {
                    Toast
                        .makeText(context, context.getString(R.string.spotify_no_tracks), Toast.LENGTH_SHORT)
                        .show()
                    return@launch
                }
                val preloadItem = SpotifyPlaybackResolver.resolveToMetadata(tracks.first())
                playerConnection?.playQueue(
                    SpotifyTrackQueue(
                        title = album.name,
                        tracks = tracks,
                        startIndex = 0,
                        preloadItem = preloadItem,
                    ),
                )
            } finally {
                resolvingAlbumId = null
            }
        }
    }

    ExpressivePullToRefreshBox(
        isRefreshing = state.isLoading,
        onRefresh = viewModel::refresh,
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface),
    ) {
        LazyColumn(
            state = lazyListState,
            contentPadding = LocalPlayerAwareWindowInsets.current.union(WindowInsets.ime)
                .asPaddingValues(),
            modifier = Modifier.fillMaxSize(),
        ) {
            item(key = "header") {
                SpotifyFavoritesHeader(
                    sectionTitle = sectionTitle,
                    count = when (section) {
                        SpotifyMusicSection.LIKED_SONGS -> state.likedSongs.size
                        SpotifyMusicSection.TOP_TRACKS -> state.topTracks.size
                        SpotifyMusicSection.ALBUMS -> state.savedAlbums.size
                    },
                    section = section,
                    canPlay = sectionTracks.isNotEmpty(),
                    isResolving = resolvingTrackId != null,
                    onPlay = { playTracks() },
                    onShuffle = { playTracks(shuffled = true) },
                )
            }

            item(key = "sections") {
                ChipsRow(
                    chips = listOf(
                        SpotifyMusicSection.LIKED_SONGS to stringResource(R.string.liked_songs),
                        SpotifyMusicSection.TOP_TRACKS to stringResource(R.string.spotify_top_tracks),
                        SpotifyMusicSection.ALBUMS to stringResource(R.string.spotify_saved_albums),
                    ),
                    currentValue = section,
                    onValueUpdate = viewModel::selectSection,
                    icons = mapOf(
                        SpotifyMusicSection.LIKED_SONGS to R.drawable.favorite,
                        SpotifyMusicSection.TOP_TRACKS to R.drawable.trending_up,
                        SpotifyMusicSection.ALBUMS to R.drawable.album,
                    ),
                )
            }

            state.errorMessage?.let { error ->
                item(key = "error") {
                    Text(
                        text = error,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp),
                    )
                }
            }

            when (section) {
                SpotifyMusicSection.ALBUMS -> {
                    val albums = state.savedAlbums
                    if (albums.isEmpty()) {
                        item(key = "empty_albums") {
                            FavoritesEmptyState(
                                icon = R.drawable.album,
                                text = stringResource(R.string.spotify_empty_albums),
                            )
                        }
                    } else {
                        itemsIndexed(
                            items = albums,
                            key = { index, album -> "spotify_album_${album.id}_$index" },
                            contentType = { _, _ -> "spotify_album" },
                        ) { _, album ->
                            SpotifySavedAlbumListItem(
                                album = album,
                                isResolving = resolvingAlbumId == album.id,
                                onClick = { playAlbum(album) },
                            )
                        }
                    }
                }

                else -> {
                    if (state.isLoading && sectionTracks.isEmpty()) {
                        item(key = "loading") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                CircularWavyProgressIndicator()
                            }
                        }
                    }

                    if (!state.isLoading && filteredTracks.isEmpty()) {
                        item(key = "empty") {
                            FavoritesEmptyState(
                                icon = if (section == SpotifyMusicSection.LIKED_SONGS) {
                                    R.drawable.favorite
                                } else {
                                    R.drawable.trending_up
                                },
                                text = stringResource(
                                    if (query.text.isBlank()) {
                                        if (section == SpotifyMusicSection.LIKED_SONGS) {
                                            R.string.spotify_empty_liked
                                        } else {
                                            R.string.spotify_empty_top
                                        }
                                    } else {
                                        R.string.ai_model_no_results
                                    },
                                ),
                            )
                        }
                    }

                    itemsIndexed(
                        items = filteredTracks,
                        key = { index, track -> "spotify_liked_${track.id}_$index" },
                        contentType = { _, _ -> "spotify_track" },
                    ) { index, track ->
                        val trackIsActive =
                            remember(track, mediaMetadata) { track.isResolvedAs(mediaMetadata) }
                        val trackIsResolving = resolvingTrackId == track.id
                        val liked = track.id in state.likedTrackIds

                        SpotifyTrackListItem(
                            track = track,
                            isActive = trackIsActive || trackIsResolving,
                            isPlaying = isPlaying && !trackIsResolving,
                            trailingContent = {
                                FilledTonalIconButton(
                                    onClick = { viewModel.toggleLike(track) },
                                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                                        containerColor = if (liked) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.surfaceVariant
                                        },
                                        contentColor = if (liked) {
                                            MaterialTheme.colorScheme.onPrimary
                                        } else {
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                        },
                                    ),
                                    modifier = Modifier.size(40.dp),
                                ) {
                                    Icon(
                                        painter = painterResource(
                                            if (liked) R.drawable.favorite_filled
                                            else R.drawable.favorite_outline,
                                        ),
                                        contentDescription = stringResource(R.string.liked),
                                        modifier = Modifier.size(20.dp),
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = resolvingTrackId == null || trackIsActive) {
                                    if (trackIsActive) {
                                        playerConnection
                                            ?.player
                                            ?.togglePlayPause()
                                    } else {
                                        val startIndex = sectionTracks
                                            .indexOfFirst { it.id == track.id }
                                            .takeIf { it >= 0 }
                                            ?: index
                                        playTracks(startIndex = startIndex)
                                    }
                                },
                        )
                    }
                }
            }

            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        TopAppBar(
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = if (showTopBarTitle || isSearching) {
                    MaterialTheme.colorScheme.surface
                } else {
                    Color.Transparent
                },
                scrolledContainerColor = MaterialTheme.colorScheme.surface,
            ),
            title = {
                if (isSearching) {
                    TextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = {
                            Text(
                                text = stringResource(R.string.search),
                                style = MaterialTheme.typography.titleLarge,
                            )
                        },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.titleLarge,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            disabledIndicatorColor = Color.Transparent,
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester),
                    )
                } else if (showTopBarTitle) {
                    Text(text = sectionTitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            },
            navigationIcon = {
                IconButton(
                    onClick = {
                        if (isSearching) {
                            isSearching = false
                            query = TextFieldValue()
                        } else {
                            navController.navigateUp()
                        }
                    },
                ) {
                    Icon(
                        painter = painterResource(
                            if (isSearching) R.drawable.close else R.drawable.arrow_back,
                        ),
                        contentDescription = null,
                    )
                }
            },
            actions = {
                if (!isSearching) {
                    IconButton(onClick = { isSearching = true }) {
                        Icon(
                            painter = painterResource(R.drawable.search),
                            contentDescription = null,
                        )
                    }
                }
            },
            scrollBehavior = scrollBehavior,
        )
    }
}

@Composable
private fun SpotifyFavoritesHeader(
    sectionTitle: String,
    count: Int,
    section: SpotifyMusicSection,
    canPlay: Boolean,
    isResolving: Boolean,
    onPlay: () -> Unit,
    onShuffle: () -> Unit,
) {
    val accentColor = MaterialTheme.colorScheme.primary
    val heroShape = RoundedCornerShape(
        topStart = 30.dp,
        topEnd = 12.dp,
        bottomEnd = 30.dp,
        bottomStart = 30.dp,
    )
    val iconRes = when (section) {
        SpotifyMusicSection.LIKED_SONGS -> R.drawable.favorite
        SpotifyMusicSection.TOP_TRACKS -> R.drawable.trending_up
        SpotifyMusicSection.ALBUMS -> R.drawable.album
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                top = WindowInsets.systemBars.asPaddingValues().calculateTopPadding() + 64.dp,
                start = 16.dp,
                end = 16.dp,
                bottom = 8.dp,
            ),
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth(),
        ) {
            Surface(
                shape = heroShape,
                color = accentColor.copy(alpha = 0.16f),
                modifier = Modifier.size(72.dp),
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        painter = painterResource(iconRes),
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(34.dp),
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = sectionTitle,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.Black,
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                    text = stringResource(R.string.spotify_track_count, count),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                )
            }
        }

        if (section != SpotifyMusicSection.ALBUMS) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
            ) {
                FilledIconButton(
                    onClick = onPlay,
                    enabled = canPlay && !isResolving,
                    modifier = Modifier.size(52.dp),
                ) {
                    Icon(
                        painter = painterResource(R.drawable.play),
                        contentDescription = stringResource(R.string.play),
                        modifier = Modifier.size(26.dp),
                    )
                }
                FilledTonalIconButton(
                    onClick = onShuffle,
                    enabled = canPlay && !isResolving,
                    modifier = Modifier.size(52.dp),
                ) {
                    Icon(
                        painter = painterResource(R.drawable.shuffle),
                        contentDescription = stringResource(R.string.shuffle),
                        modifier = Modifier.size(24.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun SpotifySavedAlbumListItem(
    album: SpotifyAlbum,
    isResolving: Boolean,
    onClick: () -> Unit,
) {
    val artists = remember(album) { album.artists.joinToString { it.name }.trim() }
    val subtitle = joinByBullet(
        artists.takeIf { it.isNotBlank() },
        stringResource(R.string.spotify_track_count, album.totalTracks),
    )

    ListItem(
        title = album.name.ifBlank { stringResource(R.string.no_title) },
        subtitle = subtitle,
        thumbnailContent = {
            ItemThumbnail(
                thumbnailUrl = album.images.firstOrNull()?.url?.resize(200, 200),
                isActive = false,
                isPlaying = false,
                shape = RoundedCornerShape(ThumbnailCornerRadius),
                placeholderIconRes = R.drawable.album,
                modifier = Modifier.size(ListThumbnailSize),
            )
        },
        trailingContent = {
            if (isResolving) {
                CircularWavyProgressIndicator(modifier = Modifier.size(24.dp))
            } else {
                Icon(
                    painter = painterResource(R.drawable.chevron_right),
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(22.dp),
                )
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = !isResolving, onClick = onClick),
    )
}

@Composable
private fun FavoritesEmptyState(
    icon: Int,
    text: String,
) {
    EmptyPlaceholder(
        icon = icon,
        text = text,
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp),
    )
}

private fun SpotifyTrack.isResolvedAs(mediaMetadata: MediaMetadata?): Boolean {
    if (mediaMetadata == null) return false

    mediaMetadata.spotifyTrackId?.let { spotifyTrackId ->
        return id.isNotBlank() && spotifyTrackId == id
    }

    val titleMatches = name.equals(mediaMetadata.title, ignoreCase = true)
    val durationMatches =
        durationMs <= 0 ||
                mediaMetadata.duration <= 0 ||
                abs(durationMs.toLong() - mediaMetadata.duration * 1000L) <= 1_000L
    val albumMatches =
        album?.let { spotifyAlbum ->
            val currentAlbum = mediaMetadata.album ?: return false
            spotifyAlbum.id.isNotBlank() && spotifyAlbum.id == currentAlbum.id ||
                    spotifyAlbum.name.equals(currentAlbum.title, ignoreCase = true)
        } ?: true
    val artistMatches =
        artists.isEmpty() ||
                mediaMetadata.artists.isEmpty() ||
                artists.any { spotifyArtist ->
                    mediaMetadata.artists.any { artist ->
                        spotifyArtist.name.equals(artist.name, ignoreCase = true)
                    }
                }

    return titleMatches && durationMatches && albumMatches && artistMatches
}
