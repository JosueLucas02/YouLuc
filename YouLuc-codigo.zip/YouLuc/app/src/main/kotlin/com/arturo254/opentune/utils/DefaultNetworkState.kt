package com.arturo254.opentune.utils

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Tracks only the default route; late callbacks for a previous network cannot revive it. */
internal class DefaultNetworkState<N>(initiallyConnected: Boolean) {
    private val connected = MutableStateFlow(initiallyConnected)
    val status = connected.asStateFlow()
    private var current: N? = null
    private var validated = false
    private var blocked = false

    @Synchronized
    fun available(network: N) {
        current = network
        validated = false
        blocked = false
        connected.value = false
    }

    @Synchronized
    fun capabilitiesChanged(network: N, hasInternet: Boolean, isValidated: Boolean) {
        if (network != current) return
        validated = hasInternet && isValidated
        connected.value = validated && !blocked
    }

    @Synchronized
    fun blockedChanged(network: N, isBlocked: Boolean) {
        if (network != current) return
        blocked = isBlocked
        connected.value = validated && !blocked
    }

    @Synchronized
    fun lost(network: N) {
        if (network != current) return
        current = null
        validated = false
        connected.value = false
    }
}
