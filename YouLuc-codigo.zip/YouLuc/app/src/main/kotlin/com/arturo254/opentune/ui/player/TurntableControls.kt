package com.arturo254.opentune.ui.player

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.arturo254.opentune.LocalPlayerConnection
import com.arturo254.opentune.R
import com.arturo254.opentune.extensions.togglePlayPause

// The Turntable frame's controls, at its sizes: four pills stacked on the right (like, back,
// play/pause, forward) above the title row - the chevron on the left, the title and its format
// badge running the width under them.
/** a pill's width, for a layout that leaves room for the stack */
val TurntablePillWidth = 59.dp
private val PillWidth = TurntablePillWidth
private val PillHeight = 42.dp
private val PillGap = 11.dp
private val ChevronSize = 43.dp
private val SideMargin = 30.dp
private val PillFill = Color.White.copy(alpha = 0.08f)
/** between the stack and the title row, on top of the stack's own gap */
private val TitleGap = 4.dp

@Composable
fun TurntableControls(
    isExpandMenuOpen: Boolean,
    onToggleExpandMenu: () -> Unit,
    modifier: Modifier = Modifier,
    /** hides the chevron while the lyrics page's own (the same control, moved) is up */
    hideChevron: Boolean = false,
) {
    val connection = LocalPlayerConnection.current ?: return
    val mediaMetadata by connection.mediaMetadata.collectAsState()

    Column(
        verticalArrangement = Arrangement.spacedBy(PillGap),
        modifier = modifier
            .fillMaxWidth()
            .padding(start = SideMargin, end = SideMargin),
    ) {
        TurntablePills(modifier = Modifier.align(Alignment.End))
        Spacer(Modifier.height(TitleGap))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth(),
        ) {
            ChevronButton(
                open = isExpandMenuOpen,
                hidden = hideChevron,
                onClick = onToggleExpandMenu,
            )
            Spacer(Modifier.width(14.dp))
            TitleBlock(
                title = mediaMetadata?.title ?: "",
                artist = mediaMetadata?.artists?.joinToString(", ") { it.name } ?: "",
                modifier = Modifier.weight(1f),
            )
        }
    }
}

/**
 * The Turntable's stack of pills, top to bottom: like, back, play/pause, forward.
 */
@Composable
fun TurntablePills(modifier: Modifier = Modifier, horizontal: Boolean = false) {
    val connection = LocalPlayerConnection.current ?: return
    val mediaMetadata by connection.mediaMetadata.collectAsState()
    val isPlaying by connection.isPlaying.collectAsState()
    val playbackState by connection.playbackState.collectAsState()
    val canSkipPrevious by connection.canSkipPrevious.collectAsState()
    val canSkipNext by connection.canSkipNext.collectAsState()
    // liked: OpenTune no expone liked en mediaMetadata directamente; usamos currentSong
    val currentSong by connection.currentSong.collectAsState(initial = null)
    val isLiked = currentSong?.song?.liked == true

    val pills: @Composable () -> Unit = {
        // Like
        Pill {
            PressScaleIcon(
                icon = if (isLiked) R.drawable.favorite else R.drawable.favorite_border,
                tint = if (isLiked) Color.White else Color.White.copy(alpha = 0.85f),
                onClick = { connection.toggleLike() },
            )
        }
        // Previous
        Pill {
            AnimatedPressScaleIconButton(
                icon = R.drawable.skip_previous,
                onClick = { connection.seekToPrevious() },
                enabled = canSkipPrevious,
                tint = Color.White,
                iconSize = 24.dp,
            )
        }
        // Play/Pause
        Pill {
            AnimatedPressScaleIconButton(
                icon = when {
                    playbackState == Player.STATE_ENDED -> R.drawable.replay
                    isPlaying -> R.drawable.pause
                    else -> R.drawable.play
                },
                onClick = {
                    if (playbackState == Player.STATE_ENDED) {
                        connection.player.seekTo(0, 0)
                        connection.player.playWhenReady = true
                    } else {
                        connection.player.togglePlayPause()
                    }
                },
                enabled = true,
                tint = Color.White,
                iconSize = 26.dp,
            )
        }
        // Next
        Pill {
            AnimatedPressScaleIconButton(
                icon = R.drawable.skip_next,
                onClick = { connection.seekToNext() },
                enabled = canSkipNext,
                tint = Color.White,
                iconSize = 24.dp,
            )
        }
    }
    if (horizontal) {
        Row(horizontalArrangement = Arrangement.spacedBy(PillGap), modifier = modifier) { pills() }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(PillGap), modifier = modifier) { pills() }
    }
}

@Composable
private fun Pill(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(PillWidth, PillHeight)
            .clip(RoundedCornerShape(50))
            .background(PillFill),
    ) { content() }
}

@Composable
private fun PressScaleIcon(icon: Int, tint: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.84f else 1f, spring(dampingRatio = 0.54f, stiffness = 720f), label = "pillPress")
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = null,
            tint = tint,
            modifier = modifier
                .size(20.dp)
                .graphicsLayer { scaleX = scale; scaleY = scale },
        )
    }
}

@Composable
private fun AnimatedPressScaleIconButton(
    icon: Int,
    onClick: () -> Unit,
    enabled: Boolean,
    tint: Color,
    iconSize: androidx.compose.ui.unit.Dp,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.84f else 1f,
        spring(dampingRatio = 0.54f, stiffness = 720f),
        label = "pillPress",
    )
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxSize()
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled,
                onClick = onClick,
            ),
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = null,
            tint = if (enabled) tint else tint.copy(alpha = 0.4f),
            modifier = Modifier
                .size(iconSize)
                .graphicsLayer { scaleX = scale; scaleY = scale },
        )
    }
}

@Composable
private fun ChevronButton(open: Boolean, hidden: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val rotation by animateFloatAsState(if (open) 180f else 0f, spring(dampingRatio = 0.55f, stiffness = 380f), label = "ttChevron")
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.86f else 1f, spring(dampingRatio = 0.54f, stiffness = 720f), label = "ttChevronPress")
    Box(
        modifier = modifier
            .size(ChevronSize)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick),
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale; scaleY = scale
                    alpha = if (open || hidden) 0f else 1f
                }
                .clip(CircleShape)
                .background(PillFill),
        ) {
            Icon(
                painter = painterResource(R.drawable.expand_more),
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.9f),
                modifier = Modifier
                    .size(20.dp)
                    .graphicsLayer { rotationZ = rotation },
            )
        }
    }
}

/** The song's title and artist. */
@Composable
private fun TitleBlock(title: String, artist: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 27.sp,
                lineHeight = 31.sp,
            ),
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (artist.isNotBlank()) {
            Text(
                text = artist,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 17.sp,
                    lineHeight = 20.sp,
                ),
                color = Color.White.copy(alpha = 0.55f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}