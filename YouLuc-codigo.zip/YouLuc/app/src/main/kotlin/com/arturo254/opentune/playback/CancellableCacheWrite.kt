package com.arturo254.opentune.playback

import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import okhttp3.Call
import okhttp3.Request
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/** One sequential cache writer owns its calls; cancelling it never cancels foreground playback. */
internal class PreloadCallFactory(private val delegate: Call.Factory) : Call.Factory {
    private val cancelled = AtomicBoolean(false)
    private val active = AtomicReference<Call?>()

    override fun newCall(request: Request): Call = delegate.newCall(request).also {
        active.set(it)
        if (cancelled.get()) it.cancel()
    }

    fun cancel() {
        cancelled.set(true)
        active.getAndSet(null)?.cancel()
    }
}

/** Interrupt cache locks and close the HTTP call, including a read blocked inside OkHttp. */
internal suspend fun runCancellableCacheWrite(write: () -> Unit, cancel: () -> Unit) = coroutineScope {
    val cleanup = launch(start = CoroutineStart.UNDISPATCHED) {
        try { awaitCancellation() } finally { cancel() }
    }
    try {
        runInterruptible(Dispatchers.IO) { write() }
    } finally {
        cleanup.cancelAndJoin()
    }
}
