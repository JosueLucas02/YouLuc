package com.arturo254.opentune.ui.screens.settings

import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import com.arturo254.opentune.R
import com.arturo254.opentune.constants.AudioPreloadCountKey
import com.arturo254.opentune.constants.AudioPreloadMeteredKey
import com.arturo254.opentune.playback.AudioPreloadPolicy
import com.arturo254.opentune.ui.component.ListPreference
import com.arturo254.opentune.ui.component.PreferenceEntry
import com.arturo254.opentune.ui.component.PreferenceGroupTitle
import com.arturo254.opentune.ui.component.SwitchPreference
import com.arturo254.opentune.utils.rememberPreference

@Composable
fun AudioPreloadPreferences() {
    val (count, changeCount) = rememberPreference(AudioPreloadCountKey, AudioPreloadPolicy.DEFAULT_COUNT)
    val (metered, changeMetered) = rememberPreference(AudioPreloadMeteredKey, false)
    PreferenceGroupTitle(title = stringResource(R.string.audio_preload_title))
    ListPreference(
        title = { Text(stringResource(R.string.audio_preload_count)) },
        icon = { Icon(painterResource(R.drawable.download), null) },
        selectedValue = count.coerceIn(0, AudioPreloadPolicy.MAX_COUNT),
        values = listOf(0, 3, 5, 10),
        valueText = { if (it == 0) stringResource(R.string.disable) else pluralStringResource(R.plurals.n_song, it, it) },
        onValueSelected = changeCount,
    )
    PreferenceEntry(
        title = { Text(stringResource(R.string.audio_preload_description)) },
    )
    SwitchPreference(
        title = { Text(stringResource(R.string.audio_preload_metered)) },
        description = stringResource(R.string.audio_preload_metered_description),
        checked = metered,
        onCheckedChange = changeMetered,
        isEnabled = count > 0,
    )
}
