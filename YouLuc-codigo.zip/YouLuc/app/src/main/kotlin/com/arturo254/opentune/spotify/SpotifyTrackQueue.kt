/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.arturo254.opentune.spotify

import androidx.media3.common.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import com.arturo254.opentune.models.MediaMetadata
import com.arturo254.opentune.playback.queues.Queue
import com.arturo254.opentune.spotify.models.SpotifyTrack

/**
 * Cola de reproducción para listas de Spotify que ya se conocen por completo
 * (canciones que te gustan, álbumes guardados, top tracks...). No consulta la
 * API: solo traduce cada [SpotifyTrack] al MediaItem equivalente de YouTube
 * Music, resolviendo por lotes para no bloquear el arranque de la reproducción.
 */
class SpotifyTrackQueue(
    private val title: String? = null,
    private val tracks: List<SpotifyTrack>,
    private val startIndex: Int = 0,
    override val preloadItem: MediaMetadata? = null,
) : Queue {
    private var resolveOffset = 0

    override suspend fun getInitialStatus(): Queue.Status =
        withContext(Dispatchers.IO) {
            if (tracks.isEmpty()) {
                return@withContext Queue.Status(
                    title = title,
                    items = emptyList(),
                    mediaItemIndex = 0,
                )
            }

            val targetIndex = startIndex.coerceIn(tracks.indices)
            val batchEnd = minOf(tracks.size, targetIndex + RESOLVE_BATCH_SIZE)
            val initialBatch = tracks.subList(targetIndex, batchEnd)

            var resolved = resolve(initialBatch)
            var offset = batchEnd

            // Si el lote inicial no produjo ninguna coincidencia, seguimos
            // avanzando hasta encontrar algo reproducible.
            while (resolved.isEmpty() && offset < tracks.size) {
                val end = minOf(tracks.size, offset + RESOLVE_BATCH_SIZE)
                resolved = resolve(tracks.subList(offset, end))
                offset = end
            }

            resolveOffset = offset

            if (resolved.isEmpty()) {
                return@withContext Queue.Status(
                    title = title,
                    items = emptyList(),
                    mediaItemIndex = 0,
                )
            }

            Queue.Status(
                title = title,
                items = resolved,
                mediaItemIndex = 0,
            )
        }

    override fun hasNextPage(): Boolean = resolveOffset < tracks.size

    override suspend fun nextPage(): List<MediaItem> =
        withContext(Dispatchers.IO) {
            if (resolveOffset >= tracks.size) return@withContext emptyList()
            val end = minOf(tracks.size, resolveOffset + RESOLVE_BATCH_SIZE)
            val batch = tracks.subList(resolveOffset, end)
            resolveOffset = end
            resolve(batch)
        }

    private suspend fun resolve(batch: List<SpotifyTrack>): List<MediaItem> =
        coroutineScope {
            batch
                .map { track ->
                    async { SpotifyPlaybackResolver.resolveToMediaItem(track) }
                }.awaitAll()
                .filterNotNull()
        }

    companion object {
        private const val RESOLVE_BATCH_SIZE = 20
    }
}
