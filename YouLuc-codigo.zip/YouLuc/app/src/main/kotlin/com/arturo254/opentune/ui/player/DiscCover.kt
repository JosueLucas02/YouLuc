// DiscCover.kt
// Adaptado para OpenTune desde Musicfy/Mochy (versión simplificada solo para Turntable)
// Paquete: com.arturo254.opentune.ui.player

package com.arturo254.opentune.ui.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.allowHardware
import coil3.request.crossfade
import coil3.size.Precision
import com.arturo254.opentune.ui.utils.highRes
import coil3.size.Size as CoilSize

import kotlin.math.min

@Immutable
data class DiscGeometry(
    val diameter: Float,
    val centerX: Float,
    val centerY: Float,
    val art: Float,
    val centerYByWidth: Float? = null,
) {
    val byWidth: Boolean get() = centerYByWidth != null
}

/** Geometría del disco para el estilo Turntable (basada en la de Musicfy) */
fun discGeometryForTurntable(): DiscGeometry = DiscGeometry(
    diameter = 1.406f,
    centerX = 0.162f,
    centerY = 0.5f,
    art = 0.526f,
    centerYByWidth = 0.703f,
)

private val PlatterBlack = Color(0xFF0B0B0D)
private val LabelFallback = Color(0xFF27303B)

/**
 * Dibuja el disco de vinilo con la etiqueta giratoria.
 *
 * @param artworkUrl URL de la portada (se usa como etiqueta).
 * @param rotationProvider Ángulo de rotación actual (para girar la etiqueta).
 * @param modifier Modificador.
 */
@Composable
fun DiscCover(
    artworkUrl: String?,
    rotationProvider: () -> Float,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val geometry = remember { discGeometryForTurntable() }

    BoxWithConstraints(modifier = modifier) {
        val boxSide = if (geometry.byWidth) maxWidth.value else min(maxWidth.value, maxHeight.value)
        val discSide = boxSide * geometry.diameter
        val discSidePx = with(density) { discSide.dp.toPx() }

        val discLeft = maxWidth.value * geometry.centerX - discSide / 2f
        val discTop = (geometry.centerYByWidth?.let { maxWidth.value * it } ?: (maxHeight.value * geometry.centerY)) - discSide / 2f
        val discLeftPx = with(density) { discLeft.dp.toPx() }
        val discTopPx = with(density) { discTop.dp.toPx() }

        val platterModifier = Modifier
            .then(if (geometry.byWidth) Modifier.wrapContentSize(Alignment.TopStart, unbounded = true) else Modifier)
            .requiredSize(discSide.dp)
            .offset { IntOffset(discLeftPx.toInt(), discTopPx.toInt()) }

        // El vinilo (superficie estática, se dibuja una vez)
        Canvas(
            modifier = platterModifier.then(
                Modifier.graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            )
        ) {
            val r = size.minDimension / 2f
            val center = Offset(size.width / 2f, size.height / 2f)
            drawVinyl(center, r, geometry.art)
        }

        // La etiqueta (portada) girando
        val labelSide = (discSide * geometry.art).dp
        Box(
            modifier = platterModifier
                .graphicsLayer { rotationZ = rotationProvider() }
        ) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(labelSide)
                    .clip(CircleShape)
                    .background(LabelFallback),
            ) {
                if (artworkUrl != null) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(artworkUrl.highRes())
                            .allowHardware(true)
                            .crossfade(300)
                            .size(CoilSize(1200, 1200))
                            .precision(Precision.INEXACT)
                            .build(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        }

        // Sombra suave bajo el disco (opcional, para realismo)
        Canvas(modifier = platterModifier) {
            val r = size.minDimension / 2f
            val center = Offset(size.width / 2f, size.height / 2f)
            drawCircle(
                brush = androidx.compose.ui.graphics.Brush.radialGradient(
                    0.86f to Color.Black.copy(alpha = 0.55f),
                    1f to Color.Transparent,
                    center = center + Offset(0f, r * 0.035f),
                    radius = r * 1.09f,
                ),
                radius = r * 1.09f,
                center = center + Offset(0f, r * 0.035f),
            )
        }
    }
}