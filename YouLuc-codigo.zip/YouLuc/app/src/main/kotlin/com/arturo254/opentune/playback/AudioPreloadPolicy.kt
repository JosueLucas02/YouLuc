package com.arturo254.opentune.playback

internal object AudioPreloadPolicy {
    const val DEFAULT_COUNT = 5
    const val MAX_COUNT = 10
    const val MIB = 1024 * 1024L
    const val MAX_SONG_BYTES = 32 * MIB
    const val FREE_SPACE_RESERVE = 32 * MIB

    fun budgetBytes(cacheSizeMb: Int): Long = when {
        cacheSizeMb == -1 -> 128 * MIB
        cacheSizeMb <= 0 -> 0
        else -> minOf(128 * MIB, cacheSizeMb.toLong() * MIB / 2)
    }

    fun canPreload(
        count: Int, cacheSizeMb: Int, playing: Boolean, ready: Boolean,
        connected: Boolean, metered: Boolean, allowMetered: Boolean,
        bufferedAheadMs: Long, fullyBuffered: Boolean, testBypass: Boolean,
    ): Boolean = count > 0 && budgetBytes(cacheSizeMb) > 0 && playing && ready &&
        connected && (!metered || allowMetered) && !testBypass &&
        (bufferedAheadMs >= 15_000 || fullyBuffered)

    fun missingBytes(
        contentLength: Long?, cachedBytes: Long, storedItag: Int?, resolvedItag: Int,
        budget: Long, freeSpace: Long,
    ): Long? {
        if (contentLength == null || contentLength <= 0 || contentLength > MAX_SONG_BYTES) return null
        if (cachedBytes > 0 && storedItag != resolvedItag) return null
        val missing = contentLength - cachedBytes.coerceIn(0, contentLength)
        return missing.takeIf { it <= budget && freeSpace >= it + FREE_SPACE_RESERVE }
    }
}

/** Walk the player's next-item order, never invent a second random order for caching. */
internal fun upcomingAudioIds(
    itemCount: Int, currentIndex: Int, count: Int,
    idAt: (Int) -> String, nextIndex: (Int) -> Int,
): List<String> {
    if (currentIndex !in 0 until itemCount || count <= 0) return emptyList()
    val visited = mutableSetOf(currentIndex)
    val ids = linkedSetOf<String>()
    val currentId = idAt(currentIndex)
    var index = currentIndex
    repeat(minOf(itemCount, 100)) {
        index = nextIndex(index)
        if (index !in 0 until itemCount || !visited.add(index)) return ids.toList()
        idAt(index).takeIf { it.isNotBlank() && it != currentId }?.let(ids::add)
        if (ids.size >= count.coerceAtMost(AudioPreloadPolicy.MAX_COUNT)) return ids.toList()
    }
    return ids.toList()
}
