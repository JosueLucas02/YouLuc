package com.arturo254.opentune.ui.screens.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.arturo254.opentune.constants.ArtistSortType
import com.arturo254.opentune.constants.PlaylistSortType
import com.arturo254.opentune.constants.SongSortType
import com.arturo254.opentune.db.MusicDatabase
import com.arturo254.opentune.db.entities.Artist
import com.arturo254.opentune.db.entities.Playlist
import com.arturo254.opentune.db.entities.Song
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UserProfileViewModel @Inject constructor(
    private val database: MusicDatabase,
) : ViewModel() {

    val totalHours = MutableStateFlow(0L)
    val totalMinutes = MutableStateFlow(0L)
    val recentSongs = MutableStateFlow<List<Song>?>(null)
    val playlists = MutableStateFlow<List<Playlist>?>(null)
    val topArtists = MutableStateFlow<List<Artist>?>(null)

    init {
        viewModelScope.launch {
            try {
                val allSongs = database.songs(SongSortType.CREATE_DATE, descending = true).first()
                val totalMs = allSongs.sumOf { it.song.totalPlayTime }
                totalHours.value = (totalMs / 3600000L)
                totalMinutes.value = (totalMs / 60000L) % 60

                recentSongs.value = database.events().first().mapNotNull { it.song }.distinctBy { it.id }.take(10)
                playlists.value = database.playlists(PlaylistSortType.CREATE_DATE, descending = true).first()
                topArtists.value = database.mostPlayedArtists(fromTimeStamp = 0L, limit = 10).first()
            } catch (_: Exception) {}
        }
    }
}