package com.arturo254.opentune.ui.screens.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import com.arturo254.opentune.R
import com.arturo254.opentune.constants.PlaybackDiagnosticsEnabledKey
import com.arturo254.opentune.playback.PlaybackDiagnostics
import com.arturo254.opentune.ui.component.PreferenceEntry
import com.arturo254.opentune.ui.component.PreferenceGroupTitle
import com.arturo254.opentune.ui.component.SwitchPreference
import com.arturo254.opentune.utils.rememberPreference
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun PlaybackDiagnosticPreferences() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val (enabled, onEnabledChange) = rememberPreference(PlaybackDiagnosticsEnabledKey, true)
    var busy by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) scope.launch {
            busy = true
            try {
                PlaybackDiagnostics.export(context, uri)
                Toast.makeText(context, R.string.playback_diagnostics_saved, Toast.LENGTH_LONG).show()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                Toast.makeText(context, R.string.playback_diagnostics_export_failed, Toast.LENGTH_LONG).show()
            } finally { busy = false }
        }
    }

    PreferenceGroupTitle(title = stringResource(R.string.playback_diagnostics_title))
    SwitchPreference(
        title = { Text(stringResource(R.string.playback_diagnostics_record)) },
        description = stringResource(R.string.playback_diagnostics_description),
        icon = { Icon(painterResource(R.drawable.info), null) },
        checked = enabled,
        onCheckedChange = onEnabledChange,
    )
    PreferenceEntry(
        title = { Text(stringResource(R.string.playback_diagnostics_export)) },
        description = stringResource(R.string.playback_diagnostics_export_description),
        icon = { Icon(painterResource(R.drawable.download), null) },
        isEnabled = !busy,
        onClick = {
            val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"))
            save.launch("OpenTune-playback-$stamp.zip")
        },
    )
    PreferenceEntry(
        title = { Text(stringResource(R.string.playback_diagnostics_clear)) },
        icon = { Icon(painterResource(R.drawable.delete), null) },
        isEnabled = !busy,
        onClick = { confirmClear = true },
    )
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text(stringResource(R.string.playback_diagnostics_clear)) },
        text = { Text(stringResource(R.string.playback_diagnostics_clear_confirm)) },
        confirmButton = {
            TextButton(onClick = {
                confirmClear = false
                scope.launch {
                    busy = true
                    try { PlaybackDiagnostics.clear() }
                    catch (cancelled: CancellationException) { throw cancelled }
                    catch (_: Exception) { Toast.makeText(context, R.string.playback_diagnostics_clear_failed, Toast.LENGTH_LONG).show() }
                    finally { busy = false }
                }
            }) { Text(stringResource(R.string.playback_diagnostics_clear)) }
        },
        dismissButton = {
            TextButton(onClick = { confirmClear = false }) { Text(stringResource(android.R.string.cancel)) }
        },
    )
}
