/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.arturo254.opentune.spotify

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import com.arturo254.opentune.spotify.models.SpotifyAlbum
import com.arturo254.opentune.spotify.models.SpotifyTrack
import com.arturo254.opentune.utils.reportException

import javax.inject.Inject

/**
 * Secciones de la pantalla de música de Spotify. Cada una se carga de forma
 * perezosa la primera vez que se abre.
 */
enum class SpotifyMusicSection {
    LIKED_SONGS,
    TOP_TRACKS,
    ALBUMS,
}

@HiltViewModel
class SpotifyLikedSongsViewModel
@Inject
constructor(
    private val repository: SpotifyLibraryRepository,
) : ViewModel() {
    private val _uiState = MutableStateFlow(SpotifyLikedSongsUiState())
    val uiState: StateFlow<SpotifyLikedSongsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            repository.restoreCachedLikedSongs()
            repository.restoreCachedSavedAlbums()
        }
        // "Me gusta" y álbumes se mantienen sincronizados con el repositorio,
        // de modo que dar/quitar me gusta se refleja al instante.
        viewModelScope.launch {
            repository.likedSongs.collect { tracks ->
                _uiState.update { it.copy(likedSongs = tracks) }
            }
        }
        viewModelScope.launch {
            repository.savedAlbums.collect { albums ->
                _uiState.update { it.copy(savedAlbums = albums) }
            }
        }
        refresh()
    }

    fun selectSection(section: SpotifyMusicSection) {
        if (_uiState.value.section == section) return
        _uiState.update { it.copy(section = section, errorMessage = null) }
        loadIfNeeded(section)
    }

    /** Recarga todas las secciones que ya se hayan mostrado al menos una vez. */
    fun refresh() {
        val state = _uiState.value
        loadLikedSongs()
        if (state.topTracksLoaded) loadTopTracks()
        if (state.savedAlbumsLoaded) loadSavedAlbums()
    }

    private fun loadIfNeeded(section: SpotifyMusicSection) {
        val state = _uiState.value
        when (section) {
            SpotifyMusicSection.LIKED_SONGS ->
                if (!state.likedSongsLoaded) loadLikedSongs()

            SpotifyMusicSection.TOP_TRACKS ->
                if (!state.topTracksLoaded) loadTopTracks()

            SpotifyMusicSection.ALBUMS ->
                if (!state.savedAlbumsLoaded) loadSavedAlbums()
        }
    }

    private fun loadLikedSongs() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            runCatching { repository.refreshLikedSongs() }
                .onSuccess {
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            likedSongsLoaded = true,
                            errorMessage = null,
                        )
                    }
                }
                .onFailure(::handleFailure)
        }
    }

    private fun loadTopTracks() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            runCatching { repository.topTracks() }
                .onSuccess { tracks ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            topTracks = tracks,
                            topTracksLoaded = true,
                            errorMessage = null,
                        )
                    }
                }
                .onFailure(::handleFailure)
        }
    }

    private fun loadSavedAlbums() {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            runCatching { repository.refreshSavedAlbums() }
                .onSuccess { albums ->
                    _uiState.update {
                        it.copy(
                            isLoading = false,
                            savedAlbumsLoaded = true,
                            errorMessage = null,
                        )
                    }
                }
                .onFailure(::handleFailure)
        }
    }

    /** Da o quita "me gusta" a una canción y refleja el cambio de inmediato. */
    fun toggleLike(track: SpotifyTrack) {
        val isLiked = _uiState.value.likedSongs.any { it.id == track.id }
        viewModelScope.launch(Dispatchers.IO) {
            if (isLiked) {
                repository.unlikeTrack(track)
            } else {
                repository.likeTrack(track)
            }
        }
    }

    /** Canciones de un álbum guardado, para reproducirlo. */
    suspend fun albumTracks(albumId: String): List<SpotifyTrack> =
        runCatching { repository.albumTracks(albumId) }
            .onFailure { error ->
                reportException(error)
                _uiState.update { it.copy(errorMessage = error.message) }
            }
            .getOrDefault(emptyList())

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    private fun handleFailure(error: Throwable) {
        reportException(error)
        _uiState.update {
            it.copy(
                isLoading = false,
                errorMessage = error.message,
            )
        }
    }
}

@Immutable
data class SpotifyLikedSongsUiState(
    val section: SpotifyMusicSection = SpotifyMusicSection.LIKED_SONGS,
    val likedSongs: List<SpotifyTrack> = emptyList(),
    val topTracks: List<SpotifyTrack> = emptyList(),
    val savedAlbums: List<SpotifyAlbum> = emptyList(),
    val likedSongsLoaded: Boolean = false,
    val topTracksLoaded: Boolean = false,
    val savedAlbumsLoaded: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
) {
    /** Ids de las canciones que ya están en "Me gusta". */
    val likedTrackIds: Set<String> = likedSongs.mapTo(HashSet()) { it.id }

    /** Canciones de la sección activa. La búsqueda se aplica en la pantalla. */
    fun tracksFor(section: SpotifyMusicSection): List<SpotifyTrack> =
        when (section) {
            SpotifyMusicSection.LIKED_SONGS -> likedSongs
            SpotifyMusicSection.TOP_TRACKS -> topTracks
            SpotifyMusicSection.ALBUMS -> emptyList()
        }
}
