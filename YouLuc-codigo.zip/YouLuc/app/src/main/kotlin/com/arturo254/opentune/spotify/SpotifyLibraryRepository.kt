/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.arturo254.opentune.spotify

import android.content.Context
import androidx.datastore.preferences.core.edit
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import com.arturo254.opentune.R
import com.arturo254.opentune.constants.SpotifyAccessTokenExpiresAtKey
import com.arturo254.opentune.constants.SpotifyAccessTokenKey
import com.arturo254.opentune.constants.SpotifyAccountAvatarUrlKey
import com.arturo254.opentune.constants.SpotifyAccountNameKey
import com.arturo254.opentune.constants.SpotifyLibraryAlbumsCacheKey
import com.arturo254.opentune.constants.SpotifyLibraryLikedSongsCacheKey
import com.arturo254.opentune.constants.SpotifyLibraryPlaylistsCacheKey
import com.arturo254.opentune.constants.SpotifySpDcKey
import com.arturo254.opentune.constants.SpotifySpKeyKey
import com.arturo254.opentune.spotify.models.SpotifyAlbum
import com.arturo254.opentune.spotify.models.SpotifyPlaylist
import com.arturo254.opentune.spotify.models.SpotifyPlaylistTracksRef
import com.arturo254.opentune.spotify.models.SpotifyTrack
import com.arturo254.opentune.utils.clearWebAuthSession
import com.arturo254.opentune.utils.dataStore
import com.arturo254.opentune.utils.reportException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SpotifyLibraryRepository
@Inject
constructor(
    @ApplicationContext private val context: Context,
) {
    private val _playlists = MutableStateFlow<List<SpotifyPlaylist>>(emptyList())
    val playlists: StateFlow<List<SpotifyPlaylist>> = _playlists.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    /** Canciones que el usuario guardó en "Me gusta" de Spotify. */
    private val _likedSongs = MutableStateFlow<List<SpotifyTrack>>(emptyList())
    val likedSongs: StateFlow<List<SpotifyTrack>> = _likedSongs.asStateFlow()

    /** Álbumes guardados en la biblioteca de Spotify. */
    private val _savedAlbums = MutableStateFlow<List<SpotifyAlbum>>(emptyList())
    val savedAlbums: StateFlow<List<SpotifyAlbum>> = _savedAlbums.asStateFlow()

    /** Última sesión conocida, para saber si hay cuenta conectada y su nombre. */
    private val _session = MutableStateFlow(SpotifyAccountSession())
    val session: StateFlow<SpotifyAccountSession> = _session.asStateFlow()

    suspend fun restoreCachedPlaylists() {
        withContext(Dispatchers.IO) {
            if (_playlists.value.isNotEmpty()) return@withContext
            val cached =
                context.dataStore.data
                    .first()[SpotifyLibraryPlaylistsCacheKey]
                    .orEmpty()
            if (cached.isBlank()) return@withContext
            runCatching {
                spotifyCacheJson.decodeFromString(
                    ListSerializer(SpotifyPlaylist.serializer()),
                    cached,
                )
            }.onSuccess { playlists ->
                _playlists.value = playlists
            }.onFailure { error ->
                reportException(error)
                context.dataStore.edit { prefs ->
                    prefs.remove(SpotifyLibraryPlaylistsCacheKey)
                }
            }
        }
    }

    suspend fun restoreSession(): SpotifyAccountSession {
        val session = resolveSession()
        _session.value = session
        return session
    }

    private suspend fun resolveSession(): SpotifyAccountSession =
        withContext(Dispatchers.IO) {
            val prefs = context.dataStore.data.first()
            val token = prefs[SpotifyAccessTokenKey].orEmpty()
            val expiresAt = prefs[SpotifyAccessTokenExpiresAtKey] ?: 0L
            val accountName = prefs[SpotifyAccountNameKey].orEmpty()
            val avatarUrl = prefs[SpotifyAccountAvatarUrlKey]

            if (token.isNotBlank() && expiresAt > System.currentTimeMillis() + TOKEN_EXPIRY_GRACE_MS) {
                Spotify.accessToken = token
                return@withContext SpotifyAccountSession(
                    isAuthenticated = true,
                    accountName = accountName,
                    accountAvatarUrl = avatarUrl,
                )
            }

            val spDc = prefs[SpotifySpDcKey].orEmpty()
            if (spDc.isBlank()) return@withContext SpotifyAccountSession()

            refreshAccessToken(spDc = spDc, spKey = prefs[SpotifySpKeyKey].orEmpty())
                .fold(
                    onSuccess = {
                        val refreshed = context.dataStore.data.first()
                        SpotifyAccountSession(
                            isAuthenticated = true,
                            accountName = refreshed[SpotifyAccountNameKey].orEmpty(),
                            accountAvatarUrl = refreshed[SpotifyAccountAvatarUrlKey],
                        )
                    },
                    onFailure = {
                        if (it is CancellationException) throw it
                        reportException(it)
                        SpotifyAccountSession()
                    },
                )
        }

    suspend fun connectWithCookies(
        spDc: String,
        spKey: String,
    ): SpotifyAccountSession =
        withContext(Dispatchers.IO) {
            context.dataStore.edit { prefs ->
                prefs[SpotifySpDcKey] = spDc
                prefs.remove(SpotifyLibraryPlaylistsCacheKey)
                if (spKey.isNotBlank()) {
                    prefs[SpotifySpKeyKey] = spKey
                } else {
                    prefs.remove(SpotifySpKeyKey)
                }
            }
            _playlists.value = emptyList()
            _likedSongs.value = emptyList()
            _savedAlbums.value = emptyList()
            _errorMessage.value = null
            refreshAccessToken(spDc = spDc, spKey = spKey).getOrThrow()
            val prefs = context.dataStore.data.first()
            SpotifyAccountSession(
                isAuthenticated = true,
                accountName = prefs[SpotifyAccountNameKey].orEmpty(),
                accountAvatarUrl = prefs[SpotifyAccountAvatarUrlKey],
            )
        }.also { _session.value = it }

    suspend fun logout() {
        withContext(Dispatchers.IO) {
            context.dataStore.edit { prefs ->
                prefs.remove(SpotifySpDcKey)
                prefs.remove(SpotifySpKeyKey)
                prefs.remove(SpotifyAccessTokenKey)
                prefs.remove(SpotifyAccessTokenExpiresAtKey)
                prefs.remove(SpotifyAccountNameKey)
                prefs.remove(SpotifyAccountAvatarUrlKey)
                prefs.remove(SpotifyLibraryPlaylistsCacheKey)
                prefs.remove(SpotifyLibraryLikedSongsCacheKey)
                prefs.remove(SpotifyLibraryAlbumsCacheKey)
            }
            _playlists.value = emptyList()
            _likedSongs.value = emptyList()
            _savedAlbums.value = emptyList()
            _errorMessage.value = null
            _session.value = SpotifyAccountSession()
            Spotify.accessToken = null
            runCatching { clearWebAuthSession(context) }
                .onFailure(::reportException)
        }
    }

    suspend fun refreshPlaylists(): List<SpotifyPlaylist> =
        withContext(Dispatchers.IO) {
            _isRefreshing.value = true
            _errorMessage.value = null
            try {
                ensureAuthenticated()
                refreshProfile()
                val loaded = fetchAllPlaylists()
                _playlists.value = loaded
                context.dataStore.edit { prefs ->
                    prefs[SpotifyLibraryPlaylistsCacheKey] =
                        spotifyCacheJson.encodeToString(
                            ListSerializer(SpotifyPlaylist.serializer()),
                            loaded,
                        )
                }
                loaded
            } catch (error: CancellationException) {
                throw error
            } catch (error: Throwable) {
                reportException(error)
                _errorMessage.value = error.message
                _playlists.value
            } finally {
                _isRefreshing.value = false
            }
        }

    suspend fun playlist(playlistId: String): SpotifyPlaylist =
        withContext(Dispatchers.IO) {
            ensureAuthenticated()
            spotifyCallWithTokenRetry {
                Spotify.playlist(playlistId).getOrThrow()
            }
        }

    suspend fun playlistTracks(playlistId: String): List<SpotifyTrack> =
        withContext(Dispatchers.IO) {
            ensureAuthenticated()
            val tracks = ArrayList<SpotifyTrack>()
            var offset = 0
            val limit = 50

            while (true) {
                val page =
                    spotifyCallWithTokenRetry {
                        Spotify
                            .playlistTracks(
                                playlistId = playlistId,
                                limit = limit,
                                offset = offset,
                            ).getOrThrow()
                    }
                if (page.items.isEmpty()) break
                val pageTracks =
                    page.items.mapNotNull { it.track?.takeUnless(SpotifyTrack::isLocal) }
                tracks += pageTracks
                offset += page.items.size
                if (offset >= page.total || page.items.size < limit) break
            }

            tracks
        }

    // ── Canciones que te gustan ──────────────────────────────────────────

    suspend fun restoreCachedLikedSongs() {
        withContext(Dispatchers.IO) {
            if (_likedSongs.value.isNotEmpty()) return@withContext
            val cached =
                context.dataStore.data
                    .first()[SpotifyLibraryLikedSongsCacheKey]
                    .orEmpty()
            if (cached.isBlank()) return@withContext
            runCatching {
                spotifyCacheJson.decodeFromString(
                    ListSerializer(SpotifyTrack.serializer()),
                    cached,
                )
            }.onSuccess { tracks ->
                _likedSongs.value = tracks
            }.onFailure { error ->
                reportException(error)
                context.dataStore.edit { prefs ->
                    prefs.remove(SpotifyLibraryLikedSongsCacheKey)
                }
            }
        }
    }

    suspend fun refreshLikedSongs(): List<SpotifyTrack> =
        withContext(Dispatchers.IO) {
            _isRefreshing.value = true
            _errorMessage.value = null
            try {
                ensureAuthenticated()
                val loaded =
                    fetchAllPages { limit, offset ->
                        val page =
                            spotifyCallWithTokenRetry {
                                Spotify.likedSongs(limit = limit, offset = offset).getOrThrow()
                            }
                        page.items to page.total
                    }.mapNotNull { saved -> saved.track.takeUnless(SpotifyTrack::isLocal) }

                _likedSongs.value = loaded
                persistLikedSongs(loaded)
                loaded
            } catch (error: CancellationException) {
                throw error
            } catch (error: Throwable) {
                reportException(error)
                _errorMessage.value = error.message
                _likedSongs.value
            } finally {
                _isRefreshing.value = false
            }
        }

    /**
     * Quita una canción de "Me gusta" tanto en Spotify como en la copia local.
     * @return `true` si Spotify confirmó la operación.
     */
    suspend fun unlikeTrack(track: SpotifyTrack): Boolean =
        withContext(Dispatchers.IO) {
            val uri = track.uri?.takeIf(String::isNotBlank) ?: "spotify:track:${track.id}"
            ensureAuthenticated()
            try {
                Spotify.removeFromLibrary(listOf(uri)).getOrThrow()
                val updated = _likedSongs.value.filterNot { it.id == track.id }
                _likedSongs.value = updated
                persistLikedSongs(updated)
                true
            } catch (error: CancellationException) {
                throw error
            } catch (error: Throwable) {
                reportException(error)
                _errorMessage.value = error.message
                false
            }
        }

    /**
     * Añade una canción a "Me gusta" tanto en Spotify como en la copia local.
     * @return `true` si Spotify confirmó la operación.
     */
    suspend fun likeTrack(track: SpotifyTrack): Boolean =
        withContext(Dispatchers.IO) {
            val uri = track.uri?.takeIf(String::isNotBlank) ?: "spotify:track:${track.id}"
            ensureAuthenticated()
            try {
                Spotify.addToLibrary(listOf(uri)).getOrThrow()
                val existing = _likedSongs.value
                if (existing.none { it.id == track.id }) {
                    val updated = listOf(track) + existing
                    _likedSongs.value = updated
                    persistLikedSongs(updated)
                }
                true
            } catch (error: CancellationException) {
                throw error
            } catch (error: Throwable) {
                reportException(error)
                _errorMessage.value = error.message
                false
            }
        }

    /** Canciones más escuchadas del usuario según Spotify. */
    suspend fun topTracks(
        timeRange: String = "medium_term",
        limit: Int = 50,
    ): List<SpotifyTrack> =
        withContext(Dispatchers.IO) {
            ensureAuthenticated()
            val page =
                spotifyCallWithTokenRetry {
                    Spotify
                        .topTracks(timeRange = timeRange, limit = limit, offset = 0)
                        .getOrThrow()
                }
            page.items.filterNot(SpotifyTrack::isLocal)
        }

    // ── Álbumes guardados ────────────────────────────────────────────────

    suspend fun restoreCachedSavedAlbums() {
        withContext(Dispatchers.IO) {
            if (_savedAlbums.value.isNotEmpty()) return@withContext
            val cached =
                context.dataStore.data
                    .first()[SpotifyLibraryAlbumsCacheKey]
                    .orEmpty()
            if (cached.isBlank()) return@withContext
            runCatching {
                spotifyCacheJson.decodeFromString(
                    ListSerializer(SpotifyAlbum.serializer()),
                    cached,
                )
            }.onSuccess { albums ->
                _savedAlbums.value = albums
            }.onFailure { error ->
                reportException(error)
                context.dataStore.edit { prefs ->
                    prefs.remove(SpotifyLibraryAlbumsCacheKey)
                }
            }
        }
    }

    suspend fun refreshSavedAlbums(): List<SpotifyAlbum> =
        withContext(Dispatchers.IO) {
            try {
                ensureAuthenticated()
                val loaded =
                    fetchAllPages { limit, offset ->
                        val page =
                            spotifyCallWithTokenRetry {
                                Spotify.savedAlbums(limit = limit, offset = offset).getOrThrow()
                            }
                        page.items to page.total
                    }.map { it.album }.filter { it.id.isNotBlank() }

                _savedAlbums.value = loaded
                persistSavedAlbums(loaded)
                loaded
            } catch (error: CancellationException) {
                throw error
            } catch (error: Throwable) {
                reportException(error)
                _errorMessage.value = error.message
                _savedAlbums.value
            }
        }

    /** Canciones de un álbum guardado, listas para reproducir. */
    suspend fun albumTracks(albumId: String): List<SpotifyTrack> =
        withContext(Dispatchers.IO) {
            ensureAuthenticated()
            val album =
                spotifyCallWithTokenRetry {
                    Spotify.album(albumId).getOrThrow()
                }
            album.tracks?.items.orEmpty().filterNot(SpotifyTrack::isLocal)
        }

    // ── Helpers internos ─────────────────────────────────────────────────

    /**
     * Recorre todas las páginas de un endpoint paginado de Spotify.
     * [fetchPage] devuelve los elementos crudos de la página y el total
     * reportado por la API, para poder calcular el siguiente offset.
     */
    private suspend fun <T> fetchAllPages(
        pageSize: Int = SPOTIFY_PAGE_SIZE,
        fetchPage: suspend (limit: Int, offset: Int) -> Pair<List<T>, Int>,
    ): List<T> {
        val items = ArrayList<T>()
        var offset = 0
        while (true) {
            val (page, total) = fetchPage(pageSize, offset)
            if (page.isEmpty()) break
            items += page
            offset += page.size
            if (offset >= total || page.size < pageSize) break
        }
        return items
    }

    private suspend fun persistLikedSongs(tracks: List<SpotifyTrack>) {
        context.dataStore.edit { prefs ->
            prefs[SpotifyLibraryLikedSongsCacheKey] =
                spotifyCacheJson.encodeToString(
                    ListSerializer(SpotifyTrack.serializer()),
                    tracks,
                )
        }
    }

    private suspend fun persistSavedAlbums(albums: List<SpotifyAlbum>) {
        context.dataStore.edit { prefs ->
            prefs[SpotifyLibraryAlbumsCacheKey] =
                spotifyCacheJson.encodeToString(
                    ListSerializer(SpotifyAlbum.serializer()),
                    albums,
                )
        }
    }

    private suspend fun ensureAuthenticated() {
        val prefs = context.dataStore.data.first()
        val token = prefs[SpotifyAccessTokenKey].orEmpty()
        val expiresAt = prefs[SpotifyAccessTokenExpiresAtKey] ?: 0L
        if (token.isNotBlank() && expiresAt > System.currentTimeMillis() + TOKEN_EXPIRY_GRACE_MS) {
            Spotify.accessToken = token
            return
        }

        val spDc = prefs[SpotifySpDcKey].orEmpty()
        if (spDc.isBlank()) {
            throw IllegalStateException(context.getString(R.string.spotify_not_connected))
        }
        refreshAccessToken(spDc = spDc, spKey = prefs[SpotifySpKeyKey].orEmpty()).getOrThrow()
    }

    private suspend fun refreshAccessToken(
        spDc: String,
        spKey: String,
    ): Result<Unit> =
        SpotifyAuth
            .fetchAccessToken(spDc = spDc, spKey = spKey)
            .mapCatching { token ->
                Spotify.accessToken = token.accessToken
                context.dataStore.edit { prefs ->
                    prefs[SpotifyAccessTokenKey] = token.accessToken
                    prefs[SpotifyAccessTokenExpiresAtKey] = token.accessTokenExpirationTimestampMs
                }
                refreshProfile()
            }

    private suspend fun refreshProfile() {
        Spotify
            .me()
            .onSuccess { user ->
                context.dataStore.edit { prefs ->
                    prefs[SpotifyAccountNameKey] = user.displayName.orEmpty()
                    user.images
                        .firstOrNull()
                        ?.url
                        ?.let { prefs[SpotifyAccountAvatarUrlKey] = it }
                        ?: prefs.remove(SpotifyAccountAvatarUrlKey)
                }
            }.onFailure { error ->
                if (error is CancellationException) throw error
            }
    }

    private suspend fun fetchAllPlaylists(): List<SpotifyPlaylist> =
        fetchAllPages { limit, offset ->
            val page =
                spotifyCallWithTokenRetry {
                    Spotify.myPlaylists(limit = limit, offset = offset).getOrThrow()
                }
            page.items to page.total
        }.map { playlist ->
            if (playlist.tracks?.total != null) {
                playlist
            } else {
                playlistTrackCount(playlist.id)
                    ?.let { playlist.copy(tracks = SpotifyPlaylistTracksRef(total = it)) }
                    ?: playlist
            }
        }

    private suspend fun playlistTrackCount(playlistId: String): Int? =
        try {
            spotifyCallWithTokenRetry {
                Spotify
                    .playlistTracks(
                        playlistId = playlistId,
                        limit = 1,
                        offset = 0,
                    ).getOrThrow()
            }.total
        } catch (error: CancellationException) {
            throw error
        } catch (error: Throwable) {
            reportException(error)
            null
        }

    private suspend fun <T> spotifyCallWithTokenRetry(block: suspend () -> T): T =
        runCatching { block() }
            .getOrElse { error ->
                if ((error as? Spotify.SpotifyException)?.statusCode != 401) throw error
                val prefs = context.dataStore.data.first()
                val spDc = prefs[SpotifySpDcKey].orEmpty()
                if (spDc.isBlank()) throw error
                refreshAccessToken(
                    spDc = spDc,
                    spKey = prefs[SpotifySpKeyKey].orEmpty()
                ).getOrThrow()
                block()
            }

    companion object {
        private const val TOKEN_EXPIRY_GRACE_MS = 60_000L
        private const val SPOTIFY_PAGE_SIZE = 50
        private val spotifyCacheJson =
            Json {
                ignoreUnknownKeys = true
                encodeDefaults = true
            }
    }
}

data class SpotifyAccountSession(
    val isAuthenticated: Boolean = false,
    val accountName: String = "",
    val accountAvatarUrl: String? = null,
)
