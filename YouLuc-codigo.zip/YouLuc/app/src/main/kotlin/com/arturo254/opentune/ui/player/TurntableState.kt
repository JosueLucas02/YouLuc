package com.arturo254.opentune.ui.player

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis

/**
 * Devuelve un `Float` que representa el ángulo de rotación del vinilo.
 * Se incrementa continuamente mientras [isPlaying] sea true.
 *
 * @param isPlaying Si la música está sonando.
 * @param degreesPerSecond Velocidad de rotación en grados por segundo (por defecto 33 RPM ≈ 198°/s).
 */
@Composable
fun rememberTurntableRotation(
    isPlaying: Boolean,
    degreesPerSecond: Float = 60f, // 33 RPM
): () -> Float {
    var rotation by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(isPlaying) {
        if (!isPlaying) return@LaunchedEffect
        var lastFrame = 0L
        while (true) {
            withFrameMillis { frameTime ->
                if (lastFrame != 0L) {
                    val deltaMs = frameTime - lastFrame
                    rotation = (rotation + degreesPerSecond * deltaMs / 1000f) % 360f
                }
                lastFrame = frameTime
            }
        }
    }
    return { rotation }
}