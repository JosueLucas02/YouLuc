/*
 * OpenTune Project Original (2026)
 * Arturo254 (github.com/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */



package com.arturo254.opentune.playback

import android.content.Context
import android.os.Bundle
import androidx.media3.common.PlaybackException
import androidx.media3.datasource.HttpDataSource
import com.arturo254.opentune.R
import java.io.InterruptedIOException
import java.net.SocketTimeoutException
import java.net.SocketException
import java.net.UnknownHostException

/**
 * Turns the raw exceptions thrown by Media3 into messages a human can act on.
 *
 * Media3 hides the real reason behind most stream failures and replaces it with a handful of
 * opaque placeholders ("Source error", "Remote error", "Unexpected runtime error"). The media
 * session forwards the exception message verbatim to every connected controller, which is why
 * "Source error" ends up on the Android Auto dashboard. Translate the error before forwarding it.
 */
object PlaybackErrorMessages {

    /** Marks the errors the app raises itself, whose message already explains what happened. */
    private const val EXTRA_FRIENDLY = "com.arturo254.opentune.playback.FRIENDLY_MESSAGE"

    /** Media3 placeholders that never explain what actually went wrong. */
    private val OPAQUE_MESSAGES = listOf(
        "source error",
        "remote error",
        "unexpected runtime error",
        "playback error",
        "internal error",
        "error occurred",
    )

    /** The reason a track could not be played. */
    enum class Kind {
        NO_INTERNET,
        TIMEOUT,
        RATE_LIMITED,
        SERVER,
        NO_STREAM,
        UNSUPPORTED_FORMAT,
        NO_ACCESS,
        GENERIC,
    }

    /**
     * Builds an exception whose message is safe to show to the user.
     *
     * The marker stored in the extras keeps the message alive when the exception travels
     * through the session and reaches a controller. The bundle has to be a dedicated one:
     * the constructor without extras shares the static [android.os.Bundle.EMPTY] instance
     * between every exception of the process.
     */
    fun create(
        message: String,
        cause: Throwable?,
        errorCode: Int,
    ): PlaybackException {
        val extras = Bundle().apply { putBoolean(EXTRA_FRIENDLY, true) }
        return PlaybackException(message, cause, errorCode, extras)
    }

    /** True when [error] was raised by the app and therefore carries a meaningful message. */
    fun isFriendly(error: PlaybackException): Boolean =
        error.extras?.getBoolean(EXTRA_FRIENDLY, false) == true

    /** True when [message] is one of Media3's placeholders instead of a real reason. */
    fun isOpaque(message: CharSequence?): Boolean {
        val text = message?.toString()?.trim().orEmpty()
        if (text.isEmpty()) return true
        return OPAQUE_MESSAGES.any { text.startsWith(it, ignoreCase = true) }
    }

    /** Walks the cause chain looking for the first exception that carries an HTTP status. */
    fun httpStatusCode(error: PlaybackException): Int? {
        return causes(error).filterIsInstance<HttpDataSource.InvalidResponseCodeException>()
            .firstOrNull()?.responseCode
    }

    /**
     * Classifies a failure out of the two pieces of information Media3 always provides: the
     * error code and the HTTP status of the response, when there was one.
     */
    fun kindOf(
        errorCode: Int,
        httpStatus: Int?,
        cause: Throwable? = null,
    ): Kind {
        val direct = when {
            errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED -> Kind.NO_INTERNET
            errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> Kind.TIMEOUT
            httpStatus == 429 -> Kind.RATE_LIMITED
            httpStatus != null && httpStatus in 500..599 -> Kind.SERVER
            httpStatus != null && httpStatus in setOf(403, 404, 410, 416) -> Kind.NO_STREAM
            errorCode in PARSING_ERROR_CODES -> Kind.UNSUPPORTED_FORMAT
            errorCode == PlaybackException.ERROR_CODE_IO_NO_PERMISSION -> Kind.NO_ACCESS
            else -> Kind.GENERIC
        }
        if (direct != Kind.GENERIC) return direct
        var nestedKind: Kind? = null
        for (nested in causes(cause)) {
            when (nested) {
                is SocketTimeoutException -> return Kind.TIMEOUT
                is InterruptedIOException -> if (nested.message?.let {
                    it.contains("timeout", ignoreCase = true) || it.contains("timed out", ignoreCase = true)
                } == true) return Kind.TIMEOUT
                is UnknownHostException, is SocketException -> return Kind.NO_INTERNET
                is PlaybackException -> {
                    val kind = kindOf(nested.errorCode, null)
                    if (nestedKind == null && kind != Kind.GENERIC) nestedKind = kind
                }
            }
        }
        return nestedKind ?: if (errorCode == PlaybackException.ERROR_CODE_REMOTE_ERROR) Kind.SERVER else Kind.GENERIC
    }

    fun kindOf(error: PlaybackException): Kind = kindOf(error.errorCode, httpStatusCode(error), error.cause)

    private fun causes(error: Throwable?): Sequence<Throwable> =
        generateSequence(error) { it.cause }.take(16)

    fun forController(context: Context, error: PlaybackException): PlaybackException =
        create(friendlyMessage(context, error), error, error.errorCode)

    /**
     * The message shown to the user for [error].
     *
     * Media3's own text is never returned unless the app produced it, so the opaque
     * placeholders can not leak into the interface.
     */
    fun friendlyMessage(
        context: Context,
        error: PlaybackException,
    ): String {
        // ExoPlayer wraps resolver failures in an opaque "Source error" exception.
        val ownMessage = causes(error).filterIsInstance<PlaybackException>()
            .firstOrNull { isFriendly(it) && !isOpaque(it.message) }?.message
        if (ownMessage != null) return ownMessage

        return context.getString(
            when (kindOf(error)) {
                Kind.NO_INTERNET -> R.string.error_no_internet
                Kind.TIMEOUT -> R.string.error_timeout
                Kind.RATE_LIMITED -> R.string.playback_error_rate_limited
                Kind.SERVER -> R.string.playback_error_server
                Kind.NO_STREAM -> R.string.error_no_stream
                Kind.UNSUPPORTED_FORMAT -> R.string.playback_error_unsupported_format
                Kind.NO_ACCESS -> R.string.playback_error_no_access
                Kind.GENERIC -> R.string.playback_error_source
            }
        )
    }

    private val PARSING_ERROR_CODES = setOf(
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
        PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
        PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED,
        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
        PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
    )
}
