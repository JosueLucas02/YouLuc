
/*
 * OpenTune Project Original (2026)
 * Arturo254 (codeberg.org/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */

package com.arturo254.opentune.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class Contributor(
    val avatarUrl: String,
    val name: String,
    val role: String,
    val profileUrl: String,
)

class AboutViewModel : ViewModel() {

    private val _contributors =
        MutableStateFlow<List<Contributor>>(emptyList())

    val contributors: StateFlow<List<Contributor>> =
        _contributors.asStateFlow()

    private val _isLoading = MutableStateFlow(true)

    val isLoading: StateFlow<Boolean> =
        _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)

    val error: StateFlow<String?> =
        _error.asStateFlow()

    private companion object {
        const val TAG = "AboutViewModel"

        const val CODEBERG_API_URL =
            "https://codeberg.org/api/v1/repos/Arturo254/OpenTune/commits"

        const val PAGE_SIZE = 50
        const val MAX_PAGES = 10

        const val CONNECTION_TIMEOUT = 10000
        const val READ_TIMEOUT = 10000
    }

    private data class ContributorData(
        val name: String,
        val avatarUrl: String,
        val profileUrl: String,
        var contributions: Int = 0,
    )

    init {
        fetchContributorsFromCodeberg()
    }

    /**
     * Fetch contributors from Codeberg.
     *
     * Codeberg uses Forgejo, which does not provide
     * the same contributors endpoint as GitHub.
     *
     * Contributors are therefore calculated from
     * the repository commit history.
     */
    fun fetchContributorsFromCodeberg() {
        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null

            try {
                val result = withContext(Dispatchers.IO) {
                    getCodebergContributors()
                }

                _contributors.value = result.ifEmpty {
                    getFallbackContributors()
                }

            } catch (e: Exception) {
                android.util.Log.e(
                    TAG,
                    "Failed to fetch Codeberg contributors",
                    e
                )

                _contributors.value = getFallbackContributors()
                _error.value = null

            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Retrieves commits from Codeberg and groups
     * them by their associated Codeberg account.
     */
    private fun getCodebergContributors(): List<Contributor> {

        val contributors =
            linkedMapOf<String, ContributorData>()

        for (page in 1..MAX_PAGES) {

            val url = URL(
                "$CODEBERG_API_URL?limit=$PAGE_SIZE&page=$page"
            )

            val connection =
                url.openConnection() as HttpURLConnection

            try {
                connection.requestMethod = "GET"

                connection.setRequestProperty(
                    "Accept",
                    "application/json"
                )

                connection.setRequestProperty(
                    "User-Agent",
                    "OpenTune-Android"
                )

                connection.connectTimeout = CONNECTION_TIMEOUT
                connection.readTimeout = READ_TIMEOUT

                val responseCode = connection.responseCode

                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw IOException(
                        "Codeberg API error: HTTP $responseCode"
                    )
                }

                val response = connection.inputStream
                    .bufferedReader()
                    .use { it.readText() }

                val commits = JSONArray(response)

                if (commits.length() == 0) {
                    break
                }

                for (i in 0 until commits.length()) {

                    val commit = commits.getJSONObject(i)

                    // Codeberg account associated with the commit.
                    val author = commit.optJSONObject("author")
                        ?: continue

                    val username = author.optString("login")
                        .takeIf { it.isNotBlank() }
                        ?: continue

                    val contributor = contributors.getOrPut(username) {

                        ContributorData(
                            name = username,

                            avatarUrl = author.optString("avatar_url")
                                .takeIf { it.isNotBlank() }
                                ?: "https://codeberg.org/avatars/1",

                            profileUrl = author.optString("html_url")
                                .takeIf { it.isNotBlank() }
                                ?: "https://codeberg.org/$username"
                        )
                    }

                    contributor.contributions++
                }

                // Stop when the last page is reached.
                if (commits.length() < PAGE_SIZE) {
                    break
                }

            } finally {
                connection.disconnect()
            }
        }

        return contributors.values
            .sortedByDescending { it.contributions }
            .map { contributor ->

                Contributor(
                    avatarUrl = contributor.avatarUrl,
                    name = contributor.name,
                    role = "${contributor.contributions} contributions",
                    profileUrl = contributor.profileUrl
                )
            }
    }

    /**
     * Fallback contributors displayed when Codeberg
     * is unavailable or no contributors are found.
     */
    private fun getFallbackContributors(): List<Contributor> {

        return listOf(

            Contributor(
                avatarUrl = "https://avatars.githubusercontent.com/u/87346871?v=4",
                name = "Arturo254",
                role = "Original Creator & App Owner",
                profileUrl = "https://codeberg.org/Arturo254",
            ),

            Contributor(
                avatarUrl = "https://avatars.githubusercontent.com/u/104271815?v=4",
                name = "Erorr40",
                role = "Maintainer & Updates",
                profileUrl = "https://codeberg.org/Erorr40",
            ),

            Contributor(
                avatarUrl = "https://avatars.githubusercontent.com/u/205341163?v=4",
                name = "ϟ Xamax-code",
                role = "Code Refactor",
                profileUrl = "https://codeberg.org/xamax-code",
            ),

            Contributor(
                avatarUrl = "https://avatars.githubusercontent.com/u/147309938?v=4",
                name = "「★」 RightSideUpCak3",
                role = "Feature Developer",
                profileUrl = "https://codeberg.org/RightSideUpCak3",
            ),
        )
    }
}
