/*
 * OpenTune Project Original (2026)
 * Arturo254 (github.com/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */

package com.arturo254.opentune.ui.screens

import android.annotation.SuppressLint
import android.net.Uri
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.datastore.preferences.core.edit
import androidx.navigation.NavController
import com.arturo254.opentune.LocalPlayerAwareWindowInsets
import com.arturo254.opentune.R
import com.arturo254.opentune.constants.*
import com.arturo254.opentune.innertube.YouTube
import com.arturo254.opentune.playback.PlaybackDiagnostics
import com.arturo254.opentune.ui.component.IconButton
import com.arturo254.opentune.ui.utils.backToMain
import com.arturo254.opentune.utils.dataStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch

const val LOGIN_ROUTE = "login"
const val LOGIN_URL_ARGUMENT = "url"

fun buildLoginRoute(startUrl: String? = null): String {
    val resolvedUrl = startUrl?.trim().takeUnless { it.isNullOrBlank() } ?: return LOGIN_ROUTE
    return "$LOGIN_ROUTE?$LOGIN_URL_ARGUMENT=${Uri.encode(resolvedUrl)}"
}

private val LOGIN_CONFIG_SCRIPT = """
    (function() {
        function value(key) {
            try {
                var current = window.ytcfg && window.ytcfg.get ? window.ytcfg.get(key) : null;
                if (current) return current;
                if (window.yt && window.yt.config_ && window.yt.config_[key]) return window.yt.config_[key];
                if (key === 'PO_TOKEN') {
                    var scripts = document.querySelectorAll('script');
                    for (var i = 0; i < scripts.length; i++) {
                        var match = scripts[i].textContent.match(/"PO_TOKEN"\s*:\s*"([^\"]+)"/);
                        if (match) return match[1];
                    }
                }
            } catch (e) {}
            return null;
        }
        return JSON.stringify({visitorData:value('VISITOR_DATA'), dataSyncId:value('DATASYNC_ID'), poToken:value('PO_TOKEN')});
    })()
""".trimIndent()

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(navController: NavController, startUrl: String? = null) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val scope = rememberCoroutineScope()
    val initialUrl = remember(startUrl) { YouTubeLoginState.startUrl(startUrl) }
    var webView by remember { mutableStateOf<WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var pageError by remember { mutableStateOf<Int?>(null) }
    var sessionError by remember { mutableStateOf<Int?>(null) }
    var accountVerified by remember { mutableStateOf(false) }
    var savingSession by remember { mutableStateOf(false) }
    var attempt by remember { mutableIntStateOf(0) }
    var pageGeneration by remember { mutableIntStateOf(0) }
    var lastCookieAttempt by remember { mutableStateOf<String?>(null) }
    var sessionJob by remember { mutableStateOf<Job?>(null) }

    fun retry() {
        lastCookieAttempt = null
        pageError = null
        sessionError = null
        accountVerified = false
        val view = webView
        if (view != null) view.reload() else attempt++
    }

    fun captureSession(view: WebView, result: String?) {
        if (webView !== view || !YouTubeLoginState.isYouTubePage(view.url)) return
        val manager = CookieManager.getInstance()
        val cookie = YouTubeLoginState.mergeCookies(listOf(
            manager.getCookie("https://music.youtube.com"),
            manager.getCookie("https://www.youtube.com"),
            manager.getCookie("https://youtube.com"),
        ))
        if (!YouTubeLoginState.hasAuthentication(cookie)) return
        if (cookie == lastCookieAttempt && (accountVerified || sessionJob?.isActive == true)) return
        val config = YouTubeLoginState.pageConfig(result)
        val generation = pageGeneration
        lastCookieAttempt = cookie
        sessionJob?.cancel()
        sessionJob = scope.launch {
            savingSession = true
            sessionError = null
            try {
                // Set the client before publishing preferences: account observers must use
                // the new credentials rather than race the application's preference collector.
                if (YouTubeLoginState.authenticationCookie(YouTube.cookie) != YouTubeLoginState.authenticationCookie(cookie)) {
                    YouTube.dataSyncId = null
                    YouTube.poToken = null
                }
                YouTube.cookie = cookie
                config?.visitorData?.let { YouTube.visitorData = it }
                config?.dataSyncId?.let { YouTube.dataSyncId = YouTubeLoginState.accountDataSyncId(it) }
                context.dataStore.edit { prefs ->
                    if (YouTubeLoginState.authenticationCookie(prefs[InnerTubeCookieKey]) != YouTubeLoginState.authenticationCookie(cookie)) {
                        prefs.remove(AccountNameKey)
                        prefs.remove(AccountEmailKey)
                        prefs.remove(AccountChannelHandleKey)
                        prefs.remove(DataSyncIdKey)
                        prefs.remove(PoTokenKey)
                    }
                    prefs[InnerTubeCookieKey] = requireNotNull(cookie)
                    config?.visitorData?.let { prefs[VisitorDataKey] = it }
                    config?.dataSyncId?.let { prefs[DataSyncIdKey] = it }
                    config?.poToken?.let { prefs[PoTokenKey] = it }
                }
                manager.flush()
                val account = YouTube.accountInfo().getOrThrow()
                ensureActive()
                context.dataStore.edit { prefs ->
                    if (prefs[InnerTubeCookieKey] == cookie) {
                        prefs[AccountNameKey] = account.name
                        prefs[AccountEmailKey] = account.email.orEmpty()
                        prefs[AccountChannelHandleKey] = account.channelHandle.orEmpty()
                    }
                }
                if (generation != pageGeneration || webView !== view) return@launch
                accountVerified = true
                PlaybackDiagnostics.record("login_account_verified")
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                sessionError = R.string.login_session_failed
                PlaybackDiagnostics.record("login_session_failed", error = error)
            } finally {
                if (generation == pageGeneration) savingSession = false
            }
        }
    }

    LaunchedEffect(accountVerified) {
        if (accountVerified) {
            navController.navigateUp()
        }
    }

    Column(Modifier.fillMaxSize().windowInsetsPadding(
        LocalPlayerAwareWindowInsets.current.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom)
    )) {
        TopAppBar(
            title = { Text(stringResource(R.string.login)) },
            navigationIcon = {
                IconButton(onClick = navController::navigateUp, onLongClick = navController::backToMain) {
                    Icon(painterResource(R.drawable.arrow_back), contentDescription = stringResource(android.R.string.cancel))
                }
            },
            actions = {
                if (accountVerified) TextButton(onClick = { navController.navigateUp() }) {
                    Text(stringResource(R.string.login_done))
                }
            },
            windowInsets = WindowInsets.safeDrawing.only(WindowInsetsSides.Top),
        )
        if (progress < 100 && pageError == null) LinearProgressIndicator(
            progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(),
        )
        if (accountVerified || sessionError != null || savingSession) Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(stringResource(sessionError ?: if (accountVerified) R.string.login_connected else R.string.loading),
                modifier = Modifier.weight(1f))
            if (sessionError != null) TextButton(onClick = ::retry) { Text(stringResource(R.string.retry)) }
        }
        Box(Modifier.fillMaxWidth().weight(1f)) {
            key(attempt, initialUrl) {
                AndroidView<View>(
                    modifier = Modifier.fillMaxSize(),
                    factory = { viewContext ->
                        try {
                            WebView(viewContext).apply {
                                webView = this
                                val manager = CookieManager.getInstance()
                                manager.setAcceptCookie(true)
                                manager.setAcceptThirdPartyCookies(this, true)
                                settings.apply {
                                    javaScriptEnabled = true
                                    domStorageEnabled = true
                                    databaseEnabled = true
                                    allowFileAccess = false
                                    allowContentAccess = false
                                    setSupportZoom(true)
                                    builtInZoomControls = true
                                    displayZoomControls = false
                                    userAgentString = userAgentString
                                        .replace("; wv", "")
                                        .replace("Version/4.0 ", "")
                                }
                                webChromeClient = object : WebChromeClient() {
                                    override fun onProgressChanged(view: WebView, newProgress: Int) { progress = newProgress }
                                }
                                webViewClient = object : WebViewClient() {
                                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                                        if (!request.isForMainFrame || YouTubeLoginState.allowsNavigation(request.url.toString())) return false
                                        if (request.hasGesture() && request.url.scheme in listOf("http", "https")) {
                                            runCatching { uriHandler.openUri(request.url.toString()) }
                                        }
                                        return true
                                    }

                                    override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                                        pageGeneration++
                                        sessionJob?.cancel()
                                        accountVerified = false
                                        savingSession = false
                                        sessionError = null
                                        pageError = null
                                        progress = 0
                                        canGoBack = view.canGoBack()
                                    }

                                    override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                                        canGoBack = view.canGoBack()
                                    }

                                    override fun onPageFinished(view: WebView, url: String?) {
                                        canGoBack = view.canGoBack()
                                        progress = 100

                                        val manager = CookieManager.getInstance()
                                        val cookie = YouTubeLoginState.mergeCookies(listOf(
                                            manager.getCookie("https://music.youtube.com"),
                                            manager.getCookie("https://www.youtube.com"),
                                            manager.getCookie("https://youtube.com"),
                                        ))

                                        // If login completed and credentials exist, ensure we land on YouTube Music
                                        if (YouTubeLoginState.hasAuthentication(cookie) && !YouTubeLoginState.isYouTubePage(url)) {
                                            view.loadUrl("https://music.youtube.com")
                                            return
                                        }

                                        if (!YouTubeLoginState.isYouTubePage(url)) return
                                        val generation = pageGeneration
                                        view.evaluateJavascript(LOGIN_CONFIG_SCRIPT) { result ->
                                            if (generation == pageGeneration) captureSession(view, result)
                                        }
                                    }

                                    override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                                        if (!request.isForMainFrame) return
                                        pageError = R.string.login_page_failed
                                        PlaybackDiagnostics.record("login_page_failed", mapOf("error_code" to error.errorCode))
                                    }

                                    override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, response: WebResourceResponse) {
                                        if (!request.isForMainFrame) return
                                        PlaybackDiagnostics.record("login_http_error", mapOf("http_status" to response.statusCode))
                                        // Leave provider refusal/challenge pages visible so their explanation is readable.
                                        if (response.statusCode >= 500) pageError = R.string.login_page_failed
                                    }
                                }
                                loadUrl(initialUrl)
                            }
                        } catch (error: Exception) {
                            webView = null
                            pageError = R.string.login_page_failed
                            PlaybackDiagnostics.record("login_webview_unavailable", error = error)
                            FrameLayout(viewContext)
                        }
                    },
                    onRelease = { view ->
                        if (view is WebView) {
                            if (webView === view) webView = null
                            pageGeneration++
                            view.stopLoading()
                            view.destroy()
                        }
                    },
                )
            }
            if (pageError != null) Surface(Modifier.fillMaxSize()) {
                Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(stringResource(requireNotNull(pageError)))
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = ::retry) { Text(stringResource(R.string.retry)) }
                }
            }
        }
    }
    BackHandler(enabled = canGoBack) { webView?.goBack() }
}
