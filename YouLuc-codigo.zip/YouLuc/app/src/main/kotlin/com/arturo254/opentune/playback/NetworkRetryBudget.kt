package com.arturo254.opentune.playback

/** A retry budget survives repeated failures until playback succeeds or the user changes intent. */
internal class NetworkRetryBudget {
    private var trackId: String? = null
    private var attempts = 0

    fun delayMs(mediaId: String): Long? {
        if (trackId != mediaId) {
            trackId = mediaId
            attempts = 0
        }
        return DELAYS.getOrNull(attempts)
    }

    fun recordAttempt(mediaId: String) {
        check(trackId == mediaId)
        attempts++
    }

    fun reset() {
        trackId = null
        attempts = 0
    }

    private companion object {
        val DELAYS = longArrayOf(1_000, 2_000, 4_000, 8_000)
    }
}

internal fun canRetryNetworkPlayback(
    expectedId: String,
    currentId: String?,
    playWhenReady: Boolean,
    isIdle: Boolean,
    hasError: Boolean,
) = expectedId == currentId && playWhenReady && isIdle && hasError
