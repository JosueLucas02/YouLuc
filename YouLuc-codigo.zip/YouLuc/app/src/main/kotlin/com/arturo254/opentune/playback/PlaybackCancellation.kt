package com.arturo254.opentune.playback

import java.io.InterruptedIOException
import java.util.concurrent.CancellationException

internal fun rethrowPlaybackCancellation(error: Throwable) {
    // A skipped track's cancelled loader must not start another source or publish a new error.
    for (cause in generateSequence(error) { it.cause }.take(16)) {
        if (cause.isCancellationSignal() || cause is Error) throw cause
    }
}

internal fun isCancelledPlaybackLoad(error: Throwable) =
    generateSequence(error) { it.cause }.take(16).any { it.isCancellationSignal() }

private fun Throwable.isCancellationSignal() =
    this is CancellationException || this is InterruptedException ||
        (this is InterruptedIOException && Thread.currentThread().isInterrupted)

/** Result-based source fallback must keep coroutine cancellation and fatal errors out of retries. */
internal inline fun <T> playbackRunCatching(block: () -> T): Result<T> = try {
    Result.success(block())
} catch (error: Throwable) {
    rethrowPlaybackCancellation(error)
    Result.failure(error)
}
