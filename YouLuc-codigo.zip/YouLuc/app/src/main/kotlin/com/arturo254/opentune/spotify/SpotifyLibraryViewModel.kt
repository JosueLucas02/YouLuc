/*
 * ArchiveTune (2026)
 * © Rukamori — github.com/rukamori
 * GPL-3.0 License | Contributors: see git history
 * Do not remove or alter this notice. - Per GPL-3.0 Section 4 & Section 5
 */

package com.arturo254.opentune.spotify

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.arturo254.opentune.spotify.models.SpotifyAlbum
import com.arturo254.opentune.spotify.models.SpotifyPlaylist
import com.arturo254.opentune.spotify.models.SpotifyTrack
import javax.inject.Inject

@HiltViewModel
class SpotifyLibraryViewModel
@Inject
constructor(
    private val repository: SpotifyLibraryRepository,
) : ViewModel() {
    val playlists: StateFlow<List<SpotifyPlaylist>> =
        repository.playlists.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    /** Canciones que te gustan, para la tarjeta destacada de acceso. */
    val likedSongs: StateFlow<List<SpotifyTrack>> =
        repository.likedSongs.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    /** Álbumes guardados, usados por la pantalla de la música que te gusta. */
    val savedAlbums: StateFlow<List<SpotifyAlbum>> =
        repository.savedAlbums.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    /** Última sesión conocida, para saber si hay una cuenta conectada. */
    val session: StateFlow<SpotifyAccountSession> =
        repository.session.stateIn(viewModelScope, SharingStarted.Lazily, SpotifyAccountSession())

    val isRefreshing: StateFlow<Boolean> =
        repository.isRefreshing.stateIn(viewModelScope, SharingStarted.Lazily, false)

    val errorMessage: StateFlow<String?> =
        repository.errorMessage.stateIn(viewModelScope, SharingStarted.Lazily, null)

    init {
        viewModelScope.launch(Dispatchers.IO) {
            repository.restoreCachedPlaylists()
            repository.restoreCachedLikedSongs()
            repository.restoreCachedSavedAlbums()
            repository.restoreSession()
        }
    }

    fun refreshPlaylists() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.refreshPlaylists()
        }
    }

    /** Recarga listas, "me gusta" y álbumes guardados de una sola vez. */
    fun refreshAll() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.refreshPlaylists()
            repository.refreshLikedSongs()
            repository.refreshSavedAlbums()
        }
    }
}
