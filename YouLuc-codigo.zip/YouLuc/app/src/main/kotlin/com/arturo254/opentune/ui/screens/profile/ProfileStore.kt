package com.arturo254.opentune.ui.screens.profile

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.arturo254.opentune.utils.dataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File

object ProfileStore {
    private const val PhotoPrefix = "profile_pic_"
    private val UsernameKey = stringPreferencesKey("profile_username")
    private val PhotoKey = stringPreferencesKey("profile_photo")
    private val JoinDateKey = stringPreferencesKey("profile_join_date")

    fun copyPhoto(context: Context, uri: Uri): String? = runCatching {
        val file = File(context.filesDir, "$PhotoPrefix${System.currentTimeMillis()}.jpg")
        context.contentResolver.openInputStream(uri)!!.use { input ->
            file.outputStream().use { input.copyTo(it) }
        }
        file.absolutePath
    }.getOrNull()

    suspend fun save(context: Context, name: String, photo: Uri?) = withContext(NonCancellable + Dispatchers.IO) {
        val app = context.applicationContext
        val newPath = photo?.let { copyPhoto(app, it) }
        var oldPath: String? = null
        app.dataStore.edit { prefs ->
            prefs[UsernameKey] = name
            if (newPath != null) {
                oldPath = prefs[PhotoKey]
                prefs[PhotoKey] = newPath
            }
            if (prefs[JoinDateKey] == null) {
                prefs[JoinDateKey] = "joined at 14 nov 2026" // Fecha fija de ejemplo
            }
        }
        oldPath?.let { path ->
            val f = File(path)
            if (f.parentFile == app.filesDir && f.name.startsWith(PhotoPrefix)) f.delete()
        }
    }

    suspend fun load(context: Context): Triple<String, String?, String> = withContext(Dispatchers.IO) {
        val prefs = context.applicationContext.dataStore.data.first()
        val name = prefs[UsernameKey] ?: "Arturo254"
        val photo = prefs[PhotoKey]
        val joinDate = prefs[JoinDateKey] ?: "joined at 14 nov 2026"
        Triple(name, photo, joinDate)
    }
}