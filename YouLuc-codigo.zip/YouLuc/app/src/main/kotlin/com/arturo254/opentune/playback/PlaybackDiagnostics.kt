package com.arturo254.opentune.playback

import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import com.arturo254.opentune.BuildConfig
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.serialization.json.*
import java.io.File
import java.time.Instant
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong

/** Local-only diagnostics, enabled in both debug and release builds by the user preference. */
object PlaybackDiagnostics {
    private sealed interface Write {
        data class Event(val line: String, val timeMs: Long, val incident: Boolean) : Write
        data class Flush(val done: CompletableDeferred<Unit>) : Write
    }
    private val writes = Channel<Write>(128)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val dropped = AtomicLong()
    private val sessionId = UUID.randomUUID().toString()
    @Volatile private var store: PlaybackDiagnosticStore? = null
    @Volatile private var enabled = false
    val isEnabled: Boolean get() = enabled
    @Volatile private var lastWriteFailure: String? = null

    fun init(context: Context) {
        if (store != null) return
        store = PlaybackDiagnosticStore(File(context.noBackupFilesDir, "playback-diagnostics"))
        scope.launch {
            for (write in writes) {
                when (write) {
                    is Write.Flush -> write.done.complete(Unit)
                    is Write.Event -> try {
                        store?.append(write.line, write.timeMs, write.incident)
                    } catch (error: Exception) {
                        dropped.incrementAndGet()
                        lastWriteFailure = DiagnosticRedactor.redact(error.message ?: error.javaClass.simpleName)
                    }
                }
            }
        }
    }

    fun setEnabled(value: Boolean) {
        if (value == enabled) return
        if (!value) record("logging_disabled")
        enabled = value
        if (value) record("logging_enabled", mapOf(
            "app_version" to BuildConfig.VERSION_NAME, "version_code" to BuildConfig.VERSION_CODE,
            "build_type" to BuildConfig.BUILD_TYPE, "sdk" to Build.VERSION.SDK_INT,
            "android" to Build.VERSION.RELEASE, "manufacturer" to Build.MANUFACTURER,
            "model" to Build.MODEL,
        ))
    }

    fun record(event: String, fields: Map<String, Any?> = emptyMap(), error: Throwable? = null, incident: Boolean = false) {
        if (!enabled || store == null) return
        runCatching {
            val now = System.currentTimeMillis()
            val line = buildJsonObject {
                put("utc", Instant.ofEpochMilli(now).toString())
                put("elapsed_ms", SystemClock.elapsedRealtime())
                put("session", sessionId)
                put("event", event.take(80))
                put("thread", DiagnosticRedactor.redact(Thread.currentThread().name))
                putJsonObject("fields") {
                    for ((key, value) in fields.entries.take(32)) {
                        val safe = DiagnosticRedactor.field(key, value)
                        put(key.take(80), when (safe) {
                            null -> JsonNull
                            is Boolean -> JsonPrimitive(safe)
                            is Number -> JsonPrimitive(safe)
                            else -> JsonPrimitive(safe.toString())
                        })
                    }
                }
                if (error != null) {
                    put("exception", DiagnosticRedactor.redact(error.stackTraceToString()).take(8_000))
                    putJsonArray("causes") {
                        for (cause in generateSequence(error) { it.cause }.take(16)) {
                            add(buildJsonObject {
                                put("type", cause.javaClass.name)
                                put("message", DiagnosticRedactor.redact(cause.message.orEmpty()).take(512))
                            })
                        }
                    }
                }
            }.toString()
            if (!writes.trySend(Write.Event(line, now, incident)).isSuccess) dropped.incrementAndGet()
        }.onFailure { dropped.incrementAndGet() }
    }

    private suspend fun flush() = withTimeout(5_000L) {
        val done = CompletableDeferred<Unit>()
        writes.send(Write.Flush(done))
        done.await()
    }

    suspend fun export(context: Context, destination: Uri) = withContext(Dispatchers.IO) {
        flush()
        val journal = store ?: error("Playback diagnostics are not initialized")
        val metadata = buildString {
            appendLine("OpenTune playback diagnostics")
            appendLine("Exported: ${Instant.now()}")
            appendLine("App: ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE}), ${BuildConfig.BUILD_TYPE}")
            appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}, SDK ${Build.VERSION.SDK_INT}")
            appendLine("Recording enabled: $enabled")
            appendLine("Dropped events in this process: ${dropped.get()}")
            appendLine("Last write failure: ${lastWriteFailure ?: "none"}")
            appendLine("events-2, events-1, events-0 are chronological journal files (oldest first).")
            appendLine("last-incident contains the most recent error episode and up to two minutes of subsequent events, subject to size limits.")
            appendLine("Logs contain track IDs and playback state. Credentials and URL paths/queries are redacted; no account database is included.")
        }
        context.contentResolver.openOutputStream(destination)?.use { journal.export(it, metadata) }
            ?: error("Cannot open the selected destination")
    }

    suspend fun clear() = withContext(Dispatchers.IO) {
        flush()
        store?.clear()
        dropped.set(0)
        lastWriteFailure = null
        record("logs_cleared")
    }

    fun recordFatal(thread: Thread, error: Throwable) {
        record("app_crash", mapOf("crashed_thread" to thread.name), error, incident = true)
        if (enabled) runCatching { runBlocking { withTimeout(1_000) { flush() } } }
    }
}
