/*
 * OpenTune Project Original (2026)
 * Arturo254 (codeberg.org/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */

package com.arturo254.opentune.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import androidx.datastore.preferences.core.edit
import com.arturo254.opentune.BuildConfig
import com.arturo254.opentune.App
import com.arturo254.opentune.constants.GitHubReleasesEtagKey
import com.arturo254.opentune.constants.GitHubReleasesFingerprintKey
import com.arturo254.opentune.constants.GitHubReleasesJsonKey
import com.arturo254.opentune.constants.GitHubReleasesLastCheckedAtKey
import com.arturo254.opentune.constants.UpdateChannel
import com.arturo254.opentune.constants.UpdateChannelKey
import io.ktor.client.HttpClient
import io.ktor.client.call.body


import io.ktor.client.request.get
import io.ktor.client.request.headers
import io.ktor.client.request.prepareGet
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsChannel
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentLength
import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.readAvailable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

private const val CODEBERG_API_BASE = "https://codeberg.org/api/v1/repos/Arturo254/OpenTune"
private const val CODEBERG_REPO_URL = "https://codeberg.org/Arturo254/OpenTune"

data class GitCommit(
    val sha: String,
    val message: String,
    val author: String,
    val date: String,
    val url: String
)

data class ReleaseInfo(
    val tagName: String,
    val name: String,
    val body: String?,
    val publishedAt: String,
    val htmlUrl: String
)

data class NightlyInfo(
    val versionName: String,
    val apkUrl: String,
    val changelog: String?,
    val publishedAt: String
)

data class UpdateInfo(
    val tagName: String,
    val versionName: String,
    val downloadUrl: String,
    val releasePageUrl: String,
    val releaseNotes: String?,
    val publishedAt: String,
)

private const val APK_ASSET_NAME = "app-universal-release.apk"
private const val NIGHTLY_JSON_URL = "https://pub-2218e6bbd5b948e1b5d882cf4d92086d.r2.dev/update.json"

private data class ReleasesNetworkResult(
    val status: HttpStatusCode,
    val body: String?,
    val etag: String?,
)

object Updater {
    private val client = HttpClient()
    private const val ReleaseCacheCheckIntervalMs: Long = 6 * 60 * 60 * 1000L
    var lastCheckTime = -1L
        private set

    private var cachedNightlyInfo: NightlyInfo? = null

    private data class SemVer(
        val major: Int,
        val minor: Int,
        val patch: Int,
        val preRelease: List<PreReleaseIdentifier>,
    ) : Comparable<SemVer> {
        override fun compareTo(other: SemVer): Int {
            val majorCompare = major.compareTo(other.major)
            if (majorCompare != 0) return majorCompare
            val minorCompare = minor.compareTo(other.minor)
            if (minorCompare != 0) return minorCompare
            val patchCompare = patch.compareTo(other.patch)
            if (patchCompare != 0) return patchCompare

            val thisIsStable = preRelease.isEmpty()
            val otherIsStable = other.preRelease.isEmpty()
            if (thisIsStable && !otherIsStable) return 1
            if (!thisIsStable && otherIsStable) return -1

            val maxIndex = minOf(preRelease.size, other.preRelease.size)
            for (i in 0 until maxIndex) {
                val c = preRelease[i].compareTo(other.preRelease[i])
                if (c != 0) return c
            }
            return preRelease.size.compareTo(other.preRelease.size)
        }

        fun normalizedName(): String =
            if (preRelease.isEmpty()) {
                "$major.$minor.$patch"
            } else {
                "$major.$minor.$patch-" + preRelease.joinToString(".") { it.raw }
            }
    }

    private sealed interface PreReleaseIdentifier : Comparable<PreReleaseIdentifier> {
        val raw: String
    }

    private data class NumericIdentifier(
        override val raw: String,
        val value: Long,
    ) : PreReleaseIdentifier {
        override fun compareTo(other: PreReleaseIdentifier): Int =
            when (other) {
                is NumericIdentifier -> value.compareTo(other.value)
                is AlphaIdentifier -> -1
            }
    }

    private data class AlphaIdentifier(
        override val raw: String,
    ) : PreReleaseIdentifier {
        override fun compareTo(other: PreReleaseIdentifier): Int =
            when (other) {
                is NumericIdentifier -> 1
                is AlphaIdentifier -> raw.compareTo(other.raw)
            }
    }

    private val semVerRegex =
        Regex("""(?i)\bv?(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?\b""")

    private fun parseSemVerOrNull(text: String): SemVer? {
        val match = semVerRegex.find(text) ?: return null
        val major = match.groupValues.getOrNull(1)?.toIntOrNull() ?: return null
        val minor = match.groupValues.getOrNull(2)?.toIntOrNull() ?: return null
        val patch = match.groupValues.getOrNull(3)?.toIntOrNull() ?: return null
        val preReleaseText = match.groupValues.getOrNull(4)?.takeIf { it.isNotBlank() }
        val preRelease =
            preReleaseText
                ?.split('.')
                ?.filter { it.isNotBlank() }
                ?.map { identifier ->
                    if (identifier.all { it.isDigit() }) {
                        NumericIdentifier(raw = identifier, value = identifier.toLong())
                    } else {
                        AlphaIdentifier(raw = identifier)
                    }
                }
                ?: emptyList()
        return SemVer(
            major = major,
            minor = minor,
            patch = patch,
            preRelease = preRelease,
        )
    }

    private fun parseReleaseSemVerOrNull(release: ReleaseInfo): SemVer? =
        parseSemVerOrNull(release.tagName) ?: parseSemVerOrNull(release.name)

    internal fun isSameVersion(a: String, b: String): Boolean {
        val aSemVer = parseSemVerOrNull(a)
        val bSemVer = parseSemVerOrNull(b)
        return if (aSemVer != null && bSemVer != null) {
            aSemVer.major == bSemVer.major &&
                    aSemVer.minor == bSemVer.minor &&
                    aSemVer.patch == bSemVer.patch &&
                    aSemVer.preRelease == bSemVer.preRelease
        } else {
            a.trim() == b.trim()
        }
    }

    internal fun isNewerVersion(latest: String, current: String): Boolean {
        val latestSemVer = parseSemVerOrNull(latest)
        val currentSemVer = parseSemVerOrNull(current)
        return if (latestSemVer != null && currentSemVer != null) {
            latestSemVer > currentSemVer
        } else {
            !isSameVersion(latest, current)
        }
    }

    internal fun findLatestRelease(releases: List<ReleaseInfo>): ReleaseInfo? {
        if (releases.isEmpty()) return null
        val parsed =
            releases.mapNotNull { release ->
                parseReleaseSemVerOrNull(release)?.let { version -> version to release }
            }

        if (parsed.isEmpty()) return releases.firstOrNull()

        val stable = parsed.filter { it.first.preRelease.isEmpty() }
        val candidates = stable.ifEmpty { parsed }
        return candidates.maxWithOrNull(compareBy({ it.first }, { it.second.publishedAt }))?.second
    }

    private fun preferredReleaseVersionNameOrNull(release: ReleaseInfo): String? =
        parseReleaseSemVerOrNull(release)?.normalizedName()

    private fun parseReleasesJson(json: String): List<ReleaseInfo> {
        val jsonArray = JSONArray(json)
        val releases = ArrayList<ReleaseInfo>(jsonArray.length())
        for (i in 0 until jsonArray.length()) {
            val item = jsonArray.getJSONObject(i)
            releases.add(
                ReleaseInfo(
                    tagName = item.optString("tag_name", ""),
                    name = item.optString("name", ""),
                    body = if (item.has("body")) item.optString("body") else null,
                    publishedAt = item.optString("published_at", ""),
                    htmlUrl = item.optString("html_url", "")
                )
            )
        }
        return releases
    }

    private fun getTopReleaseFingerprint(releases: List<ReleaseInfo>): String {
        val latest = findLatestRelease(releases) ?: return ""
        return listOf(
            latest.tagName,
            latest.name,
            latest.publishedAt,
            latest.body.orEmpty(),
            latest.htmlUrl,
        ).joinToString("||")
    }


    private suspend fun fetchReleasesNetwork(
        perPage: Int,
        cachedEtag: String?,
    ): ReleasesNetworkResult {
        val response: HttpResponse =
            client.get(
                "$CODEBERG_API_BASE/releases?limit=$perPage"
            ) {
                headers {
                    append("Accept", "application/json")
                    append("User-Agent", "OpenTune")

                    if (!cachedEtag.isNullOrBlank()) {
                        append("If-None-Match", cachedEtag)
                    }
                }
            }

        val etag = response.headers["ETag"]

        return when (response.status) {
            HttpStatusCode.NotModified ->
                ReleasesNetworkResult(
                    status = response.status,
                    body = null,
                    etag = cachedEtag ?: etag,
                )

            else ->
                ReleasesNetworkResult(
                    status = response.status,
                    body = response.bodyAsText(),
                    etag = etag,
                )
        }
    }

    private suspend fun getCurrentUpdateChannel(): UpdateChannel {
        val channelName = App.instance.dataStore.getAsync(UpdateChannelKey) ?: UpdateChannel.STABLE.name
        return runCatching { UpdateChannel.valueOf(channelName) }.getOrDefault(UpdateChannel.STABLE)
    }

    private suspend fun fetchNightlyJson(): Result<NightlyInfo> = runCatching {
        val response = client.get(NIGHTLY_JSON_URL) {
            headers {
                append("Accept", "application/json")
                append("User-Agent", "OpenTune")
            }
        }.bodyAsText()
        val json = JSONObject(response)

        // El JSON está en /nightly/update.json pero el APK debe servirse sin /nightly/
        val rawApkUrl = json.optString("apkUrl", "")
        val fixedApkUrl = rawApkUrl.replace(
            "https://pub-2218e6bbd5b948e1b5d882cf4d92086d.r2.dev/",
            "https://pub-2218e6bbd5b948e1b5d882cf4d92086d.r2.dev/"
        )

        NightlyInfo(
            versionName = json.optString("versionName", "unknown"),
            apkUrl = fixedApkUrl.ifEmpty {
                "https://pub-2218e6bbd5b948e1b5d882cf4d92086d.r2.dev/app-universal-release.apk"
            },
            changelog = json.optString("changelog", "").takeIf { it.isNotEmpty() },
            publishedAt = json.optString("publishedAt", "")
        )
    }

    // ─── Funciones públicas (compatibilidad obligatoria) ───────────────────────

    suspend fun getCachedReleases(): List<ReleaseInfo> {
        if (getCurrentUpdateChannel() == UpdateChannel.NIGHTLY) return emptyList()
        val cachedJson = App.instance.dataStore.getAsync(GitHubReleasesJsonKey)
        return cachedJson
            ?.takeIf { it.isNotBlank() }
            ?.let { runCatching { parseReleasesJson(it) }.getOrNull() }
            ?: emptyList()
    }

    suspend fun getLatestVersionName(forceRefresh: Boolean = false): Result<String> = runCatching {
        when (getCurrentUpdateChannel()) {
            UpdateChannel.STABLE -> {
                val latest = getLatestReleaseInfo(forceRefresh = forceRefresh).getOrThrow()
                preferredReleaseVersionNameOrNull(latest) ?: latest.name.ifBlank { latest.tagName }
            }
            UpdateChannel.NIGHTLY -> {
                fetchNightlyJson().getOrThrow().versionName
            }
        }
    }

    suspend fun getLatestReleaseNotes(): Result<String?> = runCatching {
        when (getCurrentUpdateChannel()) {
            UpdateChannel.STABLE -> getLatestReleaseInfo().getOrThrow().body
            UpdateChannel.NIGHTLY -> fetchNightlyJson().getOrThrow().changelog
        }
    }

    suspend fun getLatestReleaseInfo(forceRefresh: Boolean = false): Result<ReleaseInfo> = runCatching {
        when (getCurrentUpdateChannel()) {
            UpdateChannel.STABLE -> {
                val releases = getAllReleases(forceRefresh = forceRefresh).getOrThrow()
                val latest = findLatestRelease(releases)
                    ?: throw IllegalStateException("No releases found")
                lastCheckTime = System.currentTimeMillis()
                latest
            }
            UpdateChannel.NIGHTLY -> {
                val nightly = fetchNightlyJson().getOrThrow()
                cachedNightlyInfo = nightly
                ReleaseInfo(
                    tagName = nightly.versionName,
                    name = nightly.versionName,
                    body = nightly.changelog,
                    publishedAt = nightly.publishedAt,
                    htmlUrl = nightly.apkUrl
                )
            }
        }
    }

    // ─── Comprobación de actualización ─────────────────────────────────────────

    /**
     * Comprueba si hay una versión más reciente que [currentVersionName].
     */
    suspend fun checkForUpdate(
        currentVersionName: String,
        forceRefresh: Boolean = true,
    ): Result<UpdateInfo?> =
        runCatching {
            when (getCurrentUpdateChannel()) {
                UpdateChannel.STABLE -> checkForUpdateStable(currentVersionName, forceRefresh = forceRefresh)
                UpdateChannel.NIGHTLY -> checkForUpdateNightly(currentVersionName)
            }
        }

    private suspend fun checkForUpdateStable(
        currentVersionName: String,
        forceRefresh: Boolean = true,
    ): UpdateInfo? {
        val latest = getLatestReleaseInfo(forceRefresh = forceRefresh).getOrThrow()
        val latestVersionName =
            preferredReleaseVersionNameOrNull(latest)
                ?: latest.name.ifBlank { latest.tagName }

        if (!isNewerVersion(latestVersionName, currentVersionName)) return null

        val downloadUrl = resolveApkDownloadUrl(latest.tagName)

        return UpdateInfo(
            tagName        = latest.tagName,
            versionName    = latestVersionName,
            downloadUrl    = downloadUrl,
            releasePageUrl = latest.htmlUrl,
            releaseNotes   = latest.body,
            publishedAt    = latest.publishedAt,
        )
    }

    private suspend fun checkForUpdateNightly(currentVersionName: String): UpdateInfo? {
        val nightly = fetchNightlyJson().getOrThrow()
        return if (isSameVersion(nightly.versionName, currentVersionName)) {
            null
        } else {
            cachedNightlyInfo = nightly
            UpdateInfo(
                tagName        = nightly.versionName,
                versionName    = nightly.versionName,
                downloadUrl    = nightly.apkUrl,
                releasePageUrl = nightly.apkUrl,
                releaseNotes   = nightly.changelog,
                publishedAt    = nightly.publishedAt,
            )
        }
    }

    private suspend fun resolveApkDownloadUrl(tagName: String): String {
        val encodedTag = Uri.encode(tagName)
        val fallback = "$CODEBERG_REPO_URL/releases/download/$encodedTag/$APK_ASSET_NAME"

        return runCatching {
            val response = client.get("$CODEBERG_API_BASE/releases/tags/$encodedTag") {
                headers {
                    append("Accept", "application/json")
                    append("User-Agent", "OpenTune")
                }
            }.bodyAsText()

            val assets = JSONObject(response).optJSONArray("assets")
                ?: return@runCatching fallback

            for (i in 0 until assets.length()) {
                val asset = assets.getJSONObject(i)
                if (asset.optString("name").equals(APK_ASSET_NAME, ignoreCase = true)) {
                    return@runCatching asset.optString("browser_download_url")
                        .takeIf { it.isNotBlank() }
                        ?: fallback
                }
            }

            fallback
        }.getOrDefault(fallback)
    }


    fun downloadApk(url: String, destinationFile: File): Flow<Float> = flow {
        client.prepareGet(url).execute { response ->
            val totalBytes = response.contentLength() ?: -1L
            val channel: ByteReadChannel = response.bodyAsChannel()
            var downloadedBytes = 0L
            val buffer = ByteArray(1024 * 8)

            // Elimina withContext(Dispatchers.IO) - ya estamos en el contexto correcto
            destinationFile.parentFile?.mkdirs()
            FileOutputStream(destinationFile).use { output ->
                while (!channel.isClosedForRead) {
                    val read = channel.readAvailable(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    downloadedBytes += read
                    if (totalBytes > 0) {
                        emit(downloadedBytes.toFloat() / totalBytes)
                    } else {
                        emit(-1f)
                    }
                }
            }
        }
    }.flowOn(Dispatchers.IO)

    fun installApk(context: Context, apkFile: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.FileProvider",
            apkFile
        )

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    // ─────────────────────────────────────────────────────────────────────────

    suspend fun getCommitHistory(count: Int = 20, branch: String = "main"): Result<List<GitCommit>> =
        runCatching {
            val response =
                client.get("$CODEBERG_API_BASE/commits?sha=${Uri.encode(branch)}&limit=$count") {
                    headers {
                        append("Accept", "application/json")
                        append("User-Agent", "OpenTune")
                    }
                }.bodyAsText()
            val jsonArray = JSONArray(response)
            val commits = mutableListOf<GitCommit>()
            for (i in 0 until jsonArray.length()) {
                val commitObj = jsonArray.getJSONObject(i)
                val commit = commitObj.getJSONObject("commit")
                val authorObj = commit.optJSONObject("author")
                commits.add(
                    GitCommit(
                        sha = commitObj.optString("sha", "").take(7),
                        message = commit.optString("message", "").lines().firstOrNull() ?: "",
                        author = authorObj?.optString("name", "Unknown") ?: "Unknown",
                        date = authorObj?.optString("date", "") ?: "",
                        url = commitObj.optString("html_url", "")
                    )
                )
            }
            commits
        }

    fun getLatestDownloadUrl(): String {
        val channel = runBlocking {
            kotlin.runCatching { getCurrentUpdateChannel() }.getOrDefault(UpdateChannel.STABLE)
        }
        return when (channel) {
            UpdateChannel.STABLE -> {
                // Use the cached release list to avoid performing network I/O in this synchronous API.
                runBlocking {
                    val cachedJson = App.instance.dataStore.getAsync(GitHubReleasesJsonKey)
                    val latest = cachedJson
                        ?.takeIf { it.isNotBlank() }
                        ?.let { runCatching { parseReleasesJson(it) }.getOrNull() }
                        ?.let { findLatestRelease(it) }

                    latest?.let {
                        "$CODEBERG_REPO_URL/releases/download/${Uri.encode(it.tagName)}/$APK_ASSET_NAME"
                    } ?: "$CODEBERG_REPO_URL/releases"
                }
            }
            UpdateChannel.NIGHTLY -> {
                cachedNightlyInfo?.apkUrl
                    ?: "https://pub-2218e6bbd5b948e1b5d882cf4d92086d.r2.dev/app-universal-release.apk"
            }
        }
    }

    suspend fun getAllReleases(
        perPage: Int = 30,
        forceRefresh: Boolean = false,
    ): Result<List<ReleaseInfo>> =
        runCatching {
            if (getCurrentUpdateChannel() == UpdateChannel.NIGHTLY) {
                return@runCatching emptyList()
            }

            val now = System.currentTimeMillis()
            val cachedJson = App.instance.dataStore.getAsync(GitHubReleasesJsonKey)
            val cachedEtag = App.instance.dataStore.getAsync(GitHubReleasesEtagKey)
            val lastCheckedAt = App.instance.dataStore.getAsync(GitHubReleasesLastCheckedAtKey, 0L)
            val cachedFingerprint = App.instance.dataStore.getAsync(GitHubReleasesFingerprintKey)

            val cachedReleases =
                cachedJson
                    ?.takeIf { it.isNotBlank() }
                    ?.let { runCatching { parseReleasesJson(it) }.getOrNull() }

            val shouldCheckNetwork =
                forceRefresh || cachedJson.isNullOrBlank() || (now - lastCheckedAt) >= ReleaseCacheCheckIntervalMs

            if (!shouldCheckNetwork) {
                lastCheckTime = now
                return@runCatching cachedReleases ?: emptyList()
            }

            val networkResult = runCatching {
                fetchReleasesNetwork(perPage = perPage, cachedEtag = if (forceRefresh) null else cachedEtag)
            }.getOrNull()

            if (networkResult == null) {
                val fallback = cachedReleases
                if (fallback != null && !forceRefresh) {
                    lastCheckTime = now
                    return@runCatching fallback
                }
                throw IllegalStateException("Failed to connect to Codeberg")
            }

            when {
                networkResult.status == HttpStatusCode.NotModified -> {
                    App.instance.dataStore.edit { settings ->
                        settings[GitHubReleasesLastCheckedAtKey] = now
                        networkResult.etag?.let { settings[GitHubReleasesEtagKey] = it }
                    }
                    val fallback = cachedReleases
                    if (fallback != null) {
                        lastCheckTime = now
                        return@runCatching fallback
                    }
                    throw IllegalStateException("Release cache is empty")
                }

                networkResult.status.value in 200..299 && !networkResult.body.isNullOrBlank() -> {
                    val networkBody = networkResult.body
                    val releases = parseReleasesJson(networkBody)
                    val newFingerprint = getTopReleaseFingerprint(releases)
                    val hasPayloadChanged = cachedJson != networkBody
                    val hasTopReleaseChanged = cachedFingerprint != newFingerprint

                    App.instance.dataStore.edit { settings ->
                        settings[GitHubReleasesLastCheckedAtKey] = now
                        networkResult.etag?.let { settings[GitHubReleasesEtagKey] = it }
                        if (hasPayloadChanged || hasTopReleaseChanged || cachedJson.isNullOrBlank()) {
                            settings[GitHubReleasesJsonKey] = networkBody
                            settings[GitHubReleasesFingerprintKey] = newFingerprint
                        }
                    }
                    lastCheckTime = now
                    releases
                }

                networkResult.status == HttpStatusCode.Forbidden || networkResult.status.value == 429 -> {
                    if (forceRefresh) {
                        throw IllegalStateException("Codeberg API request limit exceeded. Please try again later.")
                    }
                    cachedReleases ?: throw IllegalStateException("Codeberg API request limit exceeded")
                }

                else -> {
                    if (forceRefresh) {
                        throw IllegalStateException("Failed to fetch releases: HTTP ${networkResult.status.value}")
                    }
                    val fallback = cachedReleases
                    if (fallback != null) {
                        lastCheckTime = now
                        fallback
                    } else {
                        throw IllegalStateException("Failed to fetch releases: HTTP ${networkResult.status.value}")
                    }
                }
            }
        }
}
