package com.arturo254.opentune.playback

internal fun <T> mediaLibraryPage(items: List<T>, page: Int, pageSize: Int): List<T> {
    if (page < 0 || pageSize <= 0) return emptyList()
    val from = page.toLong() * pageSize
    if (from >= items.size) return emptyList()
    val to = minOf(from + pageSize, items.size.toLong())
    return items.subList(from.toInt(), to.toInt())
}
