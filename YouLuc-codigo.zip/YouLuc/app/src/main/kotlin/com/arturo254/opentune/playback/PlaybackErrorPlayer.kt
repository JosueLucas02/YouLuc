package com.arturo254.opentune.playback

import androidx.media3.common.ForwardingPlayer
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import java.lang.reflect.InvocationTargetException
import java.lang.reflect.Proxy
import java.util.IdentityHashMap

/** Translates errors before either Media3 or legacy car controllers receive player events. */
internal class PlaybackErrorPlayer(
    player: Player,
    private val resolveError: (PlaybackException) -> PlaybackException,
) : ForwardingPlayer(player) {
    private val listeners = IdentityHashMap<Player.Listener, Player.Listener>()
    private var originalError: PlaybackException? = null
    private var readableError: PlaybackException? = null

    private fun readable(error: PlaybackException?): PlaybackException? {
        if (error !== originalError) {
            originalError = error
            readableError = error?.let(resolveError)
        }
        return readableError
    }

    override fun getPlayerError(): PlaybackException? = readable(super.getPlayerError())

    override fun addListener(listener: Player.Listener) {
        synchronized(listeners) {
            val translated = listeners.getOrPut(listener) {
                Proxy.newProxyInstance(
                    Player.Listener::class.java.classLoader,
                    arrayOf(Player.Listener::class.java),
                ) { _, method, args ->
                    when (method.name) {
                        "onPlayerError" -> {
                            listener.onPlayerError(requireNotNull(readable(args!![0] as PlaybackException)))
                            null
                        }
                        "onPlayerErrorChanged" -> {
                            listener.onPlayerErrorChanged(readable(args?.getOrNull(0) as? PlaybackException))
                            null
                        }
                        "equals" -> {
                            val other = args?.getOrNull(0)
                            other === listener || (listeners[listener] != null && other === listeners[listener])
                        }
                        "hashCode" -> System.identityHashCode(listener)
                        "toString" -> "PlaybackErrorListenerWrapper($listener)"
                        else -> {
                            try {
                                if (args == null) {
                                    method.invoke(listener)
                                } else {
                                    method.invoke(listener, *args)
                                }
                            } catch (e: InvocationTargetException) {
                                throw e.targetException ?: e
                            }
                        }
                    }
                } as Player.Listener
            }
            super.addListener(translated)
        }
    }

    override fun removeListener(listener: Player.Listener) {
        synchronized(listeners) {
            val toRemove = listeners.remove(listener) ?: run {
                val entry = listeners.entries.firstOrNull { it.value === listener }
                if (entry != null) {
                    listeners.remove(entry.key)
                    entry.value
                } else {
                    listener
                }
            }
            super.removeListener(toRemove)
        }
    }
}
