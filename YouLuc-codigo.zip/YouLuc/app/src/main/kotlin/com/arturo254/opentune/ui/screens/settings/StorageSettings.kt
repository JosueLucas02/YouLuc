/*
 * OpenTune Project Original (2026)
 * Arturo254 (github.com/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */

package com.arturo254.opentune.ui.screens.settings

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil3.annotation.ExperimentalCoilApi
import coil3.imageLoader
import com.arturo254.opentune.LocalPlayerAwareWindowInsets
import com.arturo254.opentune.LocalPlayerConnection
import com.arturo254.opentune.R
import com.arturo254.opentune.canvas.CanvasCacheManager
import com.arturo254.opentune.constants.AutoDownloadArtworkKey
import com.arturo254.opentune.constants.AutoDownloadLyricsKey
import com.arturo254.opentune.constants.MaxCanvasCacheSizeKey
import com.arturo254.opentune.constants.MaxImageCacheSizeKey
import com.arturo254.opentune.constants.MaxSongCacheSizeKey
import com.arturo254.opentune.constants.SmartTrimmerKey
import com.arturo254.opentune.extensions.directorySizeBytes
import com.arturo254.opentune.extensions.tryOrNull
import com.arturo254.opentune.ui.component.ActionPromptDialog
import com.arturo254.opentune.ui.component.ExpressiveListBottomSheet
import com.arturo254.opentune.ui.component.IconButton
import com.arturo254.opentune.ui.component.IconContainer
import com.arturo254.opentune.ui.component.PreferenceGroup
import com.arturo254.opentune.ui.component.SwitchPreference
import com.arturo254.opentune.ui.player.CanvasArtworkPlaybackCache
import com.arturo254.opentune.ui.utils.backToMain
import com.arturo254.opentune.ui.utils.formatFileSize
import com.arturo254.opentune.utils.rememberPreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


private val ExpressiveCorner = 28.dp
private val ScreenHorizontalPadding = 16.dp
private val CacheClearButtonSize = 48.dp
private val CacheClearRestCorner = 24.dp // = CacheClearButtonSize / 2 → círculo
private val CacheClearPressedCorner = 16.dp // squircle al presionar
private val InfoChipCorner = 14.dp
private val CacheSizeRowCorner = 18.dp
private val CacheSizeRowPressedCorner = 14.dp

@OptIn(
    ExperimentalCoilApi::class,
    ExperimentalMaterial3Api::class,
    ExperimentalMaterial3ExpressiveApi::class
)
@Composable
fun StorageSettings(
    navController: NavController,
    scrollBehavior: TopAppBarScrollBehavior,
) {
    val context = LocalContext.current
    val imageDiskCache = context.imageLoader.diskCache ?: return
    val playerCache = LocalPlayerConnection.current?.service?.playerCache ?: return
    val downloadCache = LocalPlayerConnection.current?.service?.downloadCache ?: return

    val downloadCacheDir = remember { context.filesDir.resolve("download") }
    val playerCacheDir = remember { context.filesDir.resolve("exoplayer") }

    val coroutineScope = rememberCoroutineScope()
    val (smartTrimmer, onSmartTrimmerChange) = rememberPreference(
        key = SmartTrimmerKey,
        defaultValue = false
    )
    val (maxImageCacheSize, onMaxImageCacheSizeChange) = rememberPreference(
        key = MaxImageCacheSizeKey,
        defaultValue = 512
    )
    val (maxSongCacheSize, onMaxSongCacheSizeChange) = rememberPreference(
        key = MaxSongCacheSizeKey,
        defaultValue = 1024
    )
    val (autoDownloadLyrics, onAutoDownloadLyricsChange) = rememberPreference(
        key = AutoDownloadLyricsKey,
        defaultValue = true
    )
    val (autoDownloadArtwork, onAutoDownloadArtworkChange) = rememberPreference(
        key = AutoDownloadArtworkKey,
        defaultValue = true
    )
    val (maxCanvasCacheSize, onMaxCanvasCacheSizeChange) = rememberPreference(
        key = MaxCanvasCacheSizeKey,
        defaultValue = 256,
    )
    var clearCacheDialog by remember { mutableStateOf(false) }
    var clearDownloads by remember { mutableStateOf(false) }
    var clearImageCacheDialog by remember { mutableStateOf(false) }
    var clearCanvasCacheDialog by remember { mutableStateOf(false) }

    var imageCacheSize by remember {
        mutableStateOf(imageDiskCache.size)
    }
    var playerCacheSize by remember {
        mutableStateOf(0L)
    }
    var downloadCacheSize by remember {
        mutableStateOf(0L)
    }
    var canvasCacheCount by remember {
        mutableStateOf(CanvasArtworkPlaybackCache.size())
    }
    var canvasVideoCacheCount by remember { mutableStateOf(0) }
    var canvasVideoCacheSize by remember { mutableStateOf(0L) }

    val imageCacheProgress by animateFloatAsState(
        targetValue = if (imageDiskCache.maxSize > 0) {
            (imageCacheSize.toFloat() / imageDiskCache.maxSize).coerceIn(0f, 1f)
        } else 0f,
        label = "imageCacheProgress",
    )
    val maxSongCacheSizeBytes = if (maxSongCacheSize > 0) maxSongCacheSize * 1024 * 1024L else 0L
    val playerCacheProgress by animateFloatAsState(
        targetValue = if (maxSongCacheSizeBytes > 0) {
            (playerCacheSize.toFloat() / maxSongCacheSizeBytes).coerceIn(0f, 1f)
        } else 0f,
        label = "playerCacheProgress",
    )
    val canvasCacheProgress by animateFloatAsState(
        targetValue = if (maxCanvasCacheSize > 0) {
            (canvasCacheCount.toFloat() / maxCanvasCacheSize).coerceIn(0f, 1f)
        } else 0f,
        label = "canvasCacheProgress",
    )
    val canvasVideoCacheProgress by animateFloatAsState(
        targetValue = if (maxCanvasCacheSize > 0) {
            (canvasVideoCacheCount.toFloat() / maxCanvasCacheSize).coerceIn(0f, 1f)
        } else 0f,
        label = "canvasVideoCacheProgress",
    )

    // Animación de entrada de la pantalla: fundido + deslizamiento corto.
    var revealed by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { revealed = true }
    val revealProgress by animateFloatAsState(
        targetValue = if (revealed) 1f else 0f,
        animationSpec = tween(durationMillis = 420, easing = FastOutSlowInEasing),
        label = "storageReveal",
    )

    val isSmartTrimmerAvailable = maxImageCacheSize != 0 || maxSongCacheSize != 0
    LaunchedEffect(isSmartTrimmerAvailable) {
        if (!isSmartTrimmerAvailable && smartTrimmer) onSmartTrimmerChange(false)
    }

    LaunchedEffect(maxImageCacheSize) {
        if (maxImageCacheSize == 0) {
            coroutineScope.launch(Dispatchers.IO) {
                imageDiskCache.clear()
                com.arturo254.opentune.utils.ArtworkStorage.clear(context)
            }
        }
    }
    LaunchedEffect(maxSongCacheSize) {
        if (maxSongCacheSize == 0) {
            coroutineScope.launch(Dispatchers.IO) {
                playerCache.keys.forEach { key ->
                    playerCache.removeResource(key)
                }
            }
        }
    }
    LaunchedEffect(maxCanvasCacheSize) {
        CanvasArtworkPlaybackCache.setMaxSize(maxCanvasCacheSize)
        if (maxCanvasCacheSize == 0) {
            CanvasArtworkPlaybackCache.clear()
            coroutineScope.launch {
                CanvasCacheManager.clearCache()
            }
        }
    }

    LaunchedEffect(imageDiskCache) {
        while (isActive) {
            delay(500)
            imageCacheSize = imageDiskCache.size
        }
    }
    LaunchedEffect(playerCache, playerCacheDir) {
        while (isActive) {
            delay(500)
            playerCacheSize =
                withContext(Dispatchers.IO) {
                    val cacheSpace = tryOrNull { playerCache.cacheSpace } ?: 0L
                    if (cacheSpace == 0L) playerCacheDir.directorySizeBytes() else cacheSpace
                }
        }
    }
    LaunchedEffect(downloadCache, downloadCacheDir) {
        while (isActive) {
            delay(500)
            downloadCacheSize =
                withContext(Dispatchers.IO) {
                    val cacheSpace = tryOrNull { downloadCache.cacheSpace } ?: 0L
                    if (cacheSpace == 0L) downloadCacheDir.directorySizeBytes() else cacheSpace
                }
        }
    }
    LaunchedEffect(Unit) {
        while (isActive) {
            delay(500)
            canvasCacheCount = CanvasArtworkPlaybackCache.size()
        }
    }
    LaunchedEffect(Unit) {
        while (isActive) {
            delay(500)
            canvasVideoCacheCount = CanvasCacheManager.getCacheCount()
            canvasVideoCacheSize = CanvasCacheManager.getCacheSize()
        }
    }

    // Elementos de caché que alimentan la lista segmentada.
    val cacheItems = listOf(
        CacheItem(
            id = "downloads",
            icon = R.drawable.ic_download,
            title = stringResource(R.string.downloaded_songs),
            description = stringResource(R.string.size_used, formatFileSize(downloadCacheSize)),
            progress = null,
            onClear = { clearDownloads = true },
            sizeConfig = null,
        ),
        CacheItem(
            id = "songs",
            icon = R.drawable.ic_music,
            title = stringResource(R.string.song_cache),
            description = if (maxSongCacheSize == -1) {
                stringResource(R.string.size_used, formatFileSize(playerCacheSize))
            } else {
                "${formatFileSize(playerCacheSize)} / ${formatFileSize(maxSongCacheSize * 1024 * 1024L)}"
            },
            progress = if (maxSongCacheSize > 0) playerCacheProgress else null,
            onClear = { clearCacheDialog = true },
            sizeConfig = CacheSizeConfig(
                values = listOf(0, 128, 256, 512, 1024, 2048, 4096, 8192, -1),
                selected = maxSongCacheSize,
                text = {
                    when (it) {
                        0 -> stringResource(R.string.disable)
                        -1 -> stringResource(R.string.unlimited)
                        else -> formatFileSize(it * 1024 * 1024L)
                    }
                },
                onSelected = onMaxSongCacheSizeChange,
            ),
        ),
        CacheItem(
            id = "images",
            icon = R.drawable.image,
            title = stringResource(R.string.image_cache),
            description = if (maxImageCacheSize > 0) {
                "${formatFileSize(imageCacheSize)} / ${formatFileSize(imageDiskCache.maxSize)}"
            } else {
                stringResource(R.string.disable)
            },
            progress = if (maxImageCacheSize > 0) imageCacheProgress else null,
            onClear = { clearImageCacheDialog = true },
            sizeConfig = CacheSizeConfig(
                values = listOf(0, 128, 256, 512, 1024, 2048, 4096, 8192),
                selected = maxImageCacheSize,
                text = {
                    when (it) {
                        0 -> stringResource(R.string.disable)
                        else -> formatFileSize(it * 1024 * 1024L)
                    }
                },
                onSelected = onMaxImageCacheSizeChange,
            ),
        ),
        CacheItem(
            id = "canvas",
            icon = R.drawable.motion_photos_on,
            title = stringResource(R.string.canvas_cache),
            description = if (maxCanvasCacheSize > 0) {
                stringResource(
                    R.string.canvas_cache_usage,
                    formatFileSize(canvasVideoCacheSize),
                    stringResource(R.string.canvas_cache_items, maxCanvasCacheSize)
                )
            } else {
                stringResource(R.string.disable)
            },
            progress = if (maxCanvasCacheSize > 0) canvasVideoCacheProgress else null,
            onClear = { clearCanvasCacheDialog = true },
            sizeConfig = CacheSizeConfig(
                values = listOf(0, 64, 128, 256, 512, 1024),
                selected = maxCanvasCacheSize,
                text = {
                    when (it) {
                        0 -> stringResource(R.string.disable)
                        else -> stringResource(R.string.canvas_cache_items, it)
                    }
                },
                onSelected = onMaxCanvasCacheSizeChange,
            ),
        )
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.storage)) },
                navigationIcon = {
                    IconButton(
                        onClick = navController::navigateUp,
                        onLongClick = navController::backToMain,
                    ) {
                        Icon(
                            painterResource(R.drawable.arrow_back),
                            contentDescription = null,
                        )
                    }
                },
                scrollBehavior = scrollBehavior,
            )
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .nestedScroll(scrollBehavior.nestedScrollConnection)
                .padding(innerPadding)
                .windowInsetsPadding(
                    LocalPlayerAwareWindowInsets.current.only(
                        WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom
                    )
                )
                .graphicsLayer {
                    alpha = revealProgress
                    translationY = (1f - revealProgress) * 24.dp.toPx()
                },
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp),
        ) {
            // ── Depurador inteligente ────────────────────────────────────────
            item(key = "smart_trimmer") {
                SwitchPreference(
                    title = { Text(stringResource(R.string.smart_trimmer)) },
                    description = stringResource(R.string.smart_trimmer_description),
                    icon = {
                        Icon(
                            painterResource(R.drawable.auto_awesome),
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                        )
                    },
                    checked = smartTrimmer && isSmartTrimmerAvailable,
                    onCheckedChange = onSmartTrimmerChange,
                    isEnabled = isSmartTrimmerAvailable,
                )
            }

            // ── Descargas sin conexión ───────────────────────────────────────
            item(key = "offline_group") {
                PreferenceGroup(
                    title = stringResource(R.string.offline_downloads_section),
                ) {
                    SwitchPreference(
                        title = { Text(stringResource(R.string.auto_download_lyrics)) },
                        description = stringResource(R.string.auto_download_lyrics_desc),
                        icon = {
                            Icon(
                                painterResource(R.drawable.lyrics),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        },
                        checked = autoDownloadLyrics,
                        onCheckedChange = onAutoDownloadLyricsChange,
                    )

                    SwitchPreference(
                        title = { Text(stringResource(R.string.auto_download_artwork)) },
                        description = stringResource(R.string.auto_download_artwork_desc),
                        icon = {
                            Icon(
                                painterResource(R.drawable.format_paint),
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                            )
                        },
                        checked = autoDownloadArtwork,
                        onCheckedChange = onAutoDownloadArtworkChange,
                    )
                }
            }

            // ── Tarjetas de caché ────────────────────────────────────────────
            items(items = cacheItems, key = { it.id }) { item ->
                ExpressiveCacheCard(
                    icon = item.icon,
                    title = item.title,
                    description = item.description,
                    progress = item.progress,
                    onClear = item.onClear,
                    sizeConfig = item.sizeConfig,
                    modifier = Modifier.padding(horizontal = ScreenHorizontalPadding),
                )
            }
        }
    }

    // ── Diálogos de confirmación ─────────────────────────────────────────────
    if (clearDownloads) {
        ActionPromptDialog(
            title = stringResource(R.string.clear_all_downloads),
            onDismiss = { clearDownloads = false },
            onConfirm = {
                coroutineScope.launch(Dispatchers.IO) {
                    downloadCache.keys.forEach { key ->
                        downloadCache.removeResource(key)
                    }
                }
                clearDownloads = false
            },
            onCancel = { clearDownloads = false },
            content = {
                Text(text = stringResource(R.string.clear_downloads_dialog))
            }
        )
    }

    if (clearCacheDialog) {
        ActionPromptDialog(
            title = stringResource(R.string.clear_song_cache),
            onDismiss = { clearCacheDialog = false },
            onConfirm = {
                coroutineScope.launch(Dispatchers.IO) {
                    playerCache.keys.forEach { key ->
                        playerCache.removeResource(key)
                    }
                }
                clearCacheDialog = false
            },
            onCancel = { clearCacheDialog = false },
            content = {
                Text(text = stringResource(R.string.clear_song_cache_dialog))
            }
        )
    }

    if (clearImageCacheDialog) {
        ActionPromptDialog(
            title = stringResource(R.string.clear_image_cache),
            onDismiss = { clearImageCacheDialog = false },
            onConfirm = {
                coroutineScope.launch(Dispatchers.IO) {
                    imageDiskCache.clear()
                    com.arturo254.opentune.utils.ArtworkStorage.clear(context)
                }
                clearImageCacheDialog = false
            },
            onCancel = { clearImageCacheDialog = false },
            content = {
                Text(text = stringResource(R.string.clear_image_cache_dialog))
            }
        )
    }

    if (clearCanvasCacheDialog) {
        ActionPromptDialog(
            title = stringResource(R.string.clear_canvas_cache),
            onDismiss = { clearCanvasCacheDialog = false },
            onConfirm = {
                coroutineScope.launch {
                    CanvasArtworkPlaybackCache.clear()
                    CanvasCacheManager.clearCache()
                    clearCanvasCacheDialog = false
                }
            },
            onCancel = { clearCanvasCacheDialog = false },
            content = {
                Text(text = stringResource(R.string.clear_canvas_cache_dialog))
            }
        )
    }
}


@Composable
private fun ExpressiveCacheCard(
    icon: Int,
    title: String,
    description: String,
    progress: Float?,
    onClear: () -> Unit,
    sizeConfig: CacheSizeConfig?,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(ExpressiveCorner),
        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.78f),
        border = BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f),
        ),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconContainer {
                    Icon(
                        painter = painterResource(icon),
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                    )
                }

                Spacer(Modifier.width(14.dp))

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                        text = description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }

                Spacer(Modifier.width(12.dp))

                CacheClearButton(onClick = onClear)
            }

            if (progress != null) {
                CacheUsageBar(progress = progress)
            }

            sizeConfig?.let {
                CacheSizeSelector(
                    title = stringResource(R.string.max_cache_size),
                    config = it,
                )
            }
        }
    }
}

@Composable
private fun CacheClearButton(onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.9f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium,
        ),
        label = "cacheClearScale",
    )
    val corner by animateDpAsState(
        targetValue = if (pressed) CacheClearPressedCorner else CacheClearRestCorner,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium,
        ),
        label = "cacheClearCorner",
    )

    FilledTonalIconButton(
        onClick = onClick,
        interactionSource = interactionSource,
        shape = RoundedCornerShape(corner),
        colors = IconButtonDefaults.filledTonalIconButtonColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer,
        ),
        modifier = Modifier
            .size(CacheClearButtonSize)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            },
    ) {
        Icon(
            painter = painterResource(R.drawable.delete),
            contentDescription = stringResource(R.string.clear),
            modifier = Modifier.size(20.dp),
        )
    }
}

/**
 * Barra de uso del caché. El color vira a `error` y aparece un chip
 * cuando el caché supera el 80% de su capacidad.
 */
@Composable
private fun CacheUsageBar(progress: Float) {
    val nearFull = progress > 0.8f
    val barColor by animateColorAsState(
        targetValue = if (nearFull) {
            MaterialTheme.colorScheme.error
        } else {
            MaterialTheme.colorScheme.primary
        },
        animationSpec = tween(durationMillis = 400),
        label = "cacheBarColor",
    )

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp),
            color = barColor,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            strokeCap = StrokeCap.Round,
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = stringResource(R.string.cache_usage_percent, (progress * 100).toInt()),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (nearFull) {
                Surface(
                    shape = RoundedCornerShape(InfoChipCorner),
                    color = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer,
                ) {
                    Text(
                        text = stringResource(R.string.storage_almost_full),
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    )
                }
            }
        }
    }
}

/**
 * Selector de tamaño máximo de caché: fila pulsable que abre el
 * [ExpressiveListBottomSheet] con las opciones disponibles.
 */
@Composable
private fun CacheSizeSelector(
    title: String,
    config: CacheSizeConfig,
) {
    var showBottomSheet by remember { mutableStateOf(false) }

    if (showBottomSheet) {
        ExpressiveListBottomSheet(
            onDismiss = { showBottomSheet = false },
            values = config.values,
            selectedValue = config.selected,
            valueText = config.text,
            onValueSelected = {
                showBottomSheet = false
                config.onSelected(it)
            },
        )
    }

    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()

    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.975f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow,
        ),
        label = "cacheSizeScale",
    )
    val corner by animateDpAsState(
        targetValue = if (pressed) CacheSizeRowPressedCorner else CacheSizeRowCorner,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium,
        ),
        label = "cacheSizeCorner",
    )

    Surface(
        onClick = { showBottomSheet = true },
        interactionSource = interactionSource,
        shape = RoundedCornerShape(corner),
        color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.6f),
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            },
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                painter = painterResource(R.drawable.storage),
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(Modifier.width(10.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f),
            )

            Text(
                text = config.text(config.selected),
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary,
            )

            Spacer(Modifier.width(4.dp))

            Icon(
                painter = painterResource(R.drawable.chevron_right),
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

private data class CacheItem(
    val id: String,
    val icon: Int,
    val title: String,
    val description: String,
    val progress: Float?,
    val onClear: () -> Unit,
    val sizeConfig: CacheSizeConfig? = null,
)

private data class CacheSizeConfig(
    val values: List<Int>,
    val selected: Int,
    val text: @Composable (Int) -> String,
    val onSelected: (Int) -> Unit,
)
