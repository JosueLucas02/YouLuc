package com.arturo254.opentune.ui.screens

import kotlinx.serialization.json.JsonPrimitive
import org.junit.Assert.*
import org.junit.Test

class YouTubeLoginStateTest {
    @Test
    fun validLoginAndRecoveryUrlsArePreserved() {
        val login = "https://accounts.google.com/ServiceLogin?continue=https%3A%2F%2Fmusic.youtube.com"
        val recovery = "https://music.youtube.com/watch?v=video&next=a%26b"
        assertEquals(login, YouTubeLoginState.startUrl(login))
        assertEquals(recovery, YouTubeLoginState.startUrl("  $recovery  "))
        assertTrue(YouTubeLoginState.allowsNavigation("https://consent.youtube.com/m"))
        assertTrue(YouTubeLoginState.allowsNavigation("https://accounts.google.es/signin/v2"))
        assertTrue(YouTubeLoginState.allowsNavigation("https://myaccount.google.com/"))
        assertTrue(YouTubeLoginState.allowsNavigation("https://m.youtube.com/"))
        assertTrue(YouTubeLoginState.allowsNavigation("https://consent.google.com/"))
    }

    @Test
    fun insecureOrSpoofedLoginLinksCannotLoadInTheLoginWebView() {
        for (url in listOf(null, "", "javascript:alert(1)", "http://music.youtube.com/", "file:///private/file",
            "https://music.youtube.com.evil.test", "https://user@music.youtube.com", "https://music.youtube.com:444",
            "https://example.com/path?youtube.com", "not a url")) {
            assertEquals(YouTubeLoginState.DEFAULT_URL, YouTubeLoginState.startUrl(url))
            assertFalse(YouTubeLoginState.isYouTubePage(url))
        }
    }

    @Test
    fun sessionExtractionOnlyRunsOnTheActualYouTubeOrigin() {
        assertTrue(YouTubeLoginState.isYouTubePage("https://MUSIC.YOUTUBE.COM:443/watch?v=video"))
        assertFalse(YouTubeLoginState.isYouTubePage("https://accounts.google.com/ServiceLogin"))
        assertFalse(YouTubeLoginState.isYouTubePage("https://evil.test/path/youtube.com"))
    }

    @Test
    fun musicCookiesTakePriorityOverConflictingRootCookies() {
        val merged = YouTubeLoginState.mergeCookies(listOf("SAPISID=music=value; A=one", "SAPISID=old; B=two", null))
        assertEquals("SAPISID=music=value; A=one; B=two", merged)
        assertEquals("music=value", YouTubeLoginState.authenticationCookie(merged))
    }

    @Test
    fun anonymousAndEmptyCookiesDoNotMarkAnAccountAsConnected() {
        for (cookie in listOf(null, "", "VISITOR_INFO=anonymous", "SAPISID= ", "NOT_SAPISID=wrong")) {
            assertFalse(YouTubeLoginState.hasAuthentication(cookie))
        }
        assertTrue(YouTubeLoginState.hasAuthentication("A=one; SAPISID=valid"))
        assertNull(YouTubeLoginState.mergeCookies(listOf(null, "invalid; =missing; EMPTY=")))
    }

    @Test
    fun modernAndLegacyJavascriptResultsCanBeRead() {
        val json = """{"visitorData":"visitor","dataSyncId":"channel||account","poToken":"proof"}"""
        val expected = YouTubeLoginState.PageConfig("visitor", "channel||account", "proof")
        assertEquals(expected, YouTubeLoginState.pageConfig(json))
        assertEquals(expected, YouTubeLoginState.pageConfig(JsonPrimitive(json).toString()))
    }

    @Test
    fun missingAndMalformedPageValuesDoNotOverwriteSessionMetadata() {
        assertNull(YouTubeLoginState.pageConfig(null))
        assertNull(YouTubeLoginState.pageConfig("not json"))
        assertNull(YouTubeLoginState.pageConfig("null"))
        assertNull(YouTubeLoginState.pageConfig("x".repeat(64_001)))
        assertEquals(YouTubeLoginState.PageConfig(null, null, null),
            YouTubeLoginState.pageConfig("""{"visitorData":true,"dataSyncId":null,"poToken":""}"""))
    }

    @Test
    fun channelAndAccountSyncIdsMatchTheApplicationPreferenceReader() {
        assertEquals("account", YouTubeLoginState.accountDataSyncId("account"))
        assertEquals("account", YouTubeLoginState.accountDataSyncId("channel||account"))
        assertEquals("channel", YouTubeLoginState.accountDataSyncId("channel||"))
    }
}
