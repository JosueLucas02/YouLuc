package com.arturo254.opentune.playback

import java.io.IOException
import java.io.InterruptedIOException
import java.net.SocketTimeoutException
import java.util.concurrent.CancellationException
import org.junit.Assert.*
import org.junit.Test

class PlaybackCancellationTest {
    @Test
    fun cancelledAndInterruptedLoadsPropagateTheirOriginalSignal() {
        val cancelled = CancellationException("track skipped")
        assertSame(cancelled, assertThrows(CancellationException::class.java) { rethrowPlaybackCancellation(cancelled) })
        val interrupted = InterruptedException("loader cancelled")
        assertSame(interrupted, assertThrows(InterruptedException::class.java) { rethrowPlaybackCancellation(interrupted) })
        val fatal = OutOfMemoryError("fatal")
        assertSame(fatal, assertThrows(OutOfMemoryError::class.java) { rethrowPlaybackCancellation(fatal) })
    }

    @Test
    fun realTimeoutsAndIoFailuresRemainPlaybackFailures() {
        rethrowPlaybackCancellation(SocketTimeoutException("network timeout"))
        rethrowPlaybackCancellation(IOException("network disconnected"))
    }

    @Test
    fun wrappedCancellationIsNotConvertedIntoAResultOrPlaybackError() {
        val cancelled = CancellationException("track skipped")
        val wrapper = IOException("wrapped by network client", cancelled)
        assertTrue(isCancelledPlaybackLoad(wrapper))
        assertSame(cancelled, assertThrows(CancellationException::class.java) {
            playbackRunCatching { throw wrapper }
        })
        val fatal = OutOfMemoryError("fatal")
        assertSame(fatal, assertThrows(OutOfMemoryError::class.java) {
            playbackRunCatching { throw IOException("wrapped", fatal) }
        })
    }

    @Test
    fun ordinaryFailuresRemainResultsAndCyclicCausesTerminate() {
        val timeout = SocketTimeoutException("timeout")
        assertSame(timeout, playbackRunCatching { throw timeout }.exceptionOrNull())
        val a = IOException("a")
        val b = IOException("b", a)
        a.initCause(b)
        assertFalse(isCancelledPlaybackLoad(a))
        assertSame(a, playbackRunCatching { throw a }.exceptionOrNull())
    }

    @Test
    fun anInterruptedIoLoadDoesNotEnterFallbackRecovery() {
        val wasInterrupted = Thread.interrupted()
        try {
            Thread.currentThread().interrupt()
            val error = InterruptedIOException("cancelled")
            assertSame(error, assertThrows(InterruptedIOException::class.java) { rethrowPlaybackCancellation(error) })
        } finally {
            Thread.interrupted()
            if (wasInterrupted) Thread.currentThread().interrupt()
        }
    }
}
