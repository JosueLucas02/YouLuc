package com.arturo254.opentune.playback

import org.junit.Assert.*
import org.junit.Test

class NetworkRetryBudgetTest {
    @Test
    fun repeatedFailuresHaveABoundedBackoffWithoutResettingTheirBudget() {
        val budget = NetworkRetryBudget()
        for (delay in listOf(1000L, 2000L, 4000L, 8000L)) {
            assertEquals(delay, budget.delayMs("a"))
            assertEquals(delay, budget.delayMs("a"))
            budget.recordAttempt("a")
        }
        assertNull(budget.delayMs("a"))
        assertNull(budget.delayMs("a"))
    }

    @Test
    fun aNewTrackOrNewPlaybackIntentGetsItsOwnBudget() {
        val budget = NetworkRetryBudget()
        budget.delayMs("a"); budget.recordAttempt("a")
        assertEquals(2000L, budget.delayMs("a"))
        assertEquals(1000L, budget.delayMs("b"))
        budget.recordAttempt("b")
        budget.reset()
        assertEquals(1000L, budget.delayMs("b"))
    }

    @Test
    fun aRetryCannotReviveAnOldTrackOrOverridePauseStopOrSuccessfulPlayback() {
        assertTrue(canRetryNetworkPlayback("a", "a", true, true, true))
        assertFalse(canRetryNetworkPlayback("a", "b", true, true, true))
        assertFalse(canRetryNetworkPlayback("a", null, true, true, true))
        assertFalse(canRetryNetworkPlayback("a", "a", false, true, true))
        assertFalse(canRetryNetworkPlayback("a", "a", true, true, false))
        assertFalse(canRetryNetworkPlayback("a", "a", true, false, true))
    }
}
