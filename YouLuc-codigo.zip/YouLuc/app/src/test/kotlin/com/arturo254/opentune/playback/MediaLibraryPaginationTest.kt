package com.arturo254.opentune.playback

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MediaLibraryPaginationTest {
    @Test
    fun pagesDoNotRepeatOrSkipItems() {
        val items = (0 until 7).toList()
        assertEquals(listOf(0, 1, 2), mediaLibraryPage(items, 0, 3))
        assertEquals(listOf(3, 4, 5), mediaLibraryPage(items, 1, 3))
        assertEquals(listOf(6), mediaLibraryPage(items, 2, 3))
        assertTrue(mediaLibraryPage(items, 3, 3).isEmpty())
    }

    @Test
    fun invalidAndOverflowingRequestsReturnEmptyPages() {
        val items = listOf(1, 2)
        assertTrue(mediaLibraryPage(items, -1, 1).isEmpty())
        assertTrue(mediaLibraryPage(items, 0, 0).isEmpty())
        assertTrue(mediaLibraryPage(items, 0, -1).isEmpty())
        assertTrue(mediaLibraryPage(items, Int.MAX_VALUE, Int.MAX_VALUE).isEmpty())
        assertEquals(items, mediaLibraryPage(items, 0, Int.MAX_VALUE))
    }
}
