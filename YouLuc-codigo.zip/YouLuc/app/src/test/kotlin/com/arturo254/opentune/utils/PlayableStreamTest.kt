package com.arturo254.opentune.utils

import com.arturo254.opentune.innertube.models.response.PlayerResponse
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Test

class PlayableStreamTest {
    @Test
    fun rejectedUrlFallsBackToAnotherFormatFromTheSameClient() = runBlocking {
        val preferred = audioFormat(251, "https://example.com/opus")
        val fallback = audioFormat(140, "https://example.com/aac")
        val probed = mutableListOf<String>()

        val result = YTPlayerUtils.firstPlayableStream(
            candidates = sequenceOf(preferred, fallback),
            responseExpirySeconds = 120,
            resolveUrl = { it.url },
            validateUrl = { url ->
                probed.add(url)
                url == fallback.url
            },
        )

        assertEquals(listOf(preferred.url, fallback.url), probed)
        assertEquals(YTPlayerUtils.PlayableStream(fallback, requireNotNull(fallback.url), 120), result)
    }

    @Test
    fun expiredUrlIsSkippedBeforeProbing() = runBlocking {
        val expired = audioFormat(251, "https://example.com/opus?expire=0")
        val fallback = audioFormat(140, "https://example.com/aac")
        val probed = mutableListOf<String>()

        val result = YTPlayerUtils.firstPlayableStream(
            candidates = sequenceOf(expired, fallback),
            responseExpirySeconds = 120,
            resolveUrl = { it.url },
            validateUrl = { probed.add(it) },
        )

        assertEquals(listOf(fallback.url), probed)
        assertEquals(fallback, result?.format)
    }

    private fun audioFormat(itag: Int, url: String) = PlayerResponse.StreamingData.Format(
        itag = itag,
        url = url,
        mimeType = "audio/webm",
        bitrate = 128_000,
        width = null,
        height = null,
        contentLength = null,
        quality = "tiny",
        fps = null,
        qualityLabel = null,
        averageBitrate = null,
        audioQuality = null,
        approxDurationMs = null,
        audioSampleRate = null,
        audioChannels = null,
        loudnessDb = null,
        lastModified = null,
        signatureCipher = null,
        cipher = null,
    )
}
