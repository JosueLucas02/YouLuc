package com.arturo254.opentune.playback

import org.junit.Assert.*
import org.junit.Test

class DiagnosticRedactorTest {
    @Test
    fun signedAddressesAndUserInfoRetainOnlyTheHost() {
        val text = DiagnosticRedactor.redact("HTTP 403 https://user:PRIVATE@r1.googlevideo.com/videoplayback/PRIVATE?sig=SIGNED&token=TOKEN")
        assertTrue(text.contains("HTTP 403"))
        assertTrue(text.contains("r1.googlevideo.com"))
        for (secret in listOf("PRIVATE", "SIGNED", "TOKEN", "videoplayback", "user:")) assertFalse(text.contains(secret))
    }

    @Test
    fun headersAndInlineSecretsAreRemovedFromExceptionText() {
        val text = DiagnosticRedactor.redact("""
            Authorization: Bearer TOPSECRET
            Cookie: SID=COOKIEVALUE
            {"accessToken":"ACCESSVALUE","po_token":"POVALUE","visitorData":"VISITORVALUE"}
            Contact user@example.com at content://media/private/path
        """.trimIndent())
        for (secret in listOf("TOPSECRET", "COOKIEVALUE", "ACCESSVALUE", "POVALUE", "VISITORVALUE", "user@example.com", "private/path")) {
            assertFalse("Leaked $secret in $text", text.contains(secret))
        }
    }

    @Test
    fun structuredFieldsKeepDiagnosticTypesAndHideSensitiveKeys() {
        assertEquals("<redacted>", DiagnosticRedactor.field("account_email", "someone"))
        assertEquals("<redacted>", DiagnosticRedactor.field("Authorization", "value"))
        assertEquals("<redacted>", DiagnosticRedactor.field("api_key", "value"))
        assertEquals("<redacted>", DiagnosticRedactor.field("sp_dc", "value"))
        assertEquals(403, DiagnosticRedactor.field("http_status", 403))
        assertEquals(true, DiagnosticRedactor.field("playing", true))
        assertEquals("track-id", DiagnosticRedactor.field("media_id", "track-id"))
        assertEquals("Conexión interrumpida", DiagnosticRedactor.redact("Conexión interrumpida"))
    }

    @Test
    fun punctuationInsideAnAddressCannotExposeTheRestOfItsPath() {
        val text = DiagnosticRedactor.redact(
            "https://example.com/audio(track)/PRIVATE?sig=SIGNED https://example.com/audio]PRIVATE?sig=SIGNED"
        )
        assertFalse(text.contains("PRIVATE"))
        assertFalse(text.contains("SIGNED"))
        assertFalse(text.contains("audio"))
    }
}
