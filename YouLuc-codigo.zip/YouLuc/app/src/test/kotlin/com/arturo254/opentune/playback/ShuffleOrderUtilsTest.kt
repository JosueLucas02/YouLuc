/*
 * OpenTune Project Original (2026)
 * Arturo254 (github.com/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */

package com.arturo254.opentune.playback

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class ShuffleOrderUtilsTest {
    @Test
    fun currentFirstShuffleOrder_placesCurrentItemFirst() {
        val order = currentFirstShuffleOrder(itemCount = 25, currentIndex = 12, seed = 1234L)

        assertEquals(12, order.first())
        assertArrayEquals((0 until 25).toList().toIntArray(), order.sortedArray())
    }

    @Test
    fun currentFirstShuffleOrder_coercesOutOfRangeCurrentIndex() {
        val lowOrder = currentFirstShuffleOrder(itemCount = 3, currentIndex = -10, seed = 1L)
        val highOrder = currentFirstShuffleOrder(itemCount = 3, currentIndex = 99, seed = 1L)

        assertEquals(0, lowOrder.first())
        assertEquals(2, highOrder.first())
    }
}
