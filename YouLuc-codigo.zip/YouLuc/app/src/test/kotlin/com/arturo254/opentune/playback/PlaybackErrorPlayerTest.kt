package com.arturo254.opentune.playback

import android.os.Bundle
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import org.junit.Assert.*
import org.junit.Test
import java.lang.reflect.Proxy

class PlaybackErrorPlayerTest {
    private class FakePlayer {
        var error: PlaybackException? = null
        val listeners = mutableSetOf<Player.Listener>()
        val player = Proxy.newProxyInstance(Player::class.java.classLoader, arrayOf(Player::class.java)) { _, method, args ->
            when (method.name) {
                "getPlayerError" -> error
                "addListener" -> { listeners.add(args!![0] as Player.Listener); null }
                "removeListener" -> { listeners.remove(args!![0] as Player.Listener); null }
                else -> error("Unexpected player call: ${method.name}")
            }
        } as Player
    }

    private class TestPlaybackException(message: String) : PlaybackException(
        message, null, PlaybackException.ERROR_CODE_IO_UNSPECIFIED, Bundle.EMPTY, 0L,
    )

    private fun error(message: String): PlaybackException = TestPlaybackException(message)

    @Test
    fun callbacksAndLateConnectionsReceiveTheSameReadableError() {
        val fake = FakePlayer()
        val source = error("Source error")
        val friendly = error("Could not connect to the music server")
        var resolutions = 0
        val player = PlaybackErrorPlayer(fake.player) { resolutions++; friendly }
        var callbackError: PlaybackException? = null
        var changedError: PlaybackException? = null
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) { callbackError = error }
            override fun onPlayerErrorChanged(error: PlaybackException?) { changedError = error }
        })
        fake.error = source
        fake.listeners.forEach { it.onPlayerErrorChanged(source); it.onPlayerError(source) }

        assertSame(friendly, callbackError)
        assertSame(friendly, changedError)
        assertSame(friendly, player.playerError)
        assertEquals(1, resolutions)

        fake.error = null
        fake.listeners.forEach { it.onPlayerErrorChanged(null) }
        assertNull(changedError)
        assertNull(player.playerError)
    }

    @Test
    fun listenerRegistrationAndRemovalKeepTheOriginalIdentity() {
        val fake = FakePlayer()
        val player = PlaybackErrorPlayer(fake.player) { it }
        val listener = object : Player.Listener {}
        player.addListener(listener)
        player.addListener(listener)
        assertEquals(1, fake.listeners.size)
        player.removeListener(listener)
        player.removeListener(listener)
        assertTrue(fake.listeners.isEmpty())
    }

    @Test
    fun forwardsMediaMetadataAndMediaItemEventsToWrappedListener() {
        val fake = FakePlayer()
        val player = PlaybackErrorPlayer(fake.player) { it }
        var receivedTitle: CharSequence? = null
        var receivedTransitionId: String? = null
        val listener = object : Player.Listener {
            override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) {
                receivedTitle = mediaMetadata.title
            }
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                receivedTransitionId = mediaItem?.mediaId
            }
        }
        player.addListener(listener)
        val item = androidx.media3.common.MediaItem.Builder().setMediaId("song-42").build()
        val metadata = androidx.media3.common.MediaMetadata.Builder().setTitle("Test Title").build()
        fake.listeners.forEach {
            it.onMediaItemTransition(item, Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED)
            it.onMediaMetadataChanged(metadata)
        }
        assertEquals("Test Title", receivedTitle)
        assertEquals("song-42", receivedTransitionId)
    }
}
