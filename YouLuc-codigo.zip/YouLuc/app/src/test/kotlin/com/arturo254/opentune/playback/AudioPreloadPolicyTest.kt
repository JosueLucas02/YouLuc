package com.arturo254.opentune.playback

import org.junit.Assert.*
import org.junit.Test

class AudioPreloadPolicyTest {
    private fun ids(order: List<Int>, current: Int, count: Int, repeat: Boolean = false, names: List<String> = (0..9).map { "song-$it" }) =
        upcomingAudioIds(order.size, current, count, idAt = { names[it] }, nextIndex = {
            val next = order.indexOf(it) + 1
            order.getOrNull(next) ?: if (repeat) order.first() else -1
        })

    @Test
    fun preloadingUsesTheRealShuffleOrder() {
        assertEquals(listOf("song-4", "song-1", "song-3"), ids(listOf(2, 4, 1, 3, 0), 2, 3))
        assertEquals(listOf("song-1", "song-2", "song-3"), ids(listOf(0, 1, 2, 3), 0, 5))
    }

    @Test
    fun repeatAllCannotRecacheTheCurrentSongOrLoopForever() {
        assertEquals(listOf("song-0", "song-1"), ids(listOf(0, 1, 2), 2, 10, repeat = true))
        assertTrue(ids(listOf(0), 0, 10, repeat = true).isEmpty())
        assertTrue(ids(listOf(0, 1), 1, 10).isEmpty())
    }

    @Test
    fun duplicateAndMissingIdsDoNotWasteThePreloadSlots() {
        assertEquals(listOf("b", "c"), ids(listOf(0, 1, 2, 3, 4, 5), 0, 5, true,
            listOf("a", "", "b", "b", "a", "c")))
        assertTrue(upcomingAudioIds(0, -1, 5, { error("No item access") }, { error("No traversal") }).isEmpty())
        assertTrue(upcomingAudioIds(2, 0, 0, { error("No item access") }, { error("No traversal") }).isEmpty())
    }

    @Test
    fun malformedOrHugeQueuesAreBounded() {
        var steps = 0
        val result = upcomingAudioIds(50_000, 0, 10, { if (it == 0) "current" else "" }, { steps++; it + 1 })
        assertTrue(result.isEmpty())
        assertEquals(100, steps)
        assertTrue(upcomingAudioIds(2, 0, 5, { "song-$it" }, { 100 }).isEmpty())
    }

    private fun allowed(
        count: Int = 5, cache: Int = 1024, playing: Boolean = true, ready: Boolean = true,
        connected: Boolean = true, metered: Boolean = false, allowMetered: Boolean = false,
        buffer: Long = 20_000, full: Boolean = false, testBypass: Boolean = false,
    ) = AudioPreloadPolicy.canPreload(count, cache, playing, ready, connected, metered, allowMetered, buffer, full, testBypass)

    @Test
    fun mobileDataRequiresPermissionAndPlaybackKeepsPriority() {
        assertTrue(allowed())
        assertFalse(allowed(metered = true))
        assertTrue(allowed(metered = true, allowMetered = true))
        assertFalse(allowed(connected = false))
        assertFalse(allowed(playing = false))
        assertFalse(allowed(ready = false))
        assertFalse(allowed(buffer = 1_000))
        assertTrue(allowed(buffer = 1_000, full = true))
        assertFalse(allowed(testBypass = true))
        assertFalse(allowed(cache = 0))
        assertFalse(allowed(count = 0))
    }

    @Test
    fun batchBudgetsRespectSmallAndUnlimitedCacheSettings() {
        val mb = AudioPreloadPolicy.MIB
        assertEquals(64 * mb, AudioPreloadPolicy.budgetBytes(128))
        assertEquals(128 * mb, AudioPreloadPolicy.budgetBytes(1024))
        assertEquals(128 * mb, AudioPreloadPolicy.budgetBytes(-1))
        assertEquals(128 * mb, AudioPreloadPolicy.budgetBytes(Int.MAX_VALUE))
        assertEquals(0, AudioPreloadPolicy.budgetBytes(0))
        assertEquals(0, AudioPreloadPolicy.budgetBytes(-100))
    }

    @Test
    fun partialFilesCannotMixAudioFormats() {
        val free = 100 * AudioPreloadPolicy.MIB
        assertEquals(400L, AudioPreloadPolicy.missingBytes(1000, 600, 251, 251, 500, free))
        assertNull(AudioPreloadPolicy.missingBytes(1000, 600, 140, 251, 500, free))
        assertNull(AudioPreloadPolicy.missingBytes(1000, 600, null, 251, 500, free))
        assertEquals(1000L, AudioPreloadPolicy.missingBytes(1000, 0, 140, 251, 1000, free))
    }

    @Test
    fun unknownOversizedAndLowSpaceRequestsCannotStartAnUnboundedDownload() {
        val free = 100 * AudioPreloadPolicy.MIB
        assertNull(AudioPreloadPolicy.missingBytes(null, 0, null, 251, free, free))
        assertNull(AudioPreloadPolicy.missingBytes(0, 0, null, 251, free, free))
        assertNull(AudioPreloadPolicy.missingBytes(40 * AudioPreloadPolicy.MIB, 0, null, 251, free, free))
        assertNull(AudioPreloadPolicy.missingBytes(1000, 0, null, 251, 999, free))
        assertNull(AudioPreloadPolicy.missingBytes(1000, 0, null, 251, 1000, AudioPreloadPolicy.FREE_SPACE_RESERVE))
    }
}
