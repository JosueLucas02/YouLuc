/*
 * OpenTune Project Original (2026)
 * Arturo254 (github.com/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */

package com.arturo254.opentune.playback

import androidx.media3.common.PlaybackException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException
import java.io.InterruptedIOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.SocketException
import java.net.UnknownHostException

/**
 * The Media3 placeholders ("Source error", "Remote error", ...) are the only messages the car and
 * the app used to show when a track could not be played. These tests lock the classification down
 * so that no error code and no HTTP status can end up being described with one of them.
 */
class PlaybackErrorMessagesTest {

    @Test
    fun `opaque placeholders are detected`() {
        assertTrue(PlaybackErrorMessages.isOpaque("Source error"))
        assertTrue(PlaybackErrorMessages.isOpaque("source error"))
        assertTrue(PlaybackErrorMessages.isOpaque("Remote error"))
        assertTrue(PlaybackErrorMessages.isOpaque("Unexpected runtime error"))
        assertTrue(PlaybackErrorMessages.isOpaque("Playback error"))
        assertTrue(PlaybackErrorMessages.isOpaque(""))
        assertTrue(PlaybackErrorMessages.isOpaque(null))
    }

    @Test
    fun `real reasons are not treated as opaque`() {
        assertFalse(PlaybackErrorMessages.isOpaque("The server is not responding"))
        assertFalse(PlaybackErrorMessages.isOpaque("HTTP 403"))
        assertFalse(PlaybackErrorMessages.isOpaque("This track can't be played on this device"))
    }

    @Test
    fun `placeholders with a suffix are still opaque`() {
        assertTrue(PlaybackErrorMessages.isOpaque("Source error while loading the manifest"))
        assertTrue(PlaybackErrorMessages.isOpaque("  Remote error  "))
    }

    @Test
    fun `network failures are classified by their own kind`() {
        assertEquals(
            PlaybackErrorMessages.Kind.NO_INTERNET,
            PlaybackErrorMessages.kindOf(
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                null
            )
        )
        assertEquals(
            PlaybackErrorMessages.Kind.TIMEOUT,
            PlaybackErrorMessages.kindOf(
                PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
                null
            )
        )
    }

    @Test
    fun `source wrappers retain the underlying network failure`() {
        for (cause in listOf(UnknownHostException("offline"), ConnectException("refused"), SocketException("Connection reset"))) {
            assertEquals(
                PlaybackErrorMessages.Kind.NO_INTERNET,
                PlaybackErrorMessages.kindOf(PlaybackException.ERROR_CODE_IO_UNSPECIFIED, null, IOException("Source error", cause)),
            )
        }
        assertEquals(
            PlaybackErrorMessages.Kind.TIMEOUT,
            PlaybackErrorMessages.kindOf(PlaybackException.ERROR_CODE_REMOTE_ERROR, null, IOException(SocketTimeoutException("timeout"))),
        )
    }

    @Test
    fun `total call deadlines remain retryable timeouts`() {
        assertEquals(
            PlaybackErrorMessages.Kind.TIMEOUT,
            PlaybackErrorMessages.kindOf(PlaybackException.ERROR_CODE_IO_UNSPECIFIED, null,
                IOException("Source error", InterruptedIOException("timeout"))),
        )
        assertEquals(
            PlaybackErrorMessages.Kind.GENERIC,
            PlaybackErrorMessages.kindOf(PlaybackException.ERROR_CODE_IO_UNSPECIFIED, null,
                InterruptedIOException("read interrupted")),
        )
    }

    @Test
    fun `cyclic error chains terminate`() {
        val first = IOException("first")
        val second = IOException("second", first)
        first.initCause(second)
        assertEquals(
            PlaybackErrorMessages.Kind.GENERIC,
            PlaybackErrorMessages.kindOf(PlaybackException.ERROR_CODE_IO_UNSPECIFIED, null, first),
        )
    }

    @Test
    fun `http status drives the classification`() {
        assertEquals(
            PlaybackErrorMessages.Kind.RATE_LIMITED,
            PlaybackErrorMessages.kindOf(PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS, 429)
        )
        assertEquals(
            PlaybackErrorMessages.Kind.SERVER,
            PlaybackErrorMessages.kindOf(PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS, 503)
        )
        assertEquals(
            PlaybackErrorMessages.Kind.NO_STREAM,
            PlaybackErrorMessages.kindOf(PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS, 403)
        )
        assertEquals(
            PlaybackErrorMessages.Kind.NO_STREAM,
            PlaybackErrorMessages.kindOf(PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS, 404)
        )
    }

    @Test
    fun `unsupported formats are told apart from network failures`() {
        assertEquals(
            PlaybackErrorMessages.Kind.UNSUPPORTED_FORMAT,
            PlaybackErrorMessages.kindOf(
                PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
                null
            )
        )
        assertEquals(
            PlaybackErrorMessages.Kind.UNSUPPORTED_FORMAT,
            PlaybackErrorMessages.kindOf(
                PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
                null
            )
        )
    }

    @Test
    fun `every failure ends up in a kind that has a readable message`() {
        val codes = listOf(
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
            PlaybackException.ERROR_CODE_IO_NO_PERMISSION,
            PlaybackException.ERROR_CODE_IO_UNSPECIFIED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_UNSUPPORTED,
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
            PlaybackException.ERROR_CODE_REMOTE_ERROR,
        )
        val statuses = listOf(null, 403, 404, 410, 416, 429, 500, 503)

        for (code in codes) {
            for (status in statuses) {
                val kind = PlaybackErrorMessages.kindOf(code, status)
                assertTrue(
                    "Unexpected kind $kind for code $code and status $status",
                    kind in PlaybackErrorMessages.Kind.values()
                )
            }
        }
    }
}
