package com.arturo254.opentune.playback

import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Request
import okhttp3.Response
import okio.Timeout
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.reflect.KClass

class CancellableCacheWriteTest {
    @Test(timeout = 10_000)
    fun finishingAWriteAlsoClosesItsResources() = runBlocking {
        val wrote = AtomicBoolean()
        val closed = AtomicBoolean()
        runCancellableCacheWrite({ wrote.set(true) }, { closed.set(true) })
        assertTrue(wrote.get())
        assertTrue(closed.get())
    }

    @Test(timeout = 10_000)
    fun cancellationStopsABlockedWriterAndRunsItsCleanup() = runBlocking {
        val started = CountDownLatch(1)
        val unblocked = CountDownLatch(1)
        val closed = AtomicBoolean()
        val stopped = AtomicBoolean()
        val task = async(start = CoroutineStart.UNDISPATCHED) {
            runCancellableCacheWrite({
                started.countDown()
                try { unblocked.await() } finally { stopped.set(true) }
            }, { closed.set(true); unblocked.countDown() })
        }
        assertTrue(withContext(Dispatchers.IO) { started.await(2, TimeUnit.SECONDS) })
        task.cancelAndJoin()
        assertTrue(closed.get())
        assertTrue(stopped.get())
    }

    @Test(timeout = 10_000)
    fun aWriteFailureReleasesResourcesAndRetainsItsCause() = runBlocking {
        val error = IOException("storage full")
        val closed = AtomicBoolean()
        val caught = try {
            runCancellableCacheWrite({ throw error }, { closed.set(true) })
            null
        } catch (caught: IOException) { caught }
        assertSame(error, caught)
        assertTrue(closed.get())
    }

    private class FakeCall : Call {
        var cancelled = false
        override fun request() = Request.Builder().url("https://example.com/audio").build()
        override fun cancel() { cancelled = true }
        override fun isCanceled() = cancelled
        override fun isExecuted() = false
        override fun timeout() = Timeout()
        override fun <T : Any> tag(type: KClass<T>): T? = null
        override fun <T> tag(type: Class<out T>): T? = null
        override fun <T : Any> tag(type: KClass<T>, computeIfAbsent: () -> T): T = error("Unexpected tag write")
        override fun <T : Any> tag(type: Class<T>, computeIfAbsent: () -> T): T = error("Unexpected tag write")
        override fun clone(): Call = FakeCall()
        override fun enqueue(responseCallback: Callback) = error("Not executed")
        override fun execute(): Response = error("Not executed")
    }

    @Test
    fun cancellationIsIsolatedToThePreloaderAndAlsoCoversLateCalls() {
        val calls = mutableListOf<FakeCall>()
        val factory = object : Call.Factory {
            override fun newCall(request: Request): Call = FakeCall().also(calls::add)
        }
        val foreground = factory.newCall(FakeCall().request()) as FakeCall
        val preload = PreloadCallFactory(factory)
        val active = preload.newCall(FakeCall().request()) as FakeCall
        preload.cancel()
        val late = preload.newCall(FakeCall().request()) as FakeCall
        assertFalse(foreground.cancelled)
        assertTrue(active.cancelled)
        assertTrue(late.cancelled)
    }
}
