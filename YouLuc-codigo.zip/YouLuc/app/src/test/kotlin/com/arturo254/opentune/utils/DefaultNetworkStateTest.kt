package com.arturo254.opentune.utils

import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.flow.take
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class DefaultNetworkStateTest {
    @Test
    fun validationCanRecoverWithoutAnotherAvailableCallback() {
        val state = DefaultNetworkState<String>(false)
        state.available("wifi")
        state.capabilitiesChanged("wifi", true, false)
        assertFalse(state.status.value)
        state.capabilitiesChanged("wifi", true, true)
        assertTrue(state.status.value)
        state.capabilitiesChanged("wifi", true, false)
        assertFalse(state.status.value)
    }

    @Test
    fun lateCallbacksCannotUndoAHandoffToAnotherNetwork() {
        val state = DefaultNetworkState<String>(false)
        state.available("wifi")
        state.capabilitiesChanged("wifi", true, true)
        state.available("cellular")
        state.capabilitiesChanged("cellular", true, true)
        state.lost("wifi")
        state.capabilitiesChanged("wifi", false, false)
        state.blockedChanged("wifi", true)
        assertTrue(state.status.value)
        state.lost("cellular")
        assertFalse(state.status.value)
        state.capabilitiesChanged("cellular", true, true)
        assertFalse(state.status.value)
    }

    @Test
    fun removingADataRestrictionStillRequiresValidatedInternet() {
        val state = DefaultNetworkState<String>(false)
        state.available("wifi")
        state.capabilitiesChanged("wifi", true, true)
        state.blockedChanged("wifi", true)
        assertFalse(state.status.value)
        state.capabilitiesChanged("wifi", true, true)
        assertFalse(state.status.value)
        state.blockedChanged("wifi", false)
        assertTrue(state.status.value)
        state.capabilitiesChanged("wifi", false, true)
        assertFalse(state.status.value)
        state.blockedChanged("wifi", false)
        assertFalse(state.status.value)
    }

    @Test
    fun connectivityIsReplayedToEverySubscriber() = runBlocking {
        val state = DefaultNetworkState<String>(false)
        val first = mutableListOf<Boolean>()
        val second = mutableListOf<Boolean>()
        val a = launch(start = CoroutineStart.UNDISPATCHED) { state.status.take(2).toList(first) }
        val b = launch(start = CoroutineStart.UNDISPATCHED) { state.status.take(2).toList(second) }
        state.available("wifi")
        state.capabilitiesChanged("wifi", true, true)
        a.join(); b.join()
        assertEquals(listOf(false, true), first)
        assertEquals(first, second)
        assertTrue(state.status.value)
    }
}
