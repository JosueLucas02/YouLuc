package com.arturo254.opentune.utils

import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody
import okio.Buffer
import okio.Timeout
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import kotlin.reflect.KClass

class StreamStatusProbeTest {
    private class FakeCall : Call {
        lateinit var callback: Callback
        var cancelled = false
        private var executed = false
        override fun request() = Request.Builder().url("https://example.com/audio").build()
        override fun enqueue(responseCallback: Callback) { executed = true; callback = responseCallback }
        override fun cancel() { cancelled = true }
        override fun isCanceled() = cancelled
        override fun isExecuted() = executed
        override fun timeout() = Timeout()
        override fun <T : Any> tag(type: KClass<T>): T? = null
        override fun <T> tag(type: Class<out T>): T? = null
        override fun <T : Any> tag(type: KClass<T>, computeIfAbsent: () -> T): T = error("Unexpected tag write")
        override fun <T : Any> tag(type: Class<T>, computeIfAbsent: () -> T): T = error("Unexpected tag write")
        override fun clone(): Call = FakeCall()
        override fun execute(): Response = error("Only asynchronous probes are allowed")
        fun respond(body: ResponseBody, code: Int = 206) {
            callback.onResponse(this, Response.Builder().request(request()).protocol(Protocol.HTTP_1_1)
                .code(code).message("test").body(body).build())
        }
    }

    private class Body : ResponseBody() {
        var closed = false
        override fun contentType(): MediaType? = null
        override fun contentLength() = 0L
        override fun source() = Buffer()
        override fun close() { closed = true; super.close() }
    }

    @Test
    fun aStatusProbeReleasesTheResponseBody() = runBlocking {
        val call = FakeCall()
        val body = Body()
        val status = async(start = CoroutineStart.UNDISPATCHED) { call.awaitStatusCode() }
        call.respond(body)
        assertEquals(206, status.await())
        assertTrue(body.closed)
    }

    @Test
    fun skippingCancelsTheCallAndClosesALateResponse() = runBlocking {
        val call = FakeCall()
        val status = async(start = CoroutineStart.UNDISPATCHED) { call.awaitStatusCode() }
        status.cancel()
        status.join()
        assertTrue(call.cancelled)
        val body = Body()
        call.respond(body)
        assertTrue(body.closed)
        assertTrue(status.isCancelled)
    }

    @Test
    fun aNetworkFailureKeepsItsOriginalCause() = runBlocking {
        val call = FakeCall()
        val error = IOException("connection dropped")
        val failure = async(start = CoroutineStart.UNDISPATCHED) {
            try { call.awaitStatusCode(); null } catch (error: IOException) { error }
        }
        call.callback.onFailure(call, error)
        assertSame(error, failure.await())
    }
}
