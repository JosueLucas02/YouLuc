package com.arturo254.opentune.playback

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipInputStream
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class PlaybackDiagnosticStoreTest {
    @get:Rule val temporary = TemporaryFolder()
    private fun entries(store: PlaybackDiagnosticStore): Map<String, String> {
        val output = ByteArrayOutputStream()
        store.export(output, "test report")
        val files = linkedMapOf<String, String>()
        ZipInputStream(ByteArrayInputStream(output.toByteArray())).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                files[entry.name] = zip.readBytes().toString(Charsets.UTF_8)
            }
        }
        return files
    }

    @Test
    fun rotationKeepsCompleteRecentRecordsWithinItsByteBudget() {
        val folder = temporary.newFolder()
        val store = PlaybackDiagnosticStore(folder, 128, 2)
        repeat(8) { store.append("{\"event\":$it,\"text\":\"${"é".repeat(40)}\"}", 1000L + it) }
        val exported = entries(store)
        assertEquals("test report", exported["report.txt"])
        val rows = (2 downTo 0).flatMap { exported["events-$it.jsonl"].orEmpty().lineSequence().filter(String::isNotBlank).toList() }
        assertEquals(3, rows.size)
        assertTrue(rows.first().contains("\"event\":5"))
        assertTrue(rows.last().contains("\"event\":7"))
        assertFalse(rows.joinToString().contains('�'))
        assertTrue(folder.listFiles()!!.all { it.length() <= 128 })
    }

    @Test
    fun incidentRetainsTheLeadUpAndRecoveryAfterTheJournalRollsOver() {
        val folder = temporary.newFolder()
        val store = PlaybackDiagnosticStore(folder, 128, 2)
        store.append("{\"event\":\"before\"}", 1000)
        store.append("{\"event\":\"error\"}", 1001, incident = true)
        store.append("{\"event\":\"retry\"}", 1002)
        store.append("{\"event\":\"error-again\"}", 1003, incident = true)
        store.append("{\"event\":\"recovered\"}", 1004)
        repeat(12) { store.append("{\"event\":\"later-$it-${"x".repeat(70)}\"}", 200_000L + it) }
        val exported = entries(PlaybackDiagnosticStore(folder, 128, 2))
        val incident = requireNotNull(exported["last-incident.jsonl"])
        for (event in listOf("before", "error", "retry", "error-again", "recovered")) assertTrue(incident.contains(event))
        assertFalse(incident.contains("later-"))
        assertTrue(File(folder, "last-incident.jsonl").length() <= 384)
    }

    @Test
    fun restartPreservesTheJournalAndSeparatesAnyInterruptedTail() {
        val folder = temporary.newFolder()
        File(folder, "events-0.jsonl").writeText("{\"event\":\"interrupted")
        PlaybackDiagnosticStore(folder, 128, 2).append("{\"event\":\"new-session\"}", 1000)
        val content = entries(PlaybackDiagnosticStore(folder, 128, 2))["events-0.jsonl"]!!
        assertTrue(content.endsWith("\n{\"event\":\"new-session\"}\n"))
    }

    @Test
    fun incidentReservesRoomForRecoveryWhenTheJournalIsFull() {
        val folder = temporary.newFolder()
        val store = PlaybackDiagnosticStore(folder, 128, 2)
        repeat(8) { store.append("{\"event\":\"before-$it-${"x".repeat(70)}\"}", 1000L + it) }
        store.append("{\"event\":\"error\"}", 1010, incident = true)
        store.append("{\"event\":\"recovered\"}", 1011)
        val incident = entries(store)["last-incident.jsonl"]!!
        assertTrue(incident.contains("before-7"))
        assertTrue(incident.contains("recovered"))
        assertTrue(incident.toByteArray(Charsets.UTF_8).size <= 384)
    }

    @Test
    fun clearDeletesOnlyTheOwnedDiagnosticFiles() {
        val folder = temporary.newFolder()
        val keep = File(folder, "unrelated.keep").apply { writeText("keep") }
        val store = PlaybackDiagnosticStore(folder, 128, 2)
        store.append("{\"event\":\"error\"}", 1000, incident = true)
        store.clear()
        assertEquals(setOf("report.txt"), entries(store).keys)
        assertEquals("keep", keep.readText())
    }

    @Test
    fun oversizedEventsDoNotBreakTheBoundAndRawNewlinesAreRejected() {
        val folder = temporary.newFolder()
        val store = PlaybackDiagnosticStore(folder, 128, 1)
        store.append("x".repeat(2000), 1000)
        assertTrue(entries(store)["events-0.jsonl"]!!.contains("oversized_record_dropped"))
        assertTrue(folder.listFiles()!!.all { it.length() <= 128 })
        assertThrows(IllegalArgumentException::class.java) { store.append("bad\nrecord", 1001) }
    }
}
