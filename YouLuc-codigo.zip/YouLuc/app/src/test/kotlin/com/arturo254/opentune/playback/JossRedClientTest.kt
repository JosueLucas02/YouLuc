package com.arturo254.opentune.playback

import com.arturo254.jossredconnect.JossRedClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class JossRedClientTest {
    @Test
    fun acceptsOnlyHttpUrlsAndNonemptyVideoIds() {
        assertNull(JossRedClient.streamUrl("not a URL", "track"))
        assertNull(JossRedClient.streamUrl("file:///music", "track"))
        assertNull(JossRedClient.streamUrl("https://example.com/stream", ""))
    }

    @Test
    fun appendsOneEncodedPathSegmentAndPreservesQueryParameters() {
        assertEquals("https://example.com/stream/track", JossRedClient.streamUrl("https://example.com/stream/", "track"))
        assertEquals("https://example.com/stream/track?token=1", JossRedClient.streamUrl("https://example.com/stream?token=1", "track"))
        assertEquals("https://example.com/a%2Fb", JossRedClient.streamUrl("https://example.com/", "a/b"))
        assertEquals(JossRedClient.DEFAULT_BASE_URL + "track", JossRedClient.streamUrl(" ", "track"))
    }
}
