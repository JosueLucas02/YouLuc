package com.arturo254.opentune.debug

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.support.v4.media.MediaBrowserCompat
import android.support.v4.media.session.MediaControllerCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.util.Base64
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import com.arturo254.opentune.playback.MusicService
import com.arturo254.opentune.playback.PlaybackErrorMessages
import org.json.JSONObject
import timber.log.Timber
import java.util.concurrent.atomic.AtomicBoolean

/** Shell-only controls, included only in debug APKs. No library, download or cache files change. */
class PlaybackStressReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val pending = goAsync()
        val completed = AtomicBoolean()
        var bound = false
        lateinit var connection: ServiceConnection
        lateinit var timeout: Runnable
        fun complete(result: JSONObject) {
            if (!completed.compareAndSet(false, true)) return
            handler.removeCallbacks(timeout)
            pending.resultCode = if (result.optBoolean("ok")) Activity.RESULT_OK else Activity.RESULT_CANCELED
            pending.resultData = Base64.encodeToString(result.toString().toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
            if (bound) runCatching { app.unbindService(connection) }
            pending.finish()
        }
        timeout = Runnable { complete(failure("Stress command timed out")) }
        connection = object : ServiceConnection {
            override fun onServiceConnected(name: ComponentName, binder: IBinder) {
                val service = (binder as? MusicService.MusicBinder)?.service
                if (service == null) { complete(failure("Unexpected service binder")); return }
                try {
                    command(app, service, intent, ::complete) { completed.get() }
                } catch (error: Exception) {
                    complete(failure(error.message ?: error.javaClass.simpleName))
                }
            }
            override fun onServiceDisconnected(name: ComponentName) { complete(failure("Music service disconnected")) }
            override fun onNullBinding(name: ComponentName) { complete(failure("Music service returned no binder")) }
        }
        handler.postDelayed(timeout, 8_000)
        try {
            bound = app.bindService(Intent(app, MusicService::class.java), connection, Context.BIND_AUTO_CREATE)
            if (!bound) complete(failure("Could not bind music service"))
        } catch (error: Exception) {
            complete(failure(error.message ?: "Could not bind music service"))
        }
    }

    companion object {
        private val handler = Handler(Looper.getMainLooper())
        private data class SavedQueue(
            val items: List<MediaItem>, val index: Int, val position: Long,
            val playWhenReady: Boolean, val repeat: Int, val shuffle: Boolean,
            val waitingForNetwork: Boolean,
        )
        private var saved: SavedQueue? = null
        private var activeService: MusicService? = null
        private var browser: MediaBrowserCompat? = null
        private var controller: MediaControllerCompat? = null
        private var observer: Player.Listener? = null
        private var disconnected = false
        private var rawFailures = 0
        private var rawSourceErrors = 0
        private var injectedFailures = 0
        private var opaqueControllerErrors = 0
        private var controllerCallbacks = 0
        private var steps = 0
        private val tracks = mutableSetOf<String>()
        private val expire = Runnable { runCatching { restore() } }
        private val controllerObserver = object : MediaControllerCompat.Callback() {
            override fun onPlaybackStateChanged(state: PlaybackStateCompat?) {
                controllerCallbacks++
                val message = state?.errorMessage?.toString()
                if (!message.isNullOrBlank() && PlaybackErrorMessages.isOpaque(message)) opaqueControllerErrors++
                Timber.tag("PlaybackStress").i("legacy_state=%s error=%s", state?.state, message)
            }
        }

        private fun failure(message: String) = JSONObject().put("ok", false).put("error", message)

        private fun snapshot(service: MusicService): JSONObject {
            val player = service.player
            val state = controller?.playbackState
            return JSONObject().put("ok", true).put("testing", saved != null)
                .put("queueRestoreCompleted", service.queueRestoreCompleted.value)
                .put("queueSize", player.mediaItemCount).put("index", player.currentMediaItemIndex)
                .put("trackId", player.currentMediaItem?.mediaId).put("positionMs", player.currentPosition)
                .put("playing", player.isPlaying).put("state", player.playbackState)
                .put("rawError", player.playerError?.message).put("rawErrorCode", player.playerError?.errorCode)
                .put("legacyConnected", controller != null).put("legacyState", state?.state)
                .put("legacyError", state?.errorMessage?.toString())
                .put("rawFailures", rawFailures).put("rawSourceErrors", rawSourceErrors)
                .put("injectedFailures", injectedFailures)
                .put("opaqueControllerErrors", opaqueControllerErrors).put("controllerCallbacks", controllerCallbacks)
                .put("uniqueTracks", tracks.size).put("steps", steps).put("simulatedDisconnect", disconnected)
        }

        private fun command(
            context: Context, service: MusicService, intent: Intent,
            complete: (JSONObject) -> Unit, closed: () -> Boolean,
        ) {
            val player = service.player
            val action = intent.getStringExtra("command") ?: "status"
            when (action) {
                "status" -> complete(snapshot(service))
                "begin" -> {
                    check(saved == null) { "A stress test is already active; send finish before starting another" }
                    check(player.mediaItemCount >= 3) { "Open a playlist with at least 3 tracks and play one song, then run the test" }
                    saved = SavedQueue(List(player.mediaItemCount) { player.getMediaItemAt(it) },
                        player.currentMediaItemIndex, player.currentPosition, player.playWhenReady,
                        player.repeatMode, player.shuffleModeEnabled, service.waitingForNetworkConnection.value)
                    activeService = service
                    rawFailures = 0; rawSourceErrors = 0; injectedFailures = 0; opaqueControllerErrors = 0
                    controllerCallbacks = 0; steps = 0; disconnected = false; tracks.clear()
                    player.currentMediaItem?.mediaId?.let(tracks::add)
                    service.setDebugPlaybackTestOptions(bypassCache = true, disconnected = false)
                    // Recreate sources so an already-open cached DataSource cannot escape the test.
                    val original = requireNotNull(saved)
                    player.stop()
                    player.setMediaItems(original.items, original.index, original.position)
                    player.repeatMode = Player.REPEAT_MODE_ALL
                    observer = object : Player.Listener {
                        override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                            item?.mediaId?.let(tracks::add)
                            Timber.tag("PlaybackStress").i("track=%s index=%s", item?.mediaId, player.currentMediaItemIndex)
                        }
                        override fun onPlayerError(error: PlaybackException) {
                            rawFailures++
                            if (error.message?.startsWith("Source error", ignoreCase = true) == true) rawSourceErrors++
                            if (generateSequence(error as Throwable) { it.cause }.take(16)
                                    .any { it.message?.contains("AAOS stress: simulated connection loss") == true }) injectedFailures++
                            Timber.tag("PlaybackStress").i("raw_error=%s code=%s injected=%s", error.message, error.errorCode, disconnected)
                        }
                    }.also(player::addListener)
                    handler.postDelayed(expire, 10 * 60_000L)
                    browser = MediaBrowserCompat(context, ComponentName(context, MusicService::class.java),
                        object : MediaBrowserCompat.ConnectionCallback() {
                            override fun onConnected() {
                                if (closed()) { restore(); return }
                                try {
                                    controller = MediaControllerCompat(context, requireNotNull(browser).sessionToken)
                                        .also { it.registerCallback(controllerObserver, handler) }
                                    player.prepare()
                                    player.play()
                                    complete(snapshot(service))
                                } catch (error: Exception) {
                                    restore(); complete(failure(error.message ?: "Legacy controller failed"))
                                }
                            }
                            override fun onConnectionFailed() { restore(); complete(failure("Legacy media browser connection failed")) }
                        }, null).also { it.connect() }
                }
                "fault" -> {
                    check(saved != null && activeService === service) { "Start the stress test first" }
                    disconnected = intent.getBooleanExtra("enabled", false)
                    service.setDebugPlaybackTestOptions(bypassCache = true, disconnected = disconnected)
                    complete(snapshot(service))
                }
                "burst" -> {
                    check(saved != null && activeService === service) { "Start the stress test first" }
                    val count = intent.getIntExtra("count", 12)
                    val gap = intent.getIntExtra("gap_ms", 180)
                    require(count in 1..20 && gap in 50..400 && count * gap <= 6_000) { "Invalid burst count or interval" }
                    val controls = requireNotNull(controller).transportControls
                    var sent = 0
                    val started = SystemClock.elapsedRealtime()
                    val step = object : Runnable {
                        override fun run() {
                            if (closed() || saved == null) return
                            if (sent % 4 == 3) controls.skipToPrevious() else controls.skipToNext()
                            steps++; sent++
                            if (sent < count) handler.postDelayed(this, gap.toLong())
                            else handler.postDelayed({
                                if (!closed()) complete(snapshot(service).put("burstElapsedMs", SystemClock.elapsedRealtime() - started))
                            }, 150)
                        }
                    }
                    handler.post(step)
                }
                "retry" -> {
                    check(saved != null && activeService === service) { "Start the stress test first" }
                    disconnected = false
                    service.setDebugPlaybackTestOptions(bypassCache = true, disconnected = false)
                    service.waitingForNetworkConnection.value = false
                    requireNotNull(controller).transportControls.play()
                    // Explicit retry after the simulated outage; this does not assert OS reconnect handling.
                    player.prepare()
                    player.play()
                    complete(snapshot(service))
                }
                "finish" -> {
                    val result = snapshot(service)
                    restore()
                    complete(result.put("restored", true))
                }
                else -> complete(failure("Unknown stress command"))
            }
        }

        private fun restore() {
            handler.removeCallbacks(expire)
            val service = activeService
            val original = saved
            saved = null; disconnected = false
            controller?.unregisterCallback(controllerObserver)
            controller = null
            browser?.disconnect(); browser = null
            if (service != null) {
                service.setDebugPlaybackTestOptions(bypassCache = false, disconnected = false)
                observer?.let(service.player::removeListener)
                if (original != null) {
                    service.player.run {
                        stop()
                        setMediaItems(original.items, original.index, original.position)
                        repeatMode = original.repeat; shuffleModeEnabled = original.shuffle
                        playWhenReady = original.playWhenReady
                        if (original.items.isNotEmpty()) prepare()
                    }
                    service.waitingForNetworkConnection.value = original.waitingForNetwork
                }
            }
            observer = null; activeService = null
        }
    }
}
