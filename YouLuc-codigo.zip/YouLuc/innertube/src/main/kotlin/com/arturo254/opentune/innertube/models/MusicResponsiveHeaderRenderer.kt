/*
 * OpenTune Project Original (2026)
 * Arturo254 (github.com/Arturo254)
 * Licensed Under GPL-3.0 | see git history for contributors
 */

package com.arturo254.opentune.innertube.models

import kotlinx.serialization.Serializable

@Serializable
data class MusicResponsiveHeaderRenderer(
    val thumbnail: ThumbnailRenderer? = null,
    // YouLuc: YouTube a veces ya no manda "buttons" (p. ej. en "Me gusta"); antes eso rompía la pantalla.
    val buttons: List<Button> = emptyList(),
    val title: Runs,
    val subtitle: Runs = Runs(runs = emptyList()),
    val secondSubtitle: Runs? = null,
    val straplineTextOne: Runs? = null
) {
    @Serializable
    data class Button(
        val musicPlayButtonRenderer: MusicPlayButtonRenderer?,
        val menuRenderer: Menu.MenuRenderer?
    ) {
        @Serializable
        data class MusicPlayButtonRenderer(
            val playNavigationEndpoint: NavigationEndpoint?,
        )
    }
}
