package com.arturo254.jossredconnect

import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object JossRedClient {
    const val DEFAULT_BASE_URL = "https://jossred.josprox.com/yt/v2/stream/"

    private val httpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(8, TimeUnit.SECONDS)
            .readTimeout(8, TimeUnit.SECONDS)
            .callTimeout(12, TimeUnit.SECONDS)
            .build()
    }

    fun streamUrl(baseUrl: String, mediaId: String): String? {
        if (mediaId.isBlank()) return null
        val base = baseUrl.trim().ifEmpty { DEFAULT_BASE_URL }.toHttpUrlOrNull() ?: return null
        return base.newBuilder()
            .apply {
                if (base.pathSegments.lastOrNull() == "") removePathSegment(base.pathSegments.lastIndex)
            }
            .addPathSegment(mediaId)
            .build()
            .toString()
    }

    fun isAvailable(url: String): Boolean {
        val request = Request.Builder().url(url).head().build()
        return httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@use false
            val mediaType = response.header("Content-Type").orEmpty().substringBefore(';').trim()
            val length = response.header("Content-Length")?.toLongOrNull()
            length != 0L && (
                mediaType.startsWith("audio/", ignoreCase = true) ||
                    mediaType.startsWith("video/", ignoreCase = true) ||
                    mediaType.equals("application/octet-stream", ignoreCase = true)
                )
        }
    }
}
