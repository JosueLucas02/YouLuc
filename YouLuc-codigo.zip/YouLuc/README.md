# OpenTune

<div align="center">
  <img src="https://codeberg.org/Arturo254/OpenTune/raw/branch/main/fastlane/metadata/android/en-US/images/featureGraphic.png" alt="Banner de OpenTune" width="100%"/>

  ### Cliente Avanzado de YouTube Music con Material Design 3 para Android

  [![Última versión](https://img.shields.io/gitea/v/release/Arturo254/OpenTune?gitea_url=https%3A%2F%2Fcodeberg.org&style=flat-square&logo=codeberg&color=0D1117&labelColor=161B22)](https://codeberg.org/Arturo254/OpenTune/releases)
  [![Licencia](https://img.shields.io/gitea/license/Arturo254/OpenTune?gitea_url=https%3A%2F%2Fcodeberg.org&style=flat-square&logo=gnu&color=2B3137&labelColor=161B22)](https://codeberg.org/Arturo254/OpenTune/src/branch/main/LICENSE)
  [![Descargas de la última versión](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fcodeberg.org%2Fapi%2Fv1%2Frepos%2FArturo254%2FOpenTune%2Freleases%2Flatest&query=%24.assets%5B%3F%28%40.name%3D%3D%27app-universal-release.apk%27%29%5D%5B0%5D.download_count&label=descargas%20%C3%BAltima%20versi%C3%B3n&style=flat-square&logo=android&color=3DDC84)](https://codeberg.org/Arturo254/OpenTune/releases)
  [![Estado de traducción](https://badges.crowdin.net/opentune/localized.svg)](https://crowdin.com/project/opentune)
  [![Android](https://img.shields.io/badge/Plataforma-Android%207.0+-3DDC84.svg?style=flat-square&logo=android&logoColor=white&labelColor=161B22)](https://www.android.com)
  [![Estrellas](https://img.shields.io/gitea/stars/Arturo254/OpenTune?gitea_url=https%3A%2F%2Fcodeberg.org&style=flat-square&logo=codeberg&color=yellow&labelColor=161B22)](https://codeberg.org/Arturo254/OpenTune)
  [![Forks](https://img.shields.io/gitea/forks/Arturo254/OpenTune?gitea_url=https%3A%2F%2Fcodeberg.org&style=flat-square&logo=codeberg&color=blue&labelColor=161B22)](https://codeberg.org/Arturo254/OpenTune/forks)
</div>

[![English](https://img.shields.io/badge/readme.md-english-blue?style=for-the-badge)](README.en.md)

---

## Tabla de Contenido

- [Visión General](#visión-general)
- [Stack Tecnológico](#stack-tecnológico)
- [Características Principales](#características-principales)
- [Documentación](#documentación)
- [Instalación](#instalación)
- [Compilación desde Código Fuente](#compilación-desde-código-fuente)
- [Contribuciones](#contribuciones)
- [Apoya el Proyecto](#apoya-el-proyecto)
- [Reconocimientos](#reconocimientos)
- [Licencia](#licencia)

---

## Visión General

**OpenTune** es un cliente de YouTube Music de código abierto diseñado para dispositivos Android. Cuenta con una interfaz basada en Material Design 3 y ofrece herramientas para explorar, reproducir y administrar contenido musical.

El proyecto busca ofrecer una alternativa personalizable, con funciones adicionales y una experiencia de uso sencilla.

### Beneficios principales

- **Reproducción sin anuncios:** escucha música sin interrupciones publicitarias.
- **Rendimiento:** navegación y reproducción optimizadas.
- **Privacidad:** sin sistemas propios de seguimiento publicitario.
- **Personalización:** adapta la interfaz a tus preferencias.
- **Modo sin conexión:** descarga contenido para escucharlo posteriormente.

> **Nota:** OpenTune es un proyecto independiente. No está afiliado, patrocinado ni respaldado por YouTube o Google.

---

## Stack Tecnológico

<div align="center">

| Frontend | Backend | Herramientas de desarrollo |
|:--------:|:-------:|:--------------------------:|
| ![Kotlin](https://img.shields.io/badge/Kotlin-7F52FF?style=for-the-badge&logo=kotlin&logoColor=white) | ![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white) | ![Android Studio](https://img.shields.io/badge/Android%20Studio-3DDC84?style=for-the-badge&logo=androidstudio&logoColor=white) |
| ![Jetpack Compose](https://img.shields.io/badge/Jetpack%20Compose-4285F4?style=for-the-badge&logo=jetpackcompose&logoColor=white) | ![TensorFlow](https://img.shields.io/badge/TensorFlow-FF6F00?style=for-the-badge&logo=tensorflow&logoColor=white) | ![Gradle](https://img.shields.io/badge/Gradle-02303A?style=for-the-badge&logo=gradle&logoColor=white) |
| ![Material Design 3](https://img.shields.io/badge/Material%20Design%203-757575?style=for-the-badge&logo=materialdesign&logoColor=white) | | ![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white) |

</div>

---

## Características Principales

### Funcionalidad principal

<table>
<tr>
<th width="30%">Característica</th>
<th width="70%">Descripción</th>
</tr>
<tr>
<td><strong>🎵 Reproducción sin anuncios</strong></td>
<td>Disfruta de música sin interrupciones publicitarias.</td>
</tr>
<tr>
<td><strong>🔄 Reproducción en segundo plano</strong></td>
<td>Continúa escuchando mientras utilizas otras aplicaciones.</td>
</tr>
<tr>
<td><strong>🔍 Búsqueda avanzada</strong></td>
<td>Encuentra canciones, vídeos, álbumes y listas de reproducción.</td>
</tr>
<tr>
<td><strong>👤 Integración de cuenta</strong></td>
<td>Inicia sesión para sincronizar preferencias y colecciones.</td>
</tr>
<tr>
<td><strong>📚 Gestión de biblioteca</strong></td>
<td>Organiza y administra tu colección musical.</td>
</tr>
<tr>
<td><strong>📱 Modo offline</strong></td>
<td>Descarga contenido para escucharlo sin conexión.</td>
</tr>
</table>

### Mejoras de audio

<table>
<tr>
<th width="30%">Característica</th>
<th width="70%">Descripción</th>
</tr>
<tr>
<td><strong>🎤 Letras sincronizadas</strong></td>
<td>Visualiza las letras de las canciones sincronizadas con la reproducción.</td>
</tr>
<tr>
<td><strong>⚡ Omisión inteligente de silencios</strong></td>
<td>Omite automáticamente los segmentos sin audio.</td>
</tr>
<tr>
<td><strong>🔊 Normalización de volumen</strong></td>
<td>Equilibra los niveles de sonido entre diferentes pistas.</td>
</tr>
<tr>
<td><strong>🎛️ Control de tempo y tono</strong></td>
<td>Ajusta la velocidad y el tono de reproducción.</td>
</tr>
</table>

### Personalización e integración

<table>
<tr>
<th width="30%">Característica</th>
<th width="70%">Descripción</th>
</tr>
<tr>
<td><strong>🎨 Temas dinámicos</strong></td>
<td>La interfaz puede adaptarse a los colores de las portadas de álbumes.</td>
</tr>
<tr>
<td><strong>🌐 Soporte multiidioma</strong></td>
<td>Disponible en varios idiomas gracias a las traducciones de la comunidad.</td>
</tr>
<tr>
<td><strong>🚗 Android Auto</strong></td>
<td>Integración con sistemas de infoentretenimiento compatibles.</td>
</tr>
<tr>
<td><strong>🎯 Material Design 3</strong></td>
<td>Interfaz basada en los componentes y principios de Material Design 3.</td>
</tr>
<tr>
<td><strong>🖼️ Exportación de portadas</strong></td>
<td>Guarda imágenes de álbumes en alta resolución.</td>
</tr>
<tr>
<td><strong>Portadas animadas</strong></td>
<td>Guarda portadas animadas de canciones.</td>
</tr>
</table>

> **Nota sobre las portadas animadas:** esta función utiliza la API de Apple Music y la API de OpenTune. Algunas portadas pueden no estar disponibles. Puedes consultar la disponibilidad en [Canvas OpenTune](https://canvas-opentune.netlify.app/).

---

## Documentación

Para consultar información sobre la configuración, las características y el uso de la aplicación, visita nuestra documentación:

<div align="center">

[![Documentación](https://img.shields.io/badge/Documentación-GitBook-4285F4?style=for-the-badge&logo=gitbook&logoColor=white)](https://opentune.gitbook.io/)

</div>

---

## Instalación

### Requisitos del sistema

| Componente | Requisito |
|:-----------|:----------|
| Sistema operativo | Android 7.0 (Nougat) o superior |
| Arquitectura | Compatible con las arquitecturas incluidas en el APK |
| Conexión | Internet para streaming y sincronización |

### Métodos de instalación

#### Opción 1: Codeberg Releases (recomendado)

1. Visita la sección de [Releases de OpenTune](https://codeberg.org/Arturo254/OpenTune/releases).
2. Selecciona la versión estable más reciente.
3. Descarga el archivo APK correspondiente.
4. Si Android lo solicita, habilita la instalación desde esa fuente.
5. Abre el APK para completar la instalación.

#### Opción 2: Sitio web oficial

1. Visita el [sitio web oficial de OpenTune](https://opentune.qzz.io/).
2. Selecciona la opción de descarga para Android.
3. Sigue las instrucciones de instalación.

#### Opción 3: F-Droid

<div align="center">

[<img src="https://f-droid.org/badge/get-it-on.png" alt="Get it on F-Droid" height="80">](https://f-droid.org/es/packages/com.Arturo254.opentune)

</div>

#### Opción 4: OpenAPK

<div align="center">

[<img src="https://www.openapk.net/images/openapk-badge.png" alt="Get it on OpenAPK" height="80">](https://www.openapk.net/opentune/com.Arturo254.opentune/)

</div>

> **Aviso de seguridad:** descarga OpenTune únicamente desde sus canales oficiales. Evita instalar APK procedentes de fuentes desconocidas o no verificadas.

---

## Compilación desde Código Fuente

### Requisitos previos

| Herramienta | Requisito |
|:------------|:----------|
| Android Studio | Versión compatible con el proyecto |
| JDK | 17 o superior |
| Android SDK | API 35 |
| Git | Versión reciente |
| Gradle | Versión indicada por el proyecto mediante Gradle Wrapper |
| Kotlin | Versión configurada en el proyecto |

### Configuración del entorno

Clona el repositorio:

```bash
git clone https://codeberg.org/Arturo254/OpenTune.git
````

Entra al directorio:

```
cd OpenTune
```

Actualiza los submódulos, si corresponde:

```
git submodule update --init --recursive
```

### Métodos de compilación

#### Compilación con Android Studio

1. Abre Android Studio.
2. Selecciona Open o Abrir proyecto.
3. Selecciona el directorio donde clonaste OpenTune.
4. Espera a que termine la sincronización de Gradle.
5. Selecciona Build → Build Bundle(s) / APK(s) → Build APK(s).

#### Compilación por línea de comandos

Construir la versión de producción:

```
./gradlew assembleRelease
```

Construir la versión de depuración:

```
./gradlew assembleDebug
```

Ejecutar la compilación completa:

```
./gradlew build
```

Ejecutar pruebas unitarias:

```
./gradlew test
```

Limpiar los archivos de compilación:

```
./gradlew clean
```

> Nota: los APK generados se encuentran dentro de `app/build/outputs/apk/`.

## Contribuciones

Las contribuciones son bienvenidas. Puedes ayudar reportando errores, proponiendo mejoras, enviando cambios o colaborando con las traducciones.

### Código de conducta

Todos los participantes deben mantener un entorno respetuoso y constructivo.

Antes de contribuir, consulta nuestro [Código de Conducta](https://codeberg.org/Arturo254/OpenTune/src/branch/main/CODE_OF_CONDUCT.md?utm_source=chatgpt.com).

### Traducciones

Ayuda a traducir OpenTune a tu idioma o a mejorar las traducciones existentes:

### Canales de comunidad

### Flujo de trabajo de desarrollo

1. Revisión de issues: consulta las [issues abiertas](https://codeberg.org/Arturo254/OpenTune/issues?utm_source=chatgpt.com) o crea una nueva describiendo el problema o la propuesta.
2. Fork del repositorio: crea un fork personal del proyecto.
3. Rama de trabajo: crea una rama para tu cambio:
   ```
   git checkout -b feature/nueva-caracteristica
   ```
4. Implementación: realiza los cambios siguiendo las convenciones del proyecto.
5. Pruebas: ejecuta las pruebas correspondientes:
   ```
   ./gradlew test
   ```
6. Commit: utiliza mensajes descriptivos:
   ```
   git commit -m "feat: añadir nueva característica"
   ```
7. Push: sube tu rama al fork:
   ```
   git push origin feature/nueva-caracteristica
   ```
8. Pull Request: abre una solicitud de incorporación de cambios y explica qué modificaste.

Consulta también nuestras [directrices de contribución](https://codeberg.org/Arturo254/OpenTune/src/branch/main/CONTRIBUTING.md?utm_source=chatgpt.com).

## Apoya el Proyecto

OpenTune es un proyecto de código abierto desarrollado y mantenido de forma independiente.

Si quieres apoyar su desarrollo, puedes realizar una donación voluntaria. Las contribuciones ayudan a cubrir gastos de infraestructura y permiten dedicar más tiempo al mantenimiento y desarrollo de la aplicación.

> Nota: las donaciones son completamente opcionales. OpenTune seguirá siendo gratuito y de código abierto, independientemente del apoyo financiero recibido.

## 🌟 Reconocimientos

OpenTune existe gracias al trabajo, la inspiración y el apoyo de distintos proyectos y personas de la comunidad de desarrollo de software libre.

Agradecemos especialmente a:

### 💡 Proyectos que inspiraron OpenTune

\- [ArchiveTune](https://github.com/koiverse/ArchiveTune?utm_source=chatgpt.com)\
Proyecto utilizado como base e inspiración inicial para distintas ideas y funcionalidades de OpenTune.

\- [Vivi Music](https://github.com/vivizzz007/vivi-music?utm_source=chatgpt.com)\
Referencia para el código fuente de Canvas y la integración de API.

### 🤝 Colaboradores principales

\- [@Fabito02](https://github.com/Fabito02?utm_source=chatgpt.com)\
Por su apoyo, comentarios, ideas y acompañamiento durante el desarrollo inicial del proyecto.

### 🌍 Comunidad OpenTune

\- Traductores de la comunidad\
Gracias a quienes colaboran con las traducciones y ayudan a que OpenTune esté disponible en distintos idiomas.

\- Beta testers\
Gracias a quienes prueban las versiones de desarrollo, reportan errores y comparten sus comentarios.

### ❤️ Comunidad Open Source

OpenTune también reconoce el trabajo de los desarrolladores que crean y mantienen las herramientas, bibliotecas y proyectos de código abierto que hacen posible el desarrollo de aplicaciones para Android.

## Licencia

Copyright © 2023-2026 Arturo Cervantes

OpenTune se distribuye bajo los términos de la GNU General Public License v3.0 (GPL-3.0).

Puedes utilizar, estudiar, modificar y redistribuir el software de acuerdo con las condiciones de esta licencia. Las versiones modificadas o derivadas distribuidas deben respetar las obligaciones establecidas por la GPL-3.0.

Consulta el archivo [LICENSE](https://codeberg.org/Arturo254/OpenTune/src/branch/main/LICENSE?utm_source=chatgpt.com) para conocer los términos completos.
